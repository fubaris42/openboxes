/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.19-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: openboxes
-- ------------------------------------------------------
-- Server version	10.11.19-MariaDB-ubu2204

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `DATABASECHANGELOG`
--

DROP TABLE IF EXISTS `DATABASECHANGELOG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `DATABASECHANGELOG` (
  `ID` varchar(255) NOT NULL,
  `AUTHOR` varchar(255) NOT NULL,
  `FILENAME` varchar(255) NOT NULL,
  `DATEEXECUTED` datetime NOT NULL,
  `ORDEREXECUTED` int(11) NOT NULL,
  `EXECTYPE` varchar(10) NOT NULL,
  `MD5SUM` varchar(35) DEFAULT NULL,
  `DESCRIPTION` varchar(255) DEFAULT NULL,
  `COMMENTS` varchar(255) DEFAULT NULL,
  `TAG` varchar(255) DEFAULT NULL,
  `LIQUIBASE` varchar(20) DEFAULT NULL,
  `CONTEXTS` varchar(255) DEFAULT NULL,
  `LABELS` varchar(255) DEFAULT NULL,
  `DEPLOYMENT_ID` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DATABASECHANGELOG`
--

LOCK TABLES `DATABASECHANGELOG` WRITE;
/*!40000 ALTER TABLE `DATABASECHANGELOG` DISABLE KEYS */;
INSERT INTO `DATABASECHANGELOG` VALUES
('1633402273161-1','jmiranda','views/drop-all-views.xml','2026-10-13 07:49:26',1039,'RERAN','8:2e191c6851d4326d7f5edf272f5de5a6','sql','Views will be recreated after database migrations are executed.',NULL,'3.10.1',NULL,NULL,'1877765999'),
('1700664714834-1','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:25',2,'EXECUTED','8:10729c2ba3ac63fbb58376b85a3cfacd','createTable tableName=address','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-2','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',3,'EXECUTED','8:cc002fa3c4dfab2f90f36bb45d44beef','createTable tableName=attribute','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-3','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',4,'EXECUTED','8:45c32330bc0392e064794ad44ad44d60','createTable tableName=attribute_entity_type_codes','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-4','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',5,'EXECUTED','8:a5926d64b0f53a40d9145a4067cc4586','createTable tableName=attribute_options','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-5','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',6,'EXECUTED','8:593f33573d2a7a00bc7d4e993985fd27','createTable tableName=budget_code','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-6','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',7,'EXECUTED','8:6eda459d8adbff35fdfa36baf2d68728','createTable tableName=category','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-9','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',8,'EXECUTED','8:e494529d512dbd47e942e1d276fe8935','createTable tableName=comment','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-10','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',9,'EXECUTED','8:9a82ba0a9f91d23599765e35937f88cb','createTable tableName=consumption','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-11','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',10,'EXECUTED','8:66330bddb37e385361b05cdc6cb3aee7','createTable tableName=consumption_fact','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-12','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',11,'EXECUTED','8:f0792ab6f000b077b1bd174c33badb52','createTable tableName=container','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-13','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',12,'EXECUTED','8:1e942a5abae768f1e43c591eca201924','createTable tableName=container_type','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-14','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',13,'EXECUTED','8:b3c130f8ea784c9e2560693f1caea024','createTable tableName=date_dimension','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-15','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',14,'EXECUTED','8:065a5b468826f2941feb703e748484ff','createTable tableName=document','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-16','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',15,'EXECUTED','8:1c6907f97031319fb5b75636697c0aa8','createTable tableName=document_type','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-17','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',16,'EXECUTED','8:cb368e17a7ba9b379835ab3fe1f53bef','createTable tableName=donor','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-18','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',17,'EXECUTED','8:3d05df5a2e5484272f5015511209124a','createTable tableName=event','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-19','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',18,'EXECUTED','8:f8c72f75e58d55aad6432d85d8870218','createTable tableName=event_type','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-20','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',19,'EXECUTED','8:e2d83f8ef4212d43436e1a2277b21e5c','createTable tableName=fulfillment','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-21','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',20,'EXECUTED','8:e1987cc221656ac7075fb8584761f6c6','createTable tableName=fulfillment_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-22','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',21,'EXECUTED','8:886766cecd2aff70cacad5f60880e188','createTable tableName=fulfillment_item_shipment_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-23','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',22,'EXECUTED','8:870dafa2f39bc4eaf0b68428e8b81e24','createTable tableName=gl_account','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-24','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',23,'EXECUTED','8:368d40b61e1b0dd722924d5d41247d87','createTable tableName=gl_account_type','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-25','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',24,'EXECUTED','8:abdd8ec214055da29bb4008b162192e9','createTable tableName=indicator','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-26','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',25,'EXECUTED','8:1b4652db8a3a9732805a064a826933a7','createTable tableName=inventory','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-27','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',26,'EXECUTED','8:d58a42c61037217e66f6c184451f644e','createTable tableName=inventory_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-28','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',27,'EXECUTED','8:71a01df4535eb750ada3b5b4fe71e8cb','createTable tableName=inventory_item_snapshot','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-29','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',28,'EXECUTED','8:e60103f543fe9987944b2974a3a2de0c','createTable tableName=inventory_level','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-30','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',29,'EXECUTED','8:0ad0d4e561ecb3ba47270e6f0765af51','createTable tableName=inventory_snapshot','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-31','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',30,'EXECUTED','8:6889d4af6ea0ea9b856df42ed3aa57d1','createTable tableName=invoice','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-32','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',31,'EXECUTED','8:d23bce7564df851f28fe5f5fc98b3f24','createTable tableName=invoice_document','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-33','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',32,'EXECUTED','8:053bbbf1a4d395b4318fb47a16a60928','createTable tableName=invoice_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-34','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',33,'EXECUTED','8:064f6a6bb562b1961baf932ee8993b75','createTable tableName=invoice_reference_number','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-35','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',34,'EXECUTED','8:2bdebd994ce6fda32f70d1bb117184cf','createTable tableName=invoice_type','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-36','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',35,'EXECUTED','8:b5ffd9b0c1a090c3aa05582e8c0df6db','createTable tableName=local_transfer','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-37','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',36,'EXECUTED','8:70caf9444934bd1bf0026c18e3505fdd','createTable tableName=localization','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-38','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',37,'EXECUTED','8:c1c55174b9002f5b47e9023630842db6','createTable tableName=location','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-39','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',38,'EXECUTED','8:00a1e03b3481cf27b90bb9cd4cbc82a9','createTable tableName=location_dimension','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-40','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',39,'EXECUTED','8:73e10e6cd6c581a09f4a3bffbdd05f9a','createTable tableName=location_group','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-41','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',40,'EXECUTED','8:b170377a1e1fe481f9435ff6b4cd3da6','createTable tableName=location_role','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-42','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',41,'EXECUTED','8:2570d160edbad39e3299374f336e4d8c','createTable tableName=location_supported_activities','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-43','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',42,'EXECUTED','8:9aa60ffbb77d1b4802d53b72bcaf5301','createTable tableName=location_type','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-44','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',43,'EXECUTED','8:1efa01282f9f1c9d9951898c8bae39c5','createTable tableName=location_type_supported_activities','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-45','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',44,'EXECUTED','8:6959916cbd47ed1015d5d76d59c8c057','createTable tableName=lot_dimension','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-46','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',45,'EXECUTED','8:f574a5e7c874eb5e6700890c06523478','createTable tableName=order','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-47','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',46,'EXECUTED','8:b33c6fa4c75705bc2ebd452b8ac6b5ab','createTable tableName=order_adjustment','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-48','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',47,'EXECUTED','8:892c01fb79663e2c1bab376af9029a0b','createTable tableName=order_adjustment_invoice','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-49','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',48,'EXECUTED','8:b7651a0db2609d3bb34c9a49d6d6148f','createTable tableName=order_adjustment_type','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-50','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',49,'EXECUTED','8:5532d21f2f829a60a75f1416a04ec4d4','createTable tableName=order_comment','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-51','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',50,'EXECUTED','8:2cfcbeccc7132346091b73d6e583f64a','createTable tableName=order_document','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-52','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',51,'EXECUTED','8:8d7830fdecdad099a0663e469b2f6cbd','createTable tableName=order_event','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-53','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',52,'EXECUTED','8:872003dddc33f5584e30beb9bae6b1ba','createTable tableName=order_invoice','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-54','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',53,'EXECUTED','8:bef5c0a17eb40ba4afa50a1f11c27135','createTable tableName=order_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-55','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',54,'EXECUTED','8:d6a57ff3ded3815a4d9b40d87c940d08','createTable tableName=order_item_comment','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-56','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',55,'EXECUTED','8:fffc4af033a588afd09959d49d163c1d','createTable tableName=order_shipment','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-58','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',56,'EXECUTED','8:dc583c8492908cb3f4aada58ff6c591c','createTable tableName=order_type','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-59','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',57,'EXECUTED','8:277ff4f3f206a4c1fbf0673ae8cdd0e3','createTable tableName=organization_sequences','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-60','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',58,'EXECUTED','8:d05552085261628eb1ab58e39b4b12a6','createTable tableName=party','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-61','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',59,'EXECUTED','8:a30bbe569ca2c3749c9bfd3c7f1a1eac','createTable tableName=party_role','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-62','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',60,'EXECUTED','8:8b3c496ce0a025c1daa4b83fd54bbfe7','createTable tableName=party_type','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-63','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',61,'EXECUTED','8:52dc4c0400c869cd9d8f9c1266fc2fae','createTable tableName=payment_method_type','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-64','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',62,'EXECUTED','8:416804721751f2731c6f69f4d613ed73','createTable tableName=payment_term','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-65','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',63,'EXECUTED','8:0911548afd63928d52b5ddca566cc76d','createTable tableName=person','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-66','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',64,'EXECUTED','8:387342638375d4b91265f903fd07bc46','createTable tableName=picklist','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-67','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',65,'EXECUTED','8:93ed363606f94e4e5e18c2b42353b512','createTable tableName=picklist_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-68','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',66,'EXECUTED','8:237c6a640476add0916c9262c86b1c63','createTable tableName=preference_type','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-69','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',67,'EXECUTED','8:7ef9cdfd4896ef2751889df746f3913f','createTable tableName=product','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-70','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',68,'EXECUTED','8:d8b7ef62e12b46552c921c78d5fdf579','createTable tableName=product_association','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-71','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',69,'EXECUTED','8:338a8d3c71f1a374579168c38f864ba9','createTable tableName=product_attribute','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-72','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',70,'EXECUTED','8:398767f75586898b84e90d6221b8ecf3','createTable tableName=product_availability','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-73','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',71,'EXECUTED','8:8a0844ceba1c964348e3ece3ce33a31b','createTable tableName=product_catalog','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-74','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',72,'EXECUTED','8:3a1f9aa0881da06a9494522090373a60','createTable tableName=product_catalog_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-75','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',73,'EXECUTED','8:ea62e63ea88961d081dcc31d6fcdbeb7','createTable tableName=product_category','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-76','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',74,'EXECUTED','8:fa3838597a5cd9593ca78c9c141f3cfd','createTable tableName=product_component','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-79','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',75,'EXECUTED','8:d47ac49b6bdc79ee5949153f4f1121b7','createTable tableName=product_dimension','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-80','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',76,'EXECUTED','8:17359ff5d60457308fd0397fc6398e5a','createTable tableName=product_document','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-81','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',77,'EXECUTED','8:bd454c4fcc08fbefe197e828408b3f9f','createTable tableName=product_group','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-82','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',78,'EXECUTED','8:870984a0861c150b93ea7db46462be75','createTable tableName=product_group_product','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-83','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',79,'EXECUTED','8:a75bec41fcab51043021880cf7044bb6','createTable tableName=product_merge_logger','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-84','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',80,'EXECUTED','8:e1f5367a4e8b4c4e1bdc4479f232ac1b','createTable tableName=product_package','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-85','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',81,'EXECUTED','8:d9bcd85230063888c1d7e13a6447d823','createTable tableName=product_price','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-86','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',82,'EXECUTED','8:e13c89a8c5c86e36ba71c15c6a2f8e4d','createTable tableName=product_supplier','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-87','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',83,'EXECUTED','8:8a437ce339399208ebb1792c02d4ba4f','createTable tableName=product_supplier_preference','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-88','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',84,'EXECUTED','8:00c344ba5b1f990f87bc4aa2e2ab0061','createTable tableName=product_tag','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-89','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',85,'EXECUTED','8:fbddff427fb6de5ea2db8a06f1b9f097','createTable tableName=product_type','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-90','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',86,'EXECUTED','8:c2654c9e32f1f61af55f5d9cec244499','createTable tableName=product_type_displayed_fields','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-91','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',87,'EXECUTED','8:12c1ace37071aba697300ad96ca386fb','createTable tableName=product_type_required_fields','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-92','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',88,'EXECUTED','8:98e29866bab9412a53c8e754ea607975','createTable tableName=product_type_supported_activities','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-93','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',89,'EXECUTED','8:c1f75a321b6dd4bb6895fe97ad701206','createTable tableName=receipt','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-94','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',90,'EXECUTED','8:5bd45e411a6294e9653471dd872c6092','createTable tableName=receipt_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-95','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',91,'EXECUTED','8:942539cfffe2a7530d2cec5ed0d8144c','createTable tableName=reference_number','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-96','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',92,'EXECUTED','8:9961dbe0ef7d0a1aa473356df0e54b3b','createTable tableName=reference_number_type','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-97','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',93,'EXECUTED','8:cb310eda32fd09c5fa5cd38ba560e659','createTable tableName=requisition','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-98','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',94,'EXECUTED','8:5a090ec9ee22c4c88244c7065ab35f04','createTable tableName=requisition_approvers','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-99','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',95,'EXECUTED','8:5bde565196f9cb96933dcde4a7dbc5a2','createTable tableName=requisition_comment','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-100','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',96,'EXECUTED','8:c5fc1278e568ec077051f821b148687c','createTable tableName=requisition_event','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-101','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',97,'EXECUTED','8:cf724d08738a5d08c9c61241d88de39a','createTable tableName=requisition_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-102','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',98,'EXECUTED','8:30224be2f985861f580983ec60efb0ec','createTable tableName=role','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-103','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',99,'EXECUTED','8:5a049b63e4d4d82ea58d4ca526a21f9f','createTable tableName=shipment','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-104','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',100,'EXECUTED','8:b0bb12caedade8f7010e1d9a763e4353','createTable tableName=shipment_comment','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-105','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',101,'EXECUTED','8:dec5d5ffcae16e276369272a5ba87aa6','createTable tableName=shipment_document','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-106','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',102,'EXECUTED','8:154db4d2056f4153791e7eee80fe330a','createTable tableName=shipment_event','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-107','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',103,'EXECUTED','8:3b297672d295fe9716525d8edd453365','createTable tableName=shipment_invoice','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-108','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',104,'EXECUTED','8:c42f58f7ed9198fa691809cb67835e83','createTable tableName=shipment_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-109','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',105,'EXECUTED','8:16f12c1dcfbdab720f10d735585958b2','createTable tableName=shipment_method','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-110','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',106,'EXECUTED','8:7a71b12c3fa7494a916ffa17ae072003','createTable tableName=shipment_reference_number','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-111','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:26',107,'EXECUTED','8:fbdcfe9ebdd38b42343c379a30978bb9','createTable tableName=shipment_type','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-112','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:27',108,'EXECUTED','8:a543e94377e5330c68279c4984d21b07','createTable tableName=shipment_workflow','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-113','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:27',109,'EXECUTED','8:c572c2454ca2f634fa4420c66490b235','createTable tableName=shipment_workflow_container_type','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-114','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:27',110,'EXECUTED','8:bbca2be73c5ea1020a5945aab22a7c0d','createTable tableName=shipment_workflow_document','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-115','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:27',111,'EXECUTED','8:3a431d82e8bf3e2cd232137ae20d41c4','createTable tableName=shipment_workflow_document_template','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-116','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:27',112,'EXECUTED','8:fe2957ba86ad1f95be37bb58767dda24','createTable tableName=shipment_workflow_reference_number_type','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-117','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:27',113,'EXECUTED','8:9885c7a65a6a48757a0e88f471016c3e','createTable tableName=shipper','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-118','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:27',114,'EXECUTED','8:517262122a93d8348bdfb18bc4772815','createTable tableName=shipper_service','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-120','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:27',115,'EXECUTED','8:eba9c05b9f4e9e5f1b2298478d664faa','createTable tableName=synonym','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-121','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:27',116,'EXECUTED','8:bde18121f326facc419e0b22139140e2','createTable tableName=tag','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-122','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:27',117,'EXECUTED','8:267852b1ed76bbb82c7bdf0620e356e0','createTable tableName=transaction','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-123','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:27',118,'EXECUTED','8:5df862e8fc6f4a6c68f9a672885ab813','createTable tableName=transaction_entry','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-124','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:27',119,'EXECUTED','8:034447645c3b400477c091d2e36e13cc','createTable tableName=transaction_fact','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-125','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:27',120,'EXECUTED','8:a862375055cd327872b2200458c31241','createTable tableName=transaction_type','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-126','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:27',121,'EXECUTED','8:ef1ef7e56d14a625bc29add985d46d4d','createTable tableName=transaction_type_dimension','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-127','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:27',122,'EXECUTED','8:2add9b65a4b539d34b81c779787f62e9','createTable tableName=unit_of_measure','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-128','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:27',123,'EXECUTED','8:ad0cf85bc33fcf3385d74bfab8937e96','createTable tableName=unit_of_measure_class','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-129','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:27',124,'EXECUTED','8:e38cf00f7d3355ce5117adce5b043020','createTable tableName=unit_of_measure_conversion','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-130','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:27',125,'EXECUTED','8:7150aa02aff972eb87e5dc801d371293','createTable tableName=user','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-131','openboxes (generated)','install/changelog-create-tables.groovy','2026-10-13 06:22:27',126,'EXECUTED','8:b1d9b20538db26e7511f9cf44cf060d1','createTable tableName=user_role','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-132','openboxes (generated)','install/changelog-add-unique-constraints.groovy','2026-10-13 06:22:27',127,'EXECUTED','8:5591317e96b603bd5f0463b95195876c','addUniqueConstraint constraintName=inventory_item_snapshot_key, tableName=inventory_item_snapshot','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-133','openboxes (generated)','install/changelog-add-unique-constraints.groovy','2026-10-13 06:22:27',128,'EXECUTED','8:63ca40858e14dd5a648ea5af4b5ecdb3','addUniqueConstraint constraintName=inventory_snapshot_uniq_idx, tableName=inventory_snapshot','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-134','openboxes (generated)','install/changelog-add-unique-constraints.groovy','2026-10-13 06:22:27',129,'EXECUTED','8:711d552e2f7cfc139f68baa8ed1fc5e9','addUniqueConstraint constraintName=localization_code_locale_idx, tableName=localization','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-135','openboxes (generated)','install/changelog-add-unique-constraints.groovy','2026-10-13 06:22:27',130,'EXECUTED','8:f7af95321cbb3b514816d0afb06066d1','addUniqueConstraint constraintName=product_availability_uniq_idx, tableName=product_availability','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-136','openboxes (generated)','install/changelog-add-unique-constraints.groovy','2026-10-13 06:22:27',131,'EXECUTED','8:d736daf495a582a87bce7761e1e85c86','addUniqueConstraint constraintName=product_id, tableName=inventory_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-137','openboxes (generated)','install/changelog-add-unique-constraints.groovy','2026-10-13 06:22:27',132,'EXECUTED','8:4c1c2f843bd78082276815fac30b1e3b','addUniqueConstraint constraintName=product_package_uniq_idx, tableName=product_package','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-788','openboxes (generated)','install/changelog-add-unique-constraints.groovy','2026-10-13 06:22:27',133,'EXECUTED','8:7a4a4f8c358b5617aff64f46e29e546d','addUniqueConstraint constraintName=party_type_code_uniq_idx, tableName=party_type','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-789','openboxes (generated)','install/changelog-add-unique-constraints.groovy','2026-10-13 06:22:27',134,'EXECUTED','8:45231b7fbe722dacef38dab6ad6139e6','addUniqueConstraint constraintName=code_idx, tableName=product_catalog','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-138','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:27',135,'EXECUTED','8:7032964aea9f8b3645f3f5dd87d93434','createIndex indexName=FK1143A95C8ABEBD5, tableName=location_dimension','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-139','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:27',136,'EXECUTED','8:851c55834cf2df0ebdbecb3d336b3013','createIndex indexName=FK143BF46AA462C195, tableName=user_role','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-140','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:27',137,'EXECUTED','8:c5c7cc9e711c2a2494c06b83d6f94ac0','createIndex indexName=FK143BF46AFF37FDB5, tableName=user_role','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-141','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:27',138,'EXECUTED','8:bbc1d5e54af38737d8433cc02ec9a130','createIndex indexName=FK1799509C20E33E1C, tableName=requisition','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-142','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:27',139,'EXECUTED','8:765e3dd10ba29e60ea047e83acbe1326','createIndex indexName=FK1799509C217F5972, tableName=requisition','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-143','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:27',140,'EXECUTED','8:fa9d68211dde19efb3b7f5e8b0cb6aae','createIndex indexName=FK1799509C2BDD17B3, tableName=requisition','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-144','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:27',141,'EXECUTED','8:768cf3a0daf1759f6cc2170860a1fe03','createIndex indexName=FK1799509C36C69275, tableName=requisition','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-145','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:27',142,'EXECUTED','8:847527a0324792bcc4c236526c93891f','createIndex indexName=FK1799509C426DD105, tableName=requisition','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-146','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:27',143,'EXECUTED','8:49a0f5c236311770e3a337a5c0a319ee','createIndex indexName=FK1799509C4CF042D8, tableName=requisition','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-147','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:27',144,'EXECUTED','8:05ecb93381c6dcbd919bd7a1245bcaac','createIndex indexName=FK1799509CD196DBBF, tableName=requisition','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-148','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:27',145,'EXECUTED','8:c6b753cf6fa42f83e564e9787951e5ea','createIndex indexName=FK1799509CD2CB8BBB, tableName=requisition','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-149','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:27',146,'EXECUTED','8:d421b952f2a31523d24af3a824e100d7','createIndex indexName=FK1799509CDFA74E0B, tableName=requisition','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-150','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:27',147,'EXECUTED','8:4e2cef0158a23a96ce8abae6c5dc1cb9','createIndex indexName=FK187E54C9DED5FAE7, tableName=product_catalog_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-151','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:27',148,'EXECUTED','8:7cc338edba80908930fffb3290951e3f','createIndex indexName=FK187E54C9FB5E604E, tableName=product_catalog_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-152','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:27',149,'EXECUTED','8:17807a4da0bd075ab295855f9c012fd6','createIndex indexName=FK1BF9A217F5972, tableName=tag','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-153','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:27',150,'EXECUTED','8:835aa3cb6b53847965913ccda292f352','createIndex indexName=FK1BF9A426DD105, tableName=tag','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-154','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:27',151,'EXECUTED','8:0b9e1dcdaaaf71aef163aa19797a1109','createIndex indexName=FK1C92FE2F3E67CF9F, tableName=party_role','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-155','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:27',152,'EXECUTED','8:3c353d8326d6733db3320fc419ddc144','createIndex indexName=FK1E50D72D72882836, tableName=transaction_fact','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-156','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:27',153,'EXECUTED','8:58af1a1ecee17ddc9f6bfe19398b3b3d','createIndex indexName=FK1E50D72DA27827C2, tableName=transaction_fact','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-157','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:27',154,'EXECUTED','8:a36be8f9024aa7bcd2bcd41b0b54f10f','createIndex indexName=FK1E50D72DCA32CFEF, tableName=transaction_fact','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-158','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:27',155,'EXECUTED','8:1634623fcc8aca731eb143701f41d900','createIndex indexName=FK1E50D72DCA354381, tableName=transaction_fact','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-159','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:27',156,'EXECUTED','8:3633e075760485aabdfb36635935d607','createIndex indexName=FK1E50D72DD1F27172, tableName=transaction_fact','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-160','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:27',157,'EXECUTED','8:a1735c90e98e1f759f39f08095bfce4b','createIndex indexName=FK299E50ABDED5FAE7, tableName=synonym','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-161','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:27',158,'EXECUTED','8:523d2f38d2af1936ea7ef7b0b79f9175','createIndex indexName=FK2D110D6418D76D84, tableName=order_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-162','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:27',159,'EXECUTED','8:8016ea7e0f5797f5648906e2d3584eb6','createIndex indexName=FK2D110D6429542386, tableName=order_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-163','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:27',160,'EXECUTED','8:423ef18955baa258d1c840f9309f7040','createIndex indexName=FK2D110D6429B2552E, tableName=order_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-164','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:27',161,'EXECUTED','8:2532289437fab1042c85ffffc6a71b6a','createIndex indexName=FK2D110D6444979D51, tableName=order_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-165','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:27',162,'EXECUTED','8:04652b73ac659e46b86afb867a99a2a2','createIndex indexName=FK2D110D6451A9416E, tableName=order_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-166','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:27',163,'EXECUTED','8:c037f45e051075416b2a59356cb109ad','createIndex indexName=FK2D110D645ED93B03, tableName=order_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-167','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:27',164,'EXECUTED','8:148a5e2bc82ed3db2933ceb9ae592af8','createIndex indexName=FK2D110D64605326C, tableName=order_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-168','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:27',165,'EXECUTED','8:75f5beb6748ebced6ab330f86aa35f97','createIndex indexName=FK2D110D64911E7578, tableName=order_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-169','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:27',166,'EXECUTED','8:8a463b68b2f98c166a8abe7f49f71bf1','createIndex indexName=FK2D110D64AA992CED, tableName=order_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-170','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:28',167,'EXECUTED','8:eebdc21eb009e303b87c2e544f10d171','createIndex indexName=FK2D110D64D08EDBE6, tableName=order_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-171','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:28',168,'EXECUTED','8:764a280955babbbc1632937e4fa721c6','createIndex indexName=FK2D110D64DED5FAE7, tableName=order_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-172','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:28',169,'EXECUTED','8:c5e1466a03fdb130c6c3deb16d69abcc','createIndex indexName=FK2D110D64EF4C770D, tableName=order_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-173','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:28',170,'EXECUTED','8:b7f25fd56f70d461bff3e03e51e449fb','createIndex indexName=FK2DE9EE6EB8839C0F, tableName=order_comment','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-174','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:28',171,'EXECUTED','8:c6bd9b3f5988ca229b3863a73e7a1ffb','createIndex indexName=FK2DE9EE6EC4A49BBF, tableName=order_comment','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-175','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:28',172,'EXECUTED','8:30a9fc14ae7054f470dffe43ca111b37','createIndex indexName=FK2E4511844A3E746, tableName=unit_of_measure_conversion','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-176','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:28',173,'EXECUTED','8:399155719a7b92c20e6cda83b24d6b2e','createIndex indexName=FK2E4511849B9434D5, tableName=unit_of_measure_conversion','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-177','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:28',174,'EXECUTED','8:4d22b1611467b5c03e35d42b32da7d33','createIndex indexName=FK302BCFE619A2EF8, tableName=category','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-178','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:28',175,'EXECUTED','8:d004af6e4ff0dfd268596ab88beb93ab','createIndex indexName=FK312F6C292388BC5, tableName=shipment_reference_number','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-179','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:28',176,'EXECUTED','8:2bc6c52a4f97fd0f01d9c5656ce6d48f','createIndex indexName=FK313A4BDF14F7BB8E, tableName=product_group_product','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-180','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:28',177,'EXECUTED','8:e47f8e4483cb9cece0917712ed2b2ebd','createIndex indexName=FK313A4BDFDED5FAE7, tableName=product_group_product','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-181','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:28',178,'EXECUTED','8:f73c539b018f4cc110a7b9f9e5b86d45','createIndex indexName=FK335CD11B6631D8CC, tableName=document','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-182','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:28',179,'EXECUTED','8:29eff2ed648b6ed228b18ee9205ccccf','createIndex indexName=FK36EBCB1F28CE07, tableName=user','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-183','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:28',180,'EXECUTED','8:169c612190758a2ce3e1f19e3ba01ee4','createIndex indexName=FK36EBCB41E07A73, tableName=user','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-184','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:28',181,'EXECUTED','8:c32b306eff4994768ea081c84f1dec00','createIndex indexName=FK38A5EE5FAF1302EB, tableName=comment','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-185','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:28',182,'EXECUTED','8:7f1e9fc13c61845c383cb56747275a0b','createIndex indexName=FK38A5EE5FF885F087, tableName=comment','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-186','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:28',183,'EXECUTED','8:64737749c4661ab728cafefd1f6de0c6','createIndex indexName=FK38EE09DA47B0D087, tableName=attribute_entity_type_codes','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-187','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:28',184,'EXECUTED','8:58406eaf3f4d88454970fea3384bc57d','createIndex indexName=FK3A097B1C24DEBC91, tableName=product_supplier','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-188','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:28',185,'EXECUTED','8:f92b6753d09f957eb5fdf04cc317d44b','createIndex indexName=FK3A097B1C2A475A37, tableName=product_supplier','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-189','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:28',186,'EXECUTED','8:09ee682d6a7442773b62b89d82156eff','createIndex indexName=FK3A097B1CDED5FAE7, tableName=product_supplier','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-190','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:28',187,'EXECUTED','8:4fe8f5ce57364039736f6ba7ae5a74c0','createIndex indexName=FK3A097B1CF42F7E5C, tableName=product_supplier','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-191','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:28',188,'EXECUTED','8:b409e5b7770d362731e38e4de89cec28','createIndex indexName=FK40203B26296B2CA3, tableName=shipment_method','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-192','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:28',189,'EXECUTED','8:86597fafc23c914ae064a0506f201969','createIndex indexName=FK40203B263896C98E, tableName=shipment_method','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-193','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:28',190,'EXECUTED','8:8bae5d596064580f7549a5148dd2f6d0','createIndex indexName=FK408272383B5F6286, tableName=receipt','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-194','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:28',191,'EXECUTED','8:ea7147d9bdf81c5d2b59bf98d977ad9c','createIndex indexName=FK4082723844979D51, tableName=receipt','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-195','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:28',192,'EXECUTED','8:782747ce3e68538273bbcf335320737d','createIndex indexName=FK414EF28F1E2B3CDC, tableName=requisition','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-196','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:28',193,'EXECUTED','8:f05ca5b47d043bb2719a538ea348b388','createIndex indexName=FK414EF28F44979D51, tableName=requisition','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-197','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:28',194,'EXECUTED','8:4bc2ddbda73196f3f5b0a05ea6442220','createIndex indexName=FK414EF28F94567276, tableName=requisition','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-198','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:28',195,'EXECUTED','8:3cb4317423eb30e170ec86a3ab2e18b3','createIndex indexName=FK414EF28FDBDEDAC4, tableName=requisition','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-199','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:28',196,'EXECUTED','8:9359ed73099afd2f8d24f69f4f978cfb','createIndex indexName=FK414EF28FDD302242, tableName=requisition','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-200','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:28',197,'EXECUTED','8:ad6fd64ca673e4897f06b548789575b1','createIndex indexName=FK4A1ABEFE3BE9D843, tableName=order_adjustment','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-201','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:28',198,'EXECUTED','8:56b12e555ecbbed2d05f12972b3d361e','createIndex indexName=FK4A1ABEFED08EDBE6, tableName=order_adjustment','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-202','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:28',199,'EXECUTED','8:26e866b491be1d6db0cd7f90df0ac3d6','createIndex indexName=FK4A1ABEFEE1A39520, tableName=order_adjustment','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-203','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:28',200,'EXECUTED','8:a5d5b053ab2c893947ed75b6520f582e','createIndex indexName=FK4BB27241154F600, tableName=shipment_workflow_reference_number_type','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-204','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:28',201,'EXECUTED','8:79c4c8f01cbc1b2b70fd0f695121a891','createIndex indexName=FK4DA982C35DE21C87, tableName=requisition_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-205','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:28',202,'EXECUTED','8:545534a505ed937153bc37077149dd48','createIndex indexName=FK4DA982C3AA992CED, tableName=requisition_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-206','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:28',203,'EXECUTED','8:5641be4d68cddf2e4ea04779a4107a6b','createIndex indexName=FK4DA982C3DED5FAE7, tableName=requisition_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-207','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:28',204,'EXECUTED','8:930750b011598cc9a59a81057194a2f2','createIndex indexName=FK4DA982C3EF4C770D, tableName=requisition_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-208','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:28',205,'EXECUTED','8:c1e66acb886205bf2f37ee61e0b72a75','createIndex indexName=FK51F3772FEF4C770D, tableName=product_group','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-209','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:28',206,'EXECUTED','8:c0109edb5bb2ef65423cfae7ad9b02b6','createIndex indexName=FK5358E4D614F7BB8E, tableName=requisition_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-210','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:28',207,'EXECUTED','8:3f2794540b9db6473be2714c13fd315a','createIndex indexName=FK5358E4D61594028E, tableName=requisition_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-211','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:28',208,'EXECUTED','8:9c58f966114b467974810a6907913c73','createIndex indexName=FK5358E4D6217F5972, tableName=requisition_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-212','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:28',209,'EXECUTED','8:791529ce76ccf228d24eed66243c70b1','createIndex indexName=FK5358E4D629B2552E, tableName=requisition_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-213','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:28',210,'EXECUTED','8:08698eac15655c677984383515473850','createIndex indexName=FK5358E4D6405AC22D, tableName=requisition_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-214','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:28',211,'EXECUTED','8:01678a1cb2771aaa1886496def6c468d','createIndex indexName=FK5358E4D6426DD105, tableName=requisition_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-215','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:28',212,'EXECUTED','8:c692a60b8e111ec8b74ea9d2c4df521d','createIndex indexName=FK5358E4D644979D51, tableName=requisition_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-216','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:28',213,'EXECUTED','8:1e4e6925710f187501c37d51dfb78541','createIndex indexName=FK5358E4D6DD302242, tableName=requisition_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-217','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:28',214,'EXECUTED','8:f4a1edf503dab3ab7e848284a4ae4fc8','createIndex indexName=FK5358E4D6F84BDE18, tableName=requisition_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-218','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:28',215,'EXECUTED','8:507c8ef9d95c3f1506c2dbc7435152d7','createIndex indexName=FK5A2551DEAC392B33, tableName=fulfillment','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-219','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:28',216,'EXECUTED','8:5355fe9a9de7533ffa0513e3960525cc','createIndex indexName=FK5C6729A3D970DB4, tableName=event','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-220','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:28',217,'EXECUTED','8:9a3cb7832dc4c81f2773eeb55cbf9857','createIndex indexName=FK5C6729A4415A5B0, tableName=event','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-221','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:28',218,'EXECUTED','8:f4e6852b56a6e3dd14df9171ffd41b5b','createIndex indexName=FK5D1B504A217F5972, tableName=unit_of_measure_class','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-222','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:29',219,'EXECUTED','8:7dee66b3e01ad74eeab5ad32802855c4','createIndex indexName=FK5D1B504A426DD105, tableName=unit_of_measure_class','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-223','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:29',220,'EXECUTED','8:15ad2c79b6888dbc61f74e6e4ce96c30','createIndex indexName=FK5D1B504A6B9DFD, tableName=unit_of_measure_class','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-224','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:29',221,'EXECUTED','8:ffc4aa536860bbc6cc0228cf9d6d1a40','createIndex indexName=FK615A48F6217F5972, tableName=product_package','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-225','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:29',222,'EXECUTED','8:68195bc445be8d436823224c188a115a','createIndex indexName=FK615A48F629542386, tableName=product_package','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-226','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:29',223,'EXECUTED','8:d54709ddae07a0eddfcdb74e1137e492','createIndex indexName=FK615A48F63906C4CF, tableName=product_package','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-227','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:29',224,'EXECUTED','8:6a31ea8f24c8e9ff6ad6f8f21774b974','createIndex indexName=FK615A48F6426DD105, tableName=product_package','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-228','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:29',225,'EXECUTED','8:84ba22135c746129948ff63787198fe3','createIndex indexName=FK651874E1E2B3CDC, tableName=order','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-229','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:29',226,'EXECUTED','8:4db82c052417c224afb985c30cb5770b','createIndex indexName=FK651874E240896CB, tableName=order','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-230','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:29',227,'EXECUTED','8:261f2148a4d2d69c229f4b02f4f1d3b5','createIndex indexName=FK651874E35D76CB0, tableName=order','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-231','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:29',228,'EXECUTED','8:aeb023845e9928cca03240de8d53cb38','createIndex indexName=FK651874E41B7275F, tableName=order','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-232','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:29',229,'EXECUTED','8:26ac2ad67ec4f9468e0f3bd3c0e6e417','createIndex indexName=FK651874E44979D51, tableName=order','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-233','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:29',230,'EXECUTED','8:334c938900424f20cb2541462b21cff2','createIndex indexName=FK651874E6A8010C1, tableName=order','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-234','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:29',231,'EXECUTED','8:4fc86fed551dda235aefe80d06d473a9','createIndex indexName=FK651874E6D91063C, tableName=order','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-235','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:29',232,'EXECUTED','8:48e75b071705e5daa6f7fb17086ccf0a','createIndex indexName=FK651874E8AF312E3, tableName=order','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-236','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:29',233,'EXECUTED','8:449403a44172b44262f50c7a33ea00a2','createIndex indexName=FK651874E8E7F7DCF, tableName=order','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-237','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:29',234,'EXECUTED','8:dce89f395c1255ba61cb4690afa02f7d','createIndex indexName=FK651874E9E52B00C, tableName=order','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-238','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:29',235,'EXECUTED','8:0ab03c06e43ead100ce6e7a4aa60bbe5','createIndex indexName=FK651874EAF6D8801, tableName=order','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-239','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:29',236,'EXECUTED','8:cb222dfe2050067e95afc5b41c4e467e','createIndex indexName=FK651874EDBDEDAC4, tableName=order','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-240','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:29',237,'EXECUTED','8:156735e7bfed08a7e982278f32ac682f','createIndex indexName=FK6581AE69DFE4C4C, tableName=party','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-241','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:29',238,'EXECUTED','8:44755357f132eaa070de74cae3888430','createIndex indexName=FK6581AE6D1DFC6D7, tableName=party','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-242','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:29',239,'EXECUTED','8:6c8355ffd845e2583220c0c8d0794902','createIndex indexName=FK6A1A433C3BE9D843, tableName=order_invoice','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-243','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:29',240,'EXECUTED','8:bf6dfa9e6f2d4d9d4af07024e952ac2a','createIndex indexName=FK6A1A433CB95ED8E0, tableName=order_invoice','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-244','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:29',241,'EXECUTED','8:962d30ff3d71d0aa6b2e804b7ed86efc','createIndex indexName=FK6C5BE20C800AA15, tableName=shipment_document','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-245','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:29',242,'EXECUTED','8:7a9ee42f1ace52b9e2b8c5d2cc63e7ee','createIndex indexName=FK6D032BB53B350242, tableName=shipment_event','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-246','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:29',243,'EXECUTED','8:9a888103d3bc3308e0982a58ff0dfb6c','createIndex indexName=FK6D032BB5786431F, tableName=shipment_event','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-247','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:29',244,'EXECUTED','8:f1c13e4ec9a1fb18410a2e628d519f3a','createIndex indexName=FK714F9FB528F75F00, tableName=location','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-248','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:29',245,'EXECUTED','8:18a4ac793da42ff66fa4e6207c09d1cf','createIndex indexName=FK714F9FB53BB36E94, tableName=location','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-249','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:29',246,'EXECUTED','8:d9d3c6c7c724ee17553e0514dba6bfc8','createIndex indexName=FK714F9FB541E07A73, tableName=location','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-250','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:29',247,'EXECUTED','8:687ba048722c632afcb18c31850201ef','createIndex indexName=FK714F9FB5606C7D95, tableName=location','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-251','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:29',248,'EXECUTED','8:89feb44990fbadaa5b8e39a934da72b3','createIndex indexName=FK714F9FB561ED379F, tableName=location','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-252','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:29',249,'EXECUTED','8:bab8ee8cc86aa4ee90e78bc895296c61','createIndex indexName=FK714F9FB572A2C5B4, tableName=location','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-253','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:29',250,'EXECUTED','8:c203f4b44dc2dbb81aea29722487f822','createIndex indexName=FK714F9FB57AF9A3C0, tableName=location','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-254','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:29',251,'EXECUTED','8:649a8ff3497a357bb85adca71bf257a9','createIndex indexName=FK7348B491217F5972, tableName=unit_of_measure','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-255','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:29',252,'EXECUTED','8:3f7b8c60a65662e9c0f328ce30f78735','createIndex indexName=FK7348B491426DD105, tableName=unit_of_measure','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-256','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:29',253,'EXECUTED','8:635f15aa3f200ff616db639145e52729','createIndex indexName=FK7348B49197D8303E, tableName=unit_of_measure','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-257','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:29',254,'EXECUTED','8:5ee9f67f87290a6d31d68846a157c429','createIndex indexName=FK740B54769DB749D, tableName=inventory_snapshot','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-258','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:29',255,'EXECUTED','8:f0ee7fce4afeab920b3a0bb6e4b6b50f','createIndex indexName=FK740B547AA992CED, tableName=inventory_snapshot','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-259','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:29',256,'EXECUTED','8:33d68758a2faeaed93ba026ffd8144e8','createIndex indexName=FK740B547DED5FAE7, tableName=inventory_snapshot','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-260','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:29',257,'EXECUTED','8:082266ee9d1698195353079913ec19d5','createIndex indexName=FK74D92A693D2E628A, tableName=order_event','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-261','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:29',258,'EXECUTED','8:f1cc9b1f9d87f8592f83dee5cf29c649','createIndex indexName=FK74D92A69786431F, tableName=order_event','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-262','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:29',259,'EXECUTED','8:a5129a9de8b0e1ae5b850aa392849977','createIndex indexName=FK7975323F4CC49445, tableName=local_transfer','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-263','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:29',260,'EXECUTED','8:4161709d50a1a56ee2c737c6b2146489','createIndex indexName=FK7975323F57563498, tableName=local_transfer','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-264','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:29',261,'EXECUTED','8:bf72d8eb0271f7472054d1187431cb5c','createIndex indexName=FK7A19D7561ED379F, tableName=location_group','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-265','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:29',262,'EXECUTED','8:4f18a1328fbf2a3f07aaa546921ac5a1','createIndex indexName=FK7AFF67F928F75F00, tableName=location_type_supported_activities','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-266','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:29',263,'EXECUTED','8:d4444eb3bd7d86010b261eaae3ec397b','createIndex indexName=FK7FA0D2DE1E2B3CDC, tableName=transaction','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-267','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:29',264,'EXECUTED','8:eea1dc52af7c5a39b6a35d184b3768bb','createIndex indexName=FK7FA0D2DE217F5972, tableName=transaction','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-268','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:29',265,'EXECUTED','8:d2c2ebc5f3b86afce6c59fd44dffa478','createIndex indexName=FK7FA0D2DE3265A8A9, tableName=transaction','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-269','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:29',266,'EXECUTED','8:b75a4241d984b4fbb1d6fea771c1d1a8','createIndex indexName=FK7FA0D2DE426DD105, tableName=transaction','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-270','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:29',267,'EXECUTED','8:9ec4683eacc8b3e98a91d7a96fb01a7e','createIndex indexName=FK7FA0D2DE5DE9E374, tableName=transaction','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-271','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:29',268,'EXECUTED','8:0bd18d0d042640003f8b20b1eb2471f2','createIndex indexName=FK7FA0D2DE5F12AFED, tableName=transaction','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-272','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:29',269,'EXECUTED','8:ba64fbe80050bf5ca655058851e76ddb','createIndex indexName=FK7FA0D2DE72A2C5B4, tableName=transaction','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-273','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:29',270,'EXECUTED','8:9d71f946ba8f0df6d5f2de99bbd1651a','createIndex indexName=FK7FA0D2DE828481AF, tableName=transaction','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-274','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:29',271,'EXECUTED','8:b26f55c72b4d45d21efac17b2a2d9542','createIndex indexName=FK7FA0D2DEB3FB7111, tableName=transaction','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-275','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:29',272,'EXECUTED','8:228064ec0115fed9de9bf979362236ad','createIndex indexName=FK7FA0D2DEB80B3233, tableName=transaction','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-276','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:29',273,'EXECUTED','8:8ce066b93dbbd6e60bdbdb66093e3b68','createIndex indexName=FK7FA0D2DED08EDBE6, tableName=transaction','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-277','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:29',274,'EXECUTED','8:122a7e198a15530bab5b9ac4d9168b7e','createIndex indexName=FK7FA0D2DEF7076438, tableName=transaction','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-278','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:30',275,'EXECUTED','8:f55cf85c10d52bdb0647247cfb11a588','createIndex indexName=FK7FA87A22B3FB7111, tableName=transaction_type_dimension','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-279','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:30',276,'EXECUTED','8:acfd509c993dbdc5343039506636a710','createIndex indexName=FK9475736B3BE9D843, tableName=order_shipment','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-280','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:30',277,'EXECUTED','8:52a088adeabe2f22b6308f14d791d4f7','createIndex indexName=FK9475736BB06EC4FB, tableName=order_shipment','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-281','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:30',278,'EXECUTED','8:aac1a12a5926cbbd7fe6b8ccd81505fe','createIndex indexName=FK94A534C24DEBC91, tableName=product_attribute','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-282','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:30',279,'EXECUTED','8:d177afd9d4a18870c188224b59a1e62c','createIndex indexName=FK94A534C29542386, tableName=product_attribute','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-283','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:30',280,'EXECUTED','8:e564ff9a79bf10e1cd0dd76d641bab44','createIndex indexName=FK94A534C47B0D087, tableName=product_attribute','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-284','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:30',281,'EXECUTED','8:9fc73ef28436a9cecad1011e0803bfdc','createIndex indexName=FK94A534CDED5FAE7, tableName=product_attribute','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-285','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:30',282,'EXECUTED','8:367d6a833771e44bbf7c876aa592ee73','createIndex indexName=FK98293BFB217F5972, tableName=synonym','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-286','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:30',283,'EXECUTED','8:c355d97688e12f0387ef1dd8a7395a8f','createIndex indexName=FK98293BFB426DD105, tableName=synonym','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-287','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:30',284,'EXECUTED','8:1ea6170fa8751f0937930a3523fecf2c','createIndex indexName=FK9A945A36C800AA15, tableName=shipment_workflow_document','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-288','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:30',285,'EXECUTED','8:98906533e427e15fb3b49b4e29d3a0b6','createIndex indexName=FK9A945A36EC587CFB, tableName=shipment_workflow_document','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-289','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:30',286,'EXECUTED','8:025e789b6bd7c646db80548de6d43680','createIndex indexName=FKA0303E4EDED5FAE7, tableName=product_category','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-290','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:30',287,'EXECUTED','8:6591a211bee8c566e6bdb093cfe30b12','createIndex indexName=FKA0303E4EEF4C770D, tableName=product_category','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-291','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:30',288,'EXECUTED','8:bf89ba80a6a819f21445ca192a3139e0','createIndex indexName=FKA71CAC4A9740C85F, tableName=product_tag','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-292','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:30',289,'EXECUTED','8:6877391e87f4cf275a70f3fc83a2905f','createIndex indexName=FKA71CAC4ADED5FAE7, tableName=product_tag','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-293','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:30',290,'EXECUTED','8:b731c98f4b17743dda37e81b0e3c555c','createIndex indexName=FKA8B7A49072882836, tableName=consumption_fact','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-294','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:30',291,'EXECUTED','8:cedc4301430a2c2fdec808801a2a16d7','createIndex indexName=FKA8B7A490A27827C2, tableName=consumption_fact','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-295','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:30',292,'EXECUTED','8:9bbe7a40112fe8e4e04ace0fe8bea808','createIndex indexName=FKA8B7A490CA32CFEF, tableName=consumption_fact','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-296','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:30',293,'EXECUTED','8:b71efddffa1f0b2584d6c614c679b054','createIndex indexName=FKA8B7A490D1F27172, tableName=consumption_fact','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-297','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:30',294,'EXECUTED','8:b3b5d6716d9917378d99900eb59f2691','createIndex indexName=FKABC21FD12EF4C7F4, tableName=transaction_entry','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-298','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:30',295,'EXECUTED','8:dcbea1cad92faead874e92841ccb06d6','createIndex indexName=FKABC21FD169DB749D, tableName=transaction_entry','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-299','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:30',296,'EXECUTED','8:894b6ef773bd0cfb4f5296927487b7de','createIndex indexName=FKABC21FD1AA992CED, tableName=transaction_entry','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-300','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:30',297,'EXECUTED','8:b187a3f3ee7707a993d0c66e59ef8ed5','createIndex indexName=FKABC21FD1DED5FAE7, tableName=transaction_entry','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-301','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:30',298,'EXECUTED','8:da8bce4780d14ace40f537bfffb4b2dc','createIndex indexName=FKAE3064BA44979D51, tableName=receipt_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-302','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:30',299,'EXECUTED','8:ee4469a2e8ec05c10f524ef0bd55468c','createIndex indexName=FKAE3064BA69DB749D, tableName=receipt_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-303','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:30',300,'EXECUTED','8:eef5cb36afcf7934c9c8d2aaf894a3b7','createIndex indexName=FKAE3064BAAA992CED, tableName=receipt_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-304','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:30',301,'EXECUTED','8:3d401f9b85ff791006957f129eed1a5e','createIndex indexName=FKAE3064BAB06EC4FB, tableName=receipt_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-305','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:30',302,'EXECUTED','8:e2a8eb38ed417b652337155a6defada6','createIndex indexName=FKAE3064BADED5FAE7, tableName=receipt_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-306','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:30',303,'EXECUTED','8:4423ec9ae589228b53fc2c5740a179ca','createIndex indexName=FKAE3064BAF7076438, tableName=receipt_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-307','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:30',304,'EXECUTED','8:f50a9195a23c0de86f8059571bcaf414','createIndex indexName=FKB511C5AD20E351EA, tableName=product_component','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-308','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:30',305,'EXECUTED','8:3b963610ea129d70f9bb0664eba380d5','createIndex indexName=FKB511C5AD24DEBC91, tableName=product_component','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-309','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:30',306,'EXECUTED','8:5316274c396c87b4b9d24a05c5acce8f','createIndex indexName=FKB511C5ADFB4C199C, tableName=product_component','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-310','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:30',307,'EXECUTED','8:da2bb97bca872bbaa5da85b816f4fe20','createIndex indexName=FKB5A4FE84C4A49BBF, tableName=order_item_comment','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-311','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:30',308,'EXECUTED','8:71d540575dbd50987ac664f8956d58b9','createIndex indexName=FKBD34ABCD8ABEBD5, tableName=inventory_item_snapshot','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-312','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:30',309,'EXECUTED','8:0414b01f2909fc80f049d66ecfa49171','createIndex indexName=FKBD34ABCDAA992CED, tableName=inventory_item_snapshot','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-313','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:30',310,'EXECUTED','8:7860f19d9dd44d559700f9c8e35aea43','createIndex indexName=FKBD34ABCDDED5FAE7, tableName=inventory_item_snapshot','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-314','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:30',311,'EXECUTED','8:61b8ddb06cbbc209ada3f099f7e8cc54','createIndex indexName=FKC254A2E16CDADD53, tableName=inventory_level','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-315','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:30',312,'EXECUTED','8:68c3565a67ac34de843fb1cc6a3f053b','createIndex indexName=FKC254A2E172A2C5B4, tableName=inventory_level','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-316','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:30',313,'EXECUTED','8:8530052a410949a1241b55d7e52ff3c1','createIndex indexName=FKC254A2E1CFDCB4DF, tableName=inventory_level','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-317','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:30',314,'EXECUTED','8:c2f22aad4daeae60c801a2f0a34fd316','createIndex indexName=FKC254A2E1DED5FAE7, tableName=inventory_level','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-318','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:30',315,'EXECUTED','8:f2982684360e3003991094b75c93614c','createIndex indexName=FKC254A2E1F07D879A, tableName=inventory_level','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-319','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:30',316,'EXECUTED','8:b8121f0217b7480c8b7276ce13a1c9ef','createIndex indexName=FKC398CCBAC4A49BBF, tableName=shipment_comment','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-320','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:30',317,'EXECUTED','8:04fe781688dc1b2c16cb98b0cf1e035d','createIndex indexName=FKC73E1616DED5FAE7, tableName=product_dimension','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-321','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:30',318,'EXECUTED','8:6c2c998b7ccbf559f66194993c3c794b','createIndex indexName=FKC7AA9C4013CE80, tableName=attribute','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-322','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:30',319,'EXECUTED','8:18c04ca43cbfee2b05330ffb64a2ac08','createIndex indexName=FKCD71F39B8ABEBD5, tableName=consumption','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-323','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:30',320,'EXECUTED','8:5142ce514017bde4309211ecae0b2461','createIndex indexName=FKCD71F39BAA992CED, tableName=consumption','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-324','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:30',321,'EXECUTED','8:230fa37eaff1d5a7423f7b2ae36f39ba','createIndex indexName=FKCD71F39BDED5FAE7, tableName=consumption','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-325','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:31',322,'EXECUTED','8:a09b643b47cc4d56f6f980f2e99fc60e','createIndex indexName=FKD08A526BC800AA15, tableName=product_document','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-326','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:31',323,'EXECUTED','8:513cd3d28b1b02b3a04d882aaf972484','createIndex indexName=FKD08A526BDED5FAE7, tableName=product_document','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-327','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:31',324,'EXECUTED','8:c2616d88ca7cc2814314e402bfeb50d0','createIndex indexName=FKD2EAD9F8AA992CED, tableName=lot_dimension','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-328','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:31',325,'EXECUTED','8:7f20fbd3b136e70ea210fc95f54e6dc3','createIndex indexName=FKD3F8383F217F5972, tableName=picklist','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-329','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:31',326,'EXECUTED','8:a0a9c8cd97268f0688147e7e2dd4ed28','createIndex indexName=FKD3F8383F426DD105, tableName=picklist','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-330','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:31',327,'EXECUTED','8:ac96707beb23a2b06ff0d1292f6907c0','createIndex indexName=FKD3F8383F5DE9E374, tableName=picklist','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-331','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:31',328,'EXECUTED','8:010fedca5949cbc4c9efaa0c82143d94','createIndex indexName=FKD3F8383FA3E976BC, tableName=picklist','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-332','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:31',329,'EXECUTED','8:9ee6e425ea273af4a919e9b7999167f7','createIndex indexName=FKD3FC6EAB69DB749D, tableName=product_availability','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-333','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:31',330,'EXECUTED','8:20880d7e912f37abc5345bc4e3a753f9','createIndex indexName=FKD3FC6EABAA992CED, tableName=product_availability','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-334','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:31',331,'EXECUTED','8:9e77bc2cf3bf057461530dc15d0758a9','createIndex indexName=FKD584C4C4FF77FF9B, tableName=shipment_workflow','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-335','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:31',332,'EXECUTED','8:82057916b6fb806887c9b0dd24d68f1e','createIndex indexName=FKD790DEBD154F600, tableName=reference_number','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-336','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:31',333,'EXECUTED','8:9dda55da8f3cc2af90fc45819623722e','createIndex indexName=FKDA3BB2981CD3412D, tableName=shipment_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-337','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:31',334,'EXECUTED','8:7c247c2699097a2e8474ea4867d427d6','createIndex indexName=FKDA3BB2983B5F6286, tableName=shipment_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-338','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:31',335,'EXECUTED','8:af7bf91068bd5f4f8f435c5871644705','createIndex indexName=FKDA3BB29844979D51, tableName=shipment_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-339','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:31',336,'EXECUTED','8:e2c4feda32c7b55a25db6398c204939a','createIndex indexName=FKDA3BB29849AB6B52, tableName=shipment_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-340','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:31',337,'EXECUTED','8:21a723a2221180b01125648fecf87dba','createIndex indexName=FKDA3BB29869DB749D, tableName=shipment_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-341','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:31',338,'EXECUTED','8:99d366dc8a3663c1659eefe98e6f1669','createIndex indexName=FKDA3BB2987400E88E, tableName=shipment_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-342','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:31',339,'EXECUTED','8:9603501b1acf84c77785ee66e1ffaed7','createIndex indexName=FKDA3BB298AA992CED, tableName=shipment_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-343','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:31',340,'EXECUTED','8:ad1a7ddaff7d1e4f9cf427feafb9c858','createIndex indexName=FKDA3BB298DED5FAE7, tableName=shipment_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-344','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:31',341,'EXECUTED','8:b7fa845eb7af7c418d83428430202a4d','createIndex indexName=FKDEF5AD1317A6E251, tableName=shipment_workflow_container_type','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-345','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:31',342,'EXECUTED','8:b4f09112a7340da63df95eb59a92fe83','createIndex indexName=FKDF7559D73896C98E, tableName=shipper_service','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-346','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:31',343,'EXECUTED','8:8a7ac12d623cc154e09edd71d6483a7f','createIndex indexName=FKE071DE6DB06EC4FB, tableName=fulfillment_item_shipment_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-347','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:31',344,'EXECUTED','8:838c899d1fa316d354819f9fe75037cb','createIndex indexName=FKE071DE6DB42751E1, tableName=fulfillment_item_shipment_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-348','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:31',345,'EXECUTED','8:9f246c104236233f9604bc13552224fc','createIndex indexName=FKE139719A1E2B3CDC, tableName=shipment','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-349','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:31',346,'EXECUTED','8:5f62e691a20af141971016dd1363cf84','createIndex indexName=FKE139719A217F5972, tableName=shipment','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-350','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:31',347,'EXECUTED','8:b206e295a544a0191bf578e09b212664','createIndex indexName=FKE139719A294C1012, tableName=shipment','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-351','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:31',348,'EXECUTED','8:070850dc693c0fd2cb02164ea7382cf4','createIndex indexName=FKE139719A426DD105, tableName=shipment','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-352','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:31',349,'EXECUTED','8:2b2c2b3ee8f552391cdf8e68dc2c1d74','createIndex indexName=FKE139719A44979D51, tableName=shipment','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-353','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:31',350,'EXECUTED','8:e44fdff8be17a476413b32bad071d514','createIndex indexName=FKE139719A49AB6B52, tableName=shipment','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-354','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:31',351,'EXECUTED','8:625016da98fa67df852345dbce166cb5','createIndex indexName=FKE139719A5DE9E374, tableName=shipment','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-355','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:31',352,'EXECUTED','8:be361357ba225a1b868886f18f11f3d9','createIndex indexName=FKE139719AA28CC5FB, tableName=shipment','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-356','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:31',353,'EXECUTED','8:57f42fcff0daf4d1621276c65c1b6328','createIndex indexName=FKE139719AD95ACF25, tableName=shipment','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-357','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:31',354,'EXECUTED','8:321f2e203d00b10f9b14a922c9902741','createIndex indexName=FKE139719ADBDEDAC4, tableName=shipment','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-358','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:31',355,'EXECUTED','8:14f8429226b94bbb1326463aba14fe3d','createIndex indexName=FKE139719AFF77FF9B, tableName=shipment','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-359','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:31',356,'EXECUTED','8:6dedd74a02ec235076cf488a8d8d7ec2','createIndex indexName=FKE698D2ECC800AA15, tableName=order_document','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-360','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:31',357,'EXECUTED','8:fbf91563541e8ad767d5c3050dcaa92d','createIndex indexName=FKE698D2ECFE10118D, tableName=order_document','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-361','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:31',358,'EXECUTED','8:8f72dd1945fc283675c55e1f599516a5','createIndex indexName=FKE7584B1369DB749D, tableName=picklist_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-362','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:31',359,'EXECUTED','8:5914caa1152e193dba2e2103d9e6f81a','createIndex indexName=FKE7814C8117A6E251, tableName=container','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-363','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:31',360,'EXECUTED','8:817a0f1eec7ba644c0d952a296ebe7c1','createIndex indexName=FKE7814C813B5F6286, tableName=container','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-364','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:31',361,'EXECUTED','8:da97f0bbfe5e29396638616cb2a0a75b','createIndex indexName=FKE7814C8144979D51, tableName=container','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-365','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:31',362,'EXECUTED','8:620057d1b3599c3978296f0974671304','createIndex indexName=FKE7814C814B6A2E03, tableName=container','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-366','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:31',363,'EXECUTED','8:af719a2657404d416084fc23b934ed8f','createIndex indexName=FKED441931C8653BC0, tableName=product_association','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-367','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:31',364,'EXECUTED','8:7bb4232cad5bffd68ffe3adb98b00e34','createIndex indexName=FKED441931DED5FAE7, tableName=product_association','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-368','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:31',365,'EXECUTED','8:53364b5ed2dbe36f7c2510ab97a62e49','createIndex indexName=FKED8DCCEF217F5972, tableName=product','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-369','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:31',366,'EXECUTED','8:0dc8f72a4a93488589fd6d31c4b60c6e','createIndex indexName=FKED8DCCEF426DD105, tableName=product','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-370','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:31',367,'EXECUTED','8:2d5ce2308e1038a1351649a35759864c','createIndex indexName=FKED8DCCEFABD88AC6, tableName=product','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-371','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:31',368,'EXECUTED','8:e786cc86fb30978f4d7183815a726e96','createIndex indexName=FKED8DCCEFEEB2908D, tableName=product','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-372','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:31',369,'EXECUTED','8:7ea8fe9f221f6fd8b22261e790955080','createIndex indexName=FKED8DCCEFEF4C770D, tableName=product','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-373','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:31',370,'EXECUTED','8:eca1d8db448b69cc264ba2bba10f1f81','createIndex indexName=FKEDC55CD447EBE106, tableName=fulfillment_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-374','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:31',371,'EXECUTED','8:c5bdc3812240e4ec5781105a5397799d','createIndex indexName=FKEDC55CD494567276, tableName=fulfillment_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-375','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:31',372,'EXECUTED','8:af0adf16932d5f399429948f7e3394b1','createIndex indexName=FKEDC55CD4AA992CED, tableName=fulfillment_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-376','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:31',373,'EXECUTED','8:35740e7673774984716c46d024394a08','createIndex indexName=FKF58372688ABEBD5, tableName=location_supported_activities','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-378','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:31',374,'EXECUTED','8:0b2e156b1fd55b0dfb5960e0d7e4ea76','createIndex indexName=fk_budget_code_created_by, tableName=budget_code','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-379','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:32',375,'EXECUTED','8:32393e035a6ffc4605995d1b9c61da1e','createIndex indexName=fk_budget_code_organization, tableName=budget_code','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-380','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:32',376,'EXECUTED','8:a59446a1acf52ff586b14ae6e0727c32','createIndex indexName=fk_budget_code_updated_by, tableName=budget_code','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-381','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:32',377,'EXECUTED','8:a02d872ae3f831049c633a829d825952','createIndex indexName=fk_category_gl_account, tableName=category','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-382','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:32',378,'EXECUTED','8:76dc00c5fa0b3b2800585af3b76f14ce','createIndex indexName=fk_event_comment, tableName=event','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-383','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:32',379,'EXECUTED','8:c3e353142400f73f0140899145e04180','createIndex indexName=fk_event_created_by, tableName=event','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-384','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:32',380,'EXECUTED','8:7e0b3700e269c0075d73b64a3fec8f30','createIndex indexName=fk_gl_account_created_by, tableName=gl_account','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-385','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:32',381,'EXECUTED','8:35136d98e0114bd20409cffa4c173394','createIndex indexName=fk_gl_account_gl_account_type, tableName=gl_account','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-386','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:32',382,'EXECUTED','8:464bc837a941ae05eaf7e1ec38e183d4','createIndex indexName=fk_gl_account_type_created_by, tableName=gl_account_type','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-387','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:32',383,'EXECUTED','8:863a71f42bb63cba89896529fd705fee','createIndex indexName=fk_gl_account_type_updated_by, tableName=gl_account_type','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-388','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:32',384,'EXECUTED','8:587e8763cf12a6e6f5caca0db7d90e8d','createIndex indexName=fk_gl_account_updated_by, tableName=gl_account','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-389','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:32',385,'EXECUTED','8:7745194337f502b23beb50608213ea4e','createIndex indexName=fk_invoice_created_by, tableName=invoice','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-390','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:32',386,'EXECUTED','8:49127290c88ec5515f35f85355bc63ba','createIndex indexName=fk_invoice_currency_uom, tableName=invoice','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-391','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:32',387,'EXECUTED','8:9f591f58e3812d8d6731260136950714','createIndex indexName=fk_invoice_document_document, tableName=invoice_document','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-392','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:32',388,'EXECUTED','8:ec01ff6c51fcdede0e39feee9eb9902d','createIndex indexName=fk_invoice_document_invoice, tableName=invoice_document','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-393','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:32',389,'EXECUTED','8:de6348217ea25b17cd6630cfa9a280f3','createIndex indexName=fk_invoice_invoice_type, tableName=invoice','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-394','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:32',390,'EXECUTED','8:7527e3c2f70f5149cea6437b2db60f66','createIndex indexName=fk_invoice_item_budget_code, tableName=invoice_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-395','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:32',391,'EXECUTED','8:cf501437e54a199370ce030c2a25e8e1','createIndex indexName=fk_invoice_item_created_by, tableName=invoice_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-396','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:32',392,'EXECUTED','8:b742687328cb4c6714664646f5c71d72','createIndex indexName=fk_invoice_item_gl_account, tableName=invoice_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-397','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:32',393,'EXECUTED','8:c1657a3c984c7dd7e467de4980203290','createIndex indexName=fk_invoice_item_invoice, tableName=invoice_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-398','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:32',394,'EXECUTED','8:686a834351fad1cd1cf7c0d0ed8f0e6f','createIndex indexName=fk_invoice_item_product, tableName=invoice_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-399','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:32',395,'EXECUTED','8:145fe90911d773ebdb9d1fe21ced9d04','createIndex indexName=fk_invoice_item_quantity_uom, tableName=invoice_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-400','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:32',396,'EXECUTED','8:04f19ca16009345432e878a490b89b78','createIndex indexName=fk_invoice_item_updated_by, tableName=invoice_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-401','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:32',397,'EXECUTED','8:09d8614afd3979373692a16f0400d5f7','createIndex indexName=fk_invoice_party, tableName=invoice','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-402','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:32',398,'EXECUTED','8:a8ef22c0749ef7261185caa11ce09b3a','createIndex indexName=fk_invoice_party_from, tableName=invoice','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-403','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:32',399,'EXECUTED','8:8052fdce92769aa0edc02be24389bc90','createIndex indexName=fk_invoice_reference_number_invoice_id, tableName=invoice_reference_number','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-404','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:32',400,'EXECUTED','8:3de66180bdee5ecee02536f28e9f5f27','createIndex indexName=fk_invoice_reference_number_reference_number_id, tableName=invoice_reference_number','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-405','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:32',401,'EXECUTED','8:b8794f59951ac675db65499fccd8e33e','createIndex indexName=fk_invoice_type_created_by, tableName=invoice_type','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-406','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:32',402,'EXECUTED','8:7ac4f67520159884c5548ffea9170856','createIndex indexName=fk_invoice_type_updated_by, tableName=invoice_type','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-407','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:32',403,'EXECUTED','8:51c21a169adca601b86d6f4311cffea8','createIndex indexName=fk_invoice_updated_by, tableName=invoice','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-408','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:32',404,'EXECUTED','8:af47008e13b0dd8fb9f7f8c346dba3c9','createIndex indexName=fk_order_adjustment_budget_code, tableName=order_adjustment','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-409','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:32',405,'EXECUTED','8:14c5e7c8db509866f2986714999ab055','createIndex indexName=fk_order_adjustment_gl_account, tableName=order_adjustment','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-410','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:32',406,'EXECUTED','8:9a4655fdbdcd1bf50578043240a78768','createIndex indexName=fk_order_adjustment_type_gl_account, tableName=order_adjustment_type','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-411','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:32',407,'EXECUTED','8:39c0965ca28d3b128dd8b34bbc00eca7','createIndex indexName=fk_order_item_budget_code, tableName=order_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-412','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:32',408,'EXECUTED','8:baece4dac7426f7209a61fe45371ef91','createIndex indexName=fk_order_item_gl_account, tableName=order_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-413','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:32',409,'EXECUTED','8:0bc04ab8c5d1aea292e700150d4b3aa9','createIndex indexName=fk_order_type_created_by, tableName=order_type','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-414','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:32',410,'EXECUTED','8:552994f7225c5182fcc8617f2e0ad957','createIndex indexName=fk_order_type_updated_by, tableName=order_type','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-415','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:32',411,'EXECUTED','8:74f8443d6f67797e5b0c63acf566c9c4','createIndex indexName=fk_picklist_item_order_item, tableName=picklist_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-416','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:32',412,'EXECUTED','8:505f75f635470a86ff5932119e55e4a1','createIndex indexName=fk_picklist_order, tableName=picklist','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-417','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:32',413,'EXECUTED','8:6c81a321b19d3ac07c8d5d331d82c28b','createIndex indexName=fk_preference_type_created_by, tableName=preference_type','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-418','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:32',414,'EXECUTED','8:123a6462bfa2d1c056933bf1fe43a074','createIndex indexName=fk_preference_type_updated_by, tableName=preference_type','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-419','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:32',415,'EXECUTED','8:833d96b393d9366aaec8542326d677ef','createIndex indexName=fk_product_association_mutual_association, tableName=product_association','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-420','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:32',416,'EXECUTED','8:45be4d73f5d14cd77e7ad5263fa63966','createIndex indexName=fk_product_gl_account, tableName=product','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-421','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:32',417,'EXECUTED','8:089d6e608afb8bf54477ab55fca8c105','createIndex indexName=fk_product_merge_logger_created_by, tableName=product_merge_logger','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-422','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:32',418,'EXECUTED','8:fee13a5835cd033258e8f84ed5c1cdef','createIndex indexName=fk_product_merge_logger_obsolete_product, tableName=product_merge_logger','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-423','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:32',419,'EXECUTED','8:821cd45a4ee03798396df14ca671ee51','createIndex indexName=fk_product_merge_logger_primary_product, tableName=product_merge_logger','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-424','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:32',420,'EXECUTED','8:f40029ffe4a1f05c641f41dc7d86f634','createIndex indexName=fk_product_merge_logger_updated_by, tableName=product_merge_logger','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-425','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:32',421,'EXECUTED','8:e00fca5e2b2b7b09921e020233385e3d','createIndex indexName=fk_product_price_created_by, tableName=product_price','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-426','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:32',422,'EXECUTED','8:492dfb4c95e3851a451028aeb19ec3e8','createIndex indexName=fk_product_price_unit_of_measure, tableName=product_price','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-427','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:32',423,'EXECUTED','8:6281832d7c001a2103dafc4b8d9faf6b','createIndex indexName=fk_product_price_updated_by, tableName=product_price','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-428','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:32',424,'EXECUTED','8:a5bef8cb601f8fe7bdd66cb55cf0d7d0','createIndex indexName=fk_product_product_family, tableName=product','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-429','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:33',425,'EXECUTED','8:abbf148bc85a648b50557a703711dd09','createIndex indexName=fk_product_supplier_preference_created_by, tableName=product_supplier_preference','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-430','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:33',426,'EXECUTED','8:467d7c6d3f9e3f5d8a239bb4bdd51624','createIndex indexName=fk_product_supplier_preference_destination_party, tableName=product_supplier_preference','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-431','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:33',427,'EXECUTED','8:59d802cc775784c1607992606642d53a','createIndex indexName=fk_product_supplier_preference_preference_type, tableName=product_supplier_preference','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-432','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:33',428,'EXECUTED','8:f39bd365540fae89e91238897bb7f1d0','createIndex indexName=fk_product_supplier_preference_product_supplier, tableName=product_supplier_preference','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-433','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:33',429,'EXECUTED','8:8661977febda37e7fe047b2c56b9f99a','createIndex indexName=fk_product_supplier_preference_updated_by, tableName=product_supplier_preference','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-434','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:33',430,'EXECUTED','8:63490816b15458db1492742e3e303019','createIndex indexName=fk_product_type_displayed_fields_product_type, tableName=product_type_displayed_fields','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-435','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:33',431,'EXECUTED','8:5e8edd90d05fdd5c9fc63be66212911b','createIndex indexName=fk_product_type_required_fields_product_type, tableName=product_type_required_fields','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-436','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:33',432,'EXECUTED','8:7e68045c2e65f843316096871dfa6a1d','createIndex indexName=fk_product_type_supported_activities_product_type, tableName=product_type_supported_activities','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-437','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:33',433,'EXECUTED','8:c5db678c4b02031a00ecfbbe688217ee','createIndex indexName=fk_requisition_approved_by, tableName=requisition','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-438','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:33',434,'EXECUTED','8:0fe69dcd9740c16b20974aaed4b5ea95','createIndex indexName=fk_requisition_approvers_person, tableName=requisition_approvers','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-439','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:33',435,'EXECUTED','8:7a2e28d37f46bd2edb5741401f34e616','createIndex indexName=fk_requisition_approvers_requisition, tableName=requisition_approvers','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-440','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:33',436,'EXECUTED','8:3d803cf2c5ea03006c6b79c886e32e84','createIndex indexName=fk_requisition_comment_comment, tableName=requisition_comment','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-441','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:33',437,'EXECUTED','8:ac4860054a6fd4d9fea27e371cfdb81c','createIndex indexName=fk_requisition_comment_requisition, tableName=requisition_comment','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-442','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:33',438,'EXECUTED','8:420acf183ee1ee0f5eecee03d45345e8','createIndex indexName=fk_requisition_event_event, tableName=requisition_event','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-443','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:33',439,'EXECUTED','8:79d493f0933c14f2d8fe0612f923a007','createIndex indexName=fk_requisition_event_requisition, tableName=requisition_event','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-444','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:33',440,'EXECUTED','8:274be1f1002b823458de118c7315ab9a','createIndex indexName=fk_requisition_rejected_by, tableName=requisition','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-445','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:33',441,'EXECUTED','8:d5a0c1e940385bab772722f50f427478','createIndex indexName=fk_shipment_reference_number_shipment, tableName=shipment_reference_number','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-446','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:33',442,'EXECUTED','8:6750da0b436528d0e4a6f7e1015df32a','createIndex indexName=inventory_snapshot_date_idx, tableName=inventory_snapshot','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-447','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:33',443,'EXECUTED','8:509158e54c2493bb26f8eec92c4a5963','createIndex indexName=inventory_snapshot_last_updated_idx, tableName=inventory_snapshot','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-448','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:33',444,'EXECUTED','8:edecf8e9a7ac5181cf3d5a3b52f4ff89','createIndex indexName=location_role_ibfk_1, tableName=location_role','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-449','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:33',445,'EXECUTED','8:8e3a972f549d236f9cd156c62dfe8e0b','createIndex indexName=location_role_ibfk_2, tableName=location_role','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-450','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:33',446,'EXECUTED','8:270e3eed9db61ddbbbfa18b02b329b03','createIndex indexName=location_role_ibfk_3, tableName=location_role','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-451','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:33',447,'EXECUTED','8:e1fa99ee46a689ccc23a169548e7b438','createIndex indexName=order_adjustment_invoice_ibfk_1, tableName=order_adjustment_invoice','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-452','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:33',448,'EXECUTED','8:55a8eeeb8c486e562a8db9984870a958','createIndex indexName=order_adjustment_invoice_ibfk_2, tableName=order_adjustment_invoice','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-453','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:33',449,'EXECUTED','8:76489f9bce4166b240eb409a5ac466f3','createIndex indexName=picklist_item_ibfk_1, tableName=picklist_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-454','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:33',450,'EXECUTED','8:b865ed2983146479dad7ac2f2615947a','createIndex indexName=picklist_item_ibfk_2, tableName=picklist_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-455','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:33',451,'EXECUTED','8:afdd3c2ffebfd2107189ce5a99db13d2','createIndex indexName=picklist_item_ibfk_3, tableName=picklist_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-456','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:33',452,'EXECUTED','8:f0330b17e129866d2df0074c6d976f87','createIndex indexName=picklist_item_ibfk_4, tableName=picklist_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-457','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:33',453,'EXECUTED','8:db35b059cd2bc863b0816a349c9ba920','createIndex indexName=picklist_item_ibfk_5, tableName=picklist_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-458','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:33',454,'EXECUTED','8:3fc32cf48fa8886746214bd9808110e1','createIndex indexName=product_availability_product_location_idx, tableName=product_availability','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-460','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:33',455,'EXECUTED','8:ea579a1674acc308cfef018283f0d136','createIndex indexName=shipment_invoice_ibfk_1, tableName=shipment_invoice','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-461','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:33',456,'EXECUTED','8:38306d07f21ee852f71842905ff1b52c','createIndex indexName=shipment_invoice_ibfk_2, tableName=shipment_invoice','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-462','openboxes (generated)','install/changelog-create-indices.groovy','2026-10-13 06:22:33',457,'EXECUTED','8:482198ff452cc7cf3de4ebd3c77cccf7','createIndex indexName=zone_location_ibfk_3, tableName=location','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-463','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:33',458,'EXECUTED','8:6cea8d6a504f7f3d91bc39d88a1dba6f','addForeignKeyConstraint baseTableName=location_dimension, constraintName=FK1143A95C8ABEBD5, referencedTableName=location','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-464','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:33',459,'EXECUTED','8:e44ba1f2383d31abc234a7f1775cecb0','addForeignKeyConstraint baseTableName=user_role, constraintName=FK143BF46AA462C195, referencedTableName=user','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-465','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:33',460,'EXECUTED','8:99ba4490ec6dde113be797414a68574d','addForeignKeyConstraint baseTableName=user_role, constraintName=FK143BF46AFF37FDB5, referencedTableName=role','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-466','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:33',461,'EXECUTED','8:43be16b330e8badeb82e33d5fb15d66e','addForeignKeyConstraint baseTableName=requisition, constraintName=FK1799509C20E33E1C, referencedTableName=person','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-467','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:33',462,'EXECUTED','8:7b26b54c556d5f6c93cc4f405798cd0b','addForeignKeyConstraint baseTableName=requisition, constraintName=FK1799509C217F5972, referencedTableName=user','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-468','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:33',463,'EXECUTED','8:83d4dafcf7e2cacff6ca224613e3932b','addForeignKeyConstraint baseTableName=requisition, constraintName=FK1799509C2BDD17B3, referencedTableName=requisition','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-469','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:33',464,'EXECUTED','8:c6b1c7f7828437398d94e8298b2edc3c','addForeignKeyConstraint baseTableName=requisition, constraintName=FK1799509C36C69275, referencedTableName=person','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-470','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:33',465,'EXECUTED','8:362b0dd9820edd73c67124cb2fc2abac','addForeignKeyConstraint baseTableName=requisition, constraintName=FK1799509C426DD105, referencedTableName=user','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-471','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:33',466,'EXECUTED','8:6afe6d9fd467b713f5b420ae75cbdc4e','addForeignKeyConstraint baseTableName=requisition, constraintName=FK1799509C4CF042D8, referencedTableName=person','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-472','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:33',467,'EXECUTED','8:3acc481eed37079254a147fbb1c9f840','addForeignKeyConstraint baseTableName=requisition, constraintName=FK1799509CD196DBBF, referencedTableName=person','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-473','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:34',468,'EXECUTED','8:9d4328b1f51bdf7b37b57b779b39826f','addForeignKeyConstraint baseTableName=requisition, constraintName=FK1799509CD2CB8BBB, referencedTableName=person','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-474','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:34',469,'EXECUTED','8:979f08098b2da7696af9771f349bc8b7','addForeignKeyConstraint baseTableName=requisition, constraintName=FK1799509CDFA74E0B, referencedTableName=person','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-475','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:34',470,'EXECUTED','8:a04650edc1f720c715452b47b475b893','addForeignKeyConstraint baseTableName=product_catalog_item, constraintName=FK187E54C9DED5FAE7, referencedTableName=product','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-476','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:34',471,'EXECUTED','8:462d7ff96a2800137d453896b83329ed','addForeignKeyConstraint baseTableName=product_catalog_item, constraintName=FK187E54C9FB5E604E, referencedTableName=product_catalog','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-477','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:34',472,'EXECUTED','8:9b85706f360ef8687c2260cbceb7426a','addForeignKeyConstraint baseTableName=tag, constraintName=FK1BF9A217F5972, referencedTableName=user','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-478','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:34',473,'EXECUTED','8:dc07ff67973354058a0b0018ba3b5d07','addForeignKeyConstraint baseTableName=tag, constraintName=FK1BF9A426DD105, referencedTableName=user','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-479','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:34',474,'EXECUTED','8:2348d8bd343700da06bb8b08d844e4f0','addForeignKeyConstraint baseTableName=party_role, constraintName=FK1C92FE2F3E67CF9F, referencedTableName=party','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-480','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:34',475,'EXECUTED','8:90b14232a16a5a4e4c964b959cc78141','addForeignKeyConstraint baseTableName=transaction_fact, constraintName=FK1E50D72D72882836, referencedTableName=product_dimension','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-481','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:34',476,'EXECUTED','8:cedb3c1e6799b9dbe737a79d61e5fd3e','addForeignKeyConstraint baseTableName=transaction_fact, constraintName=FK1E50D72DA27827C2, referencedTableName=location_dimension','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-482','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:34',477,'EXECUTED','8:3aeb92f3fac83c4ce9967f453df0c790','addForeignKeyConstraint baseTableName=transaction_fact, constraintName=FK1E50D72DCA32CFEF, referencedTableName=date_dimension','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-483','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:34',478,'EXECUTED','8:aa41ce522721a7ba4b91e4e60d7a4f6d','addForeignKeyConstraint baseTableName=transaction_fact, constraintName=FK1E50D72DCA354381, referencedTableName=transaction_type_dimension','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-484','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:34',479,'EXECUTED','8:31a5ffe90117e02b6997610341b0bfb1','addForeignKeyConstraint baseTableName=transaction_fact, constraintName=FK1E50D72DD1F27172, referencedTableName=lot_dimension','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-485','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:34',480,'EXECUTED','8:8f54414febbaae19ade475931861d3c3','addForeignKeyConstraint baseTableName=synonym, constraintName=FK299E50ABDED5FAE7, referencedTableName=product','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-486','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:34',481,'EXECUTED','8:87ff1555de347e5dce4a53b242a76118','addForeignKeyConstraint baseTableName=order_item, constraintName=FK2D110D6418D76D84, referencedTableName=location','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-487','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:34',482,'EXECUTED','8:4c4f701b6f76ad6b4a91bdb8c21743e7','addForeignKeyConstraint baseTableName=order_item, constraintName=FK2D110D6429542386, referencedTableName=product_supplier','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-488','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:34',483,'EXECUTED','8:1e1191dd2109945f183c313d2165369f','addForeignKeyConstraint baseTableName=order_item, constraintName=FK2D110D6429B2552E, referencedTableName=product_package','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-489','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:34',484,'EXECUTED','8:585e0a4a1e915daf1de344079e7dc643','addForeignKeyConstraint baseTableName=order_item, constraintName=FK2D110D6444979D51, referencedTableName=person','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-490','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:34',485,'EXECUTED','8:0f0fd66b2cce8d2f7fcad72ee0c221c9','addForeignKeyConstraint baseTableName=order_item, constraintName=FK2D110D6451A9416E, referencedTableName=order_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-491','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:34',486,'EXECUTED','8:2a618a3b3c9ea2101abfa062e97a1007','addForeignKeyConstraint baseTableName=order_item, constraintName=FK2D110D645ED93B03, referencedTableName=unit_of_measure','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-492','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:34',487,'EXECUTED','8:a8510493bb0129d54f4615a9c18e64f0','addForeignKeyConstraint baseTableName=order_item, constraintName=FK2D110D64605326C, referencedTableName=location','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-493','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:34',488,'EXECUTED','8:6046017abf06dd6b51dd1d8a477fb3a0','addForeignKeyConstraint baseTableName=order_item, constraintName=FK2D110D64911E7578, referencedTableName=user','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-494','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:34',489,'EXECUTED','8:7d4a240baaf7764a73679d6a7770e654','addForeignKeyConstraint baseTableName=order_item, constraintName=FK2D110D64AA992CED, referencedTableName=inventory_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-495','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:34',490,'EXECUTED','8:fc9daee7bd9fa2de6233716b9e52e787','addForeignKeyConstraint baseTableName=order_item, constraintName=FK2D110D64D08EDBE6, referencedTableName=order','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-496','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:34',491,'EXECUTED','8:96a67ef3b4862bf3bb33a91b50cb9e19','addForeignKeyConstraint baseTableName=order_item, constraintName=FK2D110D64DED5FAE7, referencedTableName=product','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-497','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:34',492,'EXECUTED','8:e26a51d27f88ab448276ba1dc04bffb5','addForeignKeyConstraint baseTableName=order_item, constraintName=FK2D110D64EF4C770D, referencedTableName=category','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-498','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:34',493,'EXECUTED','8:28fde4bda2d813ccb6877af7cbb2ba96','addForeignKeyConstraint baseTableName=order_comment, constraintName=FK2DE9EE6EB8839C0F, referencedTableName=order','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-499','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:34',494,'EXECUTED','8:4a0ebb64a3740bf9e6481d5958902b8d','addForeignKeyConstraint baseTableName=order_comment, constraintName=FK2DE9EE6EC4A49BBF, referencedTableName=comment','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-500','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:34',495,'EXECUTED','8:3af5ac48304a26f558167d684055b750','addForeignKeyConstraint baseTableName=unit_of_measure_conversion, constraintName=FK2E4511844A3E746, referencedTableName=unit_of_measure','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-501','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:34',496,'EXECUTED','8:6bbb8a9df9e535b20d932720b8e4c92e','addForeignKeyConstraint baseTableName=unit_of_measure_conversion, constraintName=FK2E4511849B9434D5, referencedTableName=unit_of_measure','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-502','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:34',497,'EXECUTED','8:2cb8f5741bdeed0507723c05f7811fa3','addForeignKeyConstraint baseTableName=category, constraintName=FK302BCFE619A2EF8, referencedTableName=category','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-503','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:34',498,'EXECUTED','8:8ff7317c80605cbb724a63cb80199912','addForeignKeyConstraint baseTableName=shipment_reference_number, constraintName=FK312F6C292388BC5, referencedTableName=reference_number','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-504','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:34',499,'EXECUTED','8:58c894ff310d5787181aa0b579ab7b88','addForeignKeyConstraint baseTableName=product_group_product, constraintName=FK313A4BDF14F7BB8E, referencedTableName=product_group','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-505','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:34',500,'EXECUTED','8:571d09d440dca45b914367a5b846f459','addForeignKeyConstraint baseTableName=product_group_product, constraintName=FK313A4BDFDED5FAE7, referencedTableName=product','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-506','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:34',501,'EXECUTED','8:d7a5a8c471db4e2e23ef5ff6a80ae938','addForeignKeyConstraint baseTableName=document, constraintName=FK335CD11B6631D8CC, referencedTableName=document_type','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-507','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:34',502,'EXECUTED','8:a7ea14892bd25f121c1fd501097bf9ec','addForeignKeyConstraint baseTableName=user, constraintName=FK36EBCB1F28CE07, referencedTableName=location','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-508','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:34',503,'EXECUTED','8:eabb920e653850100e961e0b962fac3b','addForeignKeyConstraint baseTableName=user, constraintName=FK36EBCB41E07A73, referencedTableName=user','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-509','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:34',504,'EXECUTED','8:0414cc869b96b3386bd7de7ca15d8236','addForeignKeyConstraint baseTableName=comment, constraintName=FK38A5EE5FAF1302EB, referencedTableName=user','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-510','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:35',505,'EXECUTED','8:4cf635695297fa50d7cba40f0d259b4e','addForeignKeyConstraint baseTableName=comment, constraintName=FK38A5EE5FF885F087, referencedTableName=user','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-511','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:35',506,'EXECUTED','8:6eaad04063dfc70c67f470d7aa6f8020','addForeignKeyConstraint baseTableName=attribute_entity_type_codes, constraintName=FK38EE09DA47B0D087, referencedTableName=attribute','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-512','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:35',507,'EXECUTED','8:ed7b0a97d5cd8cce5a4ebf36f47c377f','addForeignKeyConstraint baseTableName=product_supplier, constraintName=FK3A097B1C24DEBC91, referencedTableName=unit_of_measure','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-513','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:35',508,'EXECUTED','8:fbeb362542c8e4545d40a546554fbe33','addForeignKeyConstraint baseTableName=product_supplier, constraintName=FK3A097B1C2A475A37, referencedTableName=party','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-514','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:35',509,'EXECUTED','8:d4b62f925a470d5885c8fc3375ce2a63','addForeignKeyConstraint baseTableName=product_supplier, constraintName=FK3A097B1CDED5FAE7, referencedTableName=product','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-515','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:35',510,'EXECUTED','8:57920e309de0752ca7d7336996836d57','addForeignKeyConstraint baseTableName=product_supplier, constraintName=FK3A097B1CF42F7E5C, referencedTableName=party','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-516','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:35',511,'EXECUTED','8:0da124ffd26251ba3df60d9c73bcf9c5','addForeignKeyConstraint baseTableName=shipment_method, constraintName=FK40203B26296B2CA3, referencedTableName=shipper_service','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-517','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:35',512,'EXECUTED','8:a6415aeffe80c8a4ab915cec0a952f18','addForeignKeyConstraint baseTableName=shipment_method, constraintName=FK40203B263896C98E, referencedTableName=shipper','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-518','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:35',513,'EXECUTED','8:41dd788c2a863fcf31f231aea552cfac','addForeignKeyConstraint baseTableName=receipt, constraintName=FK408272383B5F6286, referencedTableName=shipment','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-519','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:35',514,'EXECUTED','8:c537faf6c611c6a2ffe994c8d7291f2d','addForeignKeyConstraint baseTableName=receipt, constraintName=FK4082723844979D51, referencedTableName=person','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-520','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:35',515,'EXECUTED','8:6512fe37423e668a321203c0839ae9cd','addForeignKeyConstraint baseTableName=requisition, constraintName=FK414EF28F1E2B3CDC, referencedTableName=location','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-521','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:35',516,'EXECUTED','8:4849f2b78cd6af09c15b8796c07512d2','addForeignKeyConstraint baseTableName=requisition, constraintName=FK414EF28F44979D51, referencedTableName=person','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-522','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:35',517,'EXECUTED','8:f8f131a2845bc0c2c6d59ff71752054f','addForeignKeyConstraint baseTableName=requisition, constraintName=FK414EF28F94567276, referencedTableName=fulfillment','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-523','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:35',518,'EXECUTED','8:e63d1d725899bf79430fa9d8b5a92dfa','addForeignKeyConstraint baseTableName=requisition, constraintName=FK414EF28FDBDEDAC4, referencedTableName=location','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-524','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:35',519,'EXECUTED','8:fc27de034766bfcfb31c2dab32f452c1','addForeignKeyConstraint baseTableName=requisition, constraintName=FK414EF28FDD302242, referencedTableName=person','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-525','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:35',520,'EXECUTED','8:ae5b5804681df602d09c47510c798584','addForeignKeyConstraint baseTableName=order_adjustment, constraintName=FK4A1ABEFE3BE9D843, referencedTableName=order_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-526','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:35',521,'EXECUTED','8:61b68642135d2775af3d2b79f1776785','addForeignKeyConstraint baseTableName=order_adjustment, constraintName=FK4A1ABEFED08EDBE6, referencedTableName=order','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-527','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:35',522,'EXECUTED','8:3603322e7e4761399964cb159a9c8d3d','addForeignKeyConstraint baseTableName=order_adjustment, constraintName=FK4A1ABEFEE1A39520, referencedTableName=order_adjustment_type','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-528','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:35',523,'EXECUTED','8:2fc98376a262b414f0375ab84b7106a4','addForeignKeyConstraint baseTableName=shipment_workflow_reference_number_type, constraintName=FK4BB27241154F600, referencedTableName=reference_number_type','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-529','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:35',524,'EXECUTED','8:f731a5ec4b52e557d2dedf1861e84c15','addForeignKeyConstraint baseTableName=requisition_item, constraintName=FK4DA982C35DE21C87, referencedTableName=requisition','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-530','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:35',525,'EXECUTED','8:2e0383e0ad2bb5b05663b77e9ea3c905','addForeignKeyConstraint baseTableName=requisition_item, constraintName=FK4DA982C3911E7578, referencedTableName=user','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-531','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:35',526,'EXECUTED','8:408715ff1e34cf6b6a110c83e3f19364','addForeignKeyConstraint baseTableName=requisition_item, constraintName=FK4DA982C3AA992CED, referencedTableName=inventory_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-532','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:35',527,'EXECUTED','8:ae7136a669101be6d6ac7f653f2c7060','addForeignKeyConstraint baseTableName=requisition_item, constraintName=FK4DA982C3DED5FAE7, referencedTableName=product','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-533','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:35',528,'EXECUTED','8:8cac938242bc647a9917108b3bc9541b','addForeignKeyConstraint baseTableName=requisition_item, constraintName=FK4DA982C3EF4C770D, referencedTableName=category','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-534','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:35',529,'EXECUTED','8:554261180769ee0966d883f46e04a42b','addForeignKeyConstraint baseTableName=product_group, constraintName=FK51F3772FEF4C770D, referencedTableName=category','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-535','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:35',530,'EXECUTED','8:7a073ed86aa75d9b9c6a070512f83d6f','addForeignKeyConstraint baseTableName=requisition_item, constraintName=FK5358E4D614F7BB8E, referencedTableName=product_group','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-536','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:35',531,'EXECUTED','8:ec04f159a32965a3e1708bfe53711504','addForeignKeyConstraint baseTableName=requisition_item, constraintName=FK5358E4D61594028E, referencedTableName=requisition_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-537','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:35',532,'EXECUTED','8:30c71dbc70d88bc0a0a485c7ef7261f5','addForeignKeyConstraint baseTableName=requisition_item, constraintName=FK5358E4D6217F5972, referencedTableName=user','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-538','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:35',533,'EXECUTED','8:a6979b76c90037df472058fc46569245','addForeignKeyConstraint baseTableName=requisition_item, constraintName=FK5358E4D629B2552E, referencedTableName=product_package','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-539','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:35',534,'EXECUTED','8:57cf6f0b560d9c42feb6036975941102','addForeignKeyConstraint baseTableName=requisition_item, constraintName=FK5358E4D6405AC22D, referencedTableName=requisition_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-540','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:36',535,'EXECUTED','8:b7f484ad24701b058788b5572d6505ee','addForeignKeyConstraint baseTableName=requisition_item, constraintName=FK5358E4D6426DD105, referencedTableName=user','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-541','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:36',536,'EXECUTED','8:5830afc7e10294ca154ffbf5e9fc4603','addForeignKeyConstraint baseTableName=requisition_item, constraintName=FK5358E4D644979D51, referencedTableName=person','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-542','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:36',537,'EXECUTED','8:62be805d777830a4ea8281b97e809153','addForeignKeyConstraint baseTableName=requisition_item, constraintName=FK5358E4D6DD302242, referencedTableName=person','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-543','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:36',538,'EXECUTED','8:e04ca83164154d63fae746c8a14f6639','addForeignKeyConstraint baseTableName=requisition_item, constraintName=FK5358E4D6F84BDE18, referencedTableName=requisition_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-544','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:36',539,'EXECUTED','8:ed2e61422b9123ed8f452dbb28f359d2','addForeignKeyConstraint baseTableName=fulfillment, constraintName=FK5A2551DEAC392B33, referencedTableName=person','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-545','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:36',540,'EXECUTED','8:a1648c2ca7359ec6db3cde137d6c8f1d','addForeignKeyConstraint baseTableName=event, constraintName=FK5C6729A3D970DB4, referencedTableName=event_type','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-546','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:36',541,'EXECUTED','8:abf654604cbc890b272f7f0b9d67d603','addForeignKeyConstraint baseTableName=event, constraintName=FK5C6729A4415A5B0, referencedTableName=location','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-547','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:36',542,'EXECUTED','8:4b7395aabb8d448aff4173e7bb64318a','addForeignKeyConstraint baseTableName=unit_of_measure_class, constraintName=FK5D1B504A217F5972, referencedTableName=user','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-548','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:36',543,'EXECUTED','8:c302c95af725240f047adce7cd67e037','addForeignKeyConstraint baseTableName=unit_of_measure_class, constraintName=FK5D1B504A426DD105, referencedTableName=user','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-549','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:36',544,'EXECUTED','8:9a57efafe2fe0efc2d8ce116a53d6bef','addForeignKeyConstraint baseTableName=unit_of_measure_class, constraintName=FK5D1B504A6B9DFD, referencedTableName=unit_of_measure','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-550','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:36',545,'EXECUTED','8:b9f8848400eb26b761950b290222f82d','addForeignKeyConstraint baseTableName=product_package, constraintName=FK615A48F6217F5972, referencedTableName=user','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-551','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:36',546,'EXECUTED','8:ffa1207a710164e97fbc3b3ca32e127d','addForeignKeyConstraint baseTableName=product_package, constraintName=FK615A48F629542386, referencedTableName=product_supplier','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-552','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:36',547,'EXECUTED','8:4306b76ee8cf0bbde942928de9473189','addForeignKeyConstraint baseTableName=product_package, constraintName=FK615A48F63906C4CF, referencedTableName=unit_of_measure','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-553','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:36',548,'EXECUTED','8:ba0cde93cd1ce82543b42bc90cb95893','addForeignKeyConstraint baseTableName=product_package, constraintName=FK615A48F6426DD105, referencedTableName=user','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-554','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:36',549,'EXECUTED','8:3eddde4c2d0647200dbe9ef4100c7459','addForeignKeyConstraint baseTableName=product_package, constraintName=FK615A48F6DED5FAE7, referencedTableName=product','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-555','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:36',550,'EXECUTED','8:35b2ba10ba969ec124c760b7fdbf4848','addForeignKeyConstraint baseTableName=order, constraintName=FK651874E1E2B3CDC, referencedTableName=location','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-556','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:36',551,'EXECUTED','8:9c96a91fa98e9ef3c266fbbf5f8842f3','addForeignKeyConstraint baseTableName=order, constraintName=FK651874E240896CB, referencedTableName=person','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-557','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:36',552,'EXECUTED','8:16c800607db7d594f9a7b907493b2610','addForeignKeyConstraint baseTableName=order, constraintName=FK651874E35D76CB0, referencedTableName=party','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-558','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:36',553,'EXECUTED','8:d9c1be004b3b83ad8c1440bb62355915','addForeignKeyConstraint baseTableName=order, constraintName=FK651874E41B7275F, referencedTableName=person','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-559','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:36',554,'EXECUTED','8:b57945852c19356342cb0d30fa3b6521','addForeignKeyConstraint baseTableName=order, constraintName=FK651874E44979D51, referencedTableName=person','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-560','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:36',555,'EXECUTED','8:f694141e6e6eac8931883a01766487c0','addForeignKeyConstraint baseTableName=order, constraintName=FK651874E6A8010C1, referencedTableName=payment_method_type','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-561','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:36',556,'EXECUTED','8:c95ce71e3d2dca3b0e590d0d79807643','addForeignKeyConstraint baseTableName=order, constraintName=FK651874E6D91063C, referencedTableName=person','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-562','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:36',557,'EXECUTED','8:be8a176b3830743a1a5847ce12f526b9','addForeignKeyConstraint baseTableName=order, constraintName=FK651874E8AF312E3, referencedTableName=order_type','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-563','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:36',558,'EXECUTED','8:59a927c9019fe7b5deaf01acf9d6cae5','addForeignKeyConstraint baseTableName=order, constraintName=FK651874E8E7F7DCF, referencedTableName=person','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-564','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:36',559,'EXECUTED','8:f4643f548385446cab1298ccfcb453b8','addForeignKeyConstraint baseTableName=order, constraintName=FK651874E9E52B00C, referencedTableName=payment_term','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-565','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:36',560,'EXECUTED','8:c2917361e0b0c1706ebe8209677231f5','addForeignKeyConstraint baseTableName=order, constraintName=FK651874EAF6D8801, referencedTableName=person','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-566','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:36',561,'EXECUTED','8:f6b02b9f62df055f01a5f8335f4cbf38','addForeignKeyConstraint baseTableName=order, constraintName=FK651874EDBDEDAC4, referencedTableName=location','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-567','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:36',562,'EXECUTED','8:2bdb8f69fbb83c4e36ff3925f7fd6e6e','addForeignKeyConstraint baseTableName=party, constraintName=FK6581AE69DFE4C4C, referencedTableName=party_type','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-568','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:36',563,'EXECUTED','8:8ffee7b02e2cb70de0619a47cf2d9ce5','addForeignKeyConstraint baseTableName=party, constraintName=FK6581AE6D1DFC6D7, referencedTableName=location','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-569','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:36',564,'EXECUTED','8:276f2154691372c13ad4b50583160ee9','addForeignKeyConstraint baseTableName=order_invoice, constraintName=FK6A1A433C3BE9D843, referencedTableName=order_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-570','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:36',565,'EXECUTED','8:f898a752de4642f3f7173b125ef1d66f','addForeignKeyConstraint baseTableName=order_invoice, constraintName=FK6A1A433CB95ED8E0, referencedTableName=invoice_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-571','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:36',566,'EXECUTED','8:8bda2779c609f27f25268170a4ac0097','addForeignKeyConstraint baseTableName=shipment_document, constraintName=FK6C5BE20C800AA15, referencedTableName=document','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-572','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:37',567,'EXECUTED','8:9a3a52ef121c48cbeb11f719ef49f00b','addForeignKeyConstraint baseTableName=shipment_event, constraintName=FK6D032BB53B350242, referencedTableName=shipment','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-573','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:37',568,'EXECUTED','8:da9321de54362f3517839eb384618659','addForeignKeyConstraint baseTableName=shipment_event, constraintName=FK6D032BB5786431F, referencedTableName=event','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-574','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:37',569,'EXECUTED','8:5bab68f50fcc9622ae642251aaf218aa','addForeignKeyConstraint baseTableName=location, constraintName=FK714F9FB528F75F00, referencedTableName=location_type','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-575','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:37',570,'EXECUTED','8:553f3ed64ec56388333e693649bcfb23','addForeignKeyConstraint baseTableName=location, constraintName=FK714F9FB53BB36E94, referencedTableName=location_group','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-576','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:37',571,'EXECUTED','8:715a1d26fb2fd3067b123940d7287703','addForeignKeyConstraint baseTableName=location, constraintName=FK714F9FB541E07A73, referencedTableName=user','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-577','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:37',572,'EXECUTED','8:14f3a279d3b4a6178fa32e6b12f7c8b6','addForeignKeyConstraint baseTableName=location, constraintName=FK714F9FB5606C7D95, referencedTableName=party','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-578','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:37',573,'EXECUTED','8:623a17c99a7e04bac58ec785a616e0b8','addForeignKeyConstraint baseTableName=location, constraintName=FK714F9FB561ED379F, referencedTableName=address','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-579','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:37',574,'EXECUTED','8:b81001b9062984bd928f36c57cb66e16','addForeignKeyConstraint baseTableName=location, constraintName=FK714F9FB572A2C5B4, referencedTableName=inventory','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-580','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:37',575,'EXECUTED','8:b63a80311fbf28f93ef8f93768062e40','addForeignKeyConstraint baseTableName=location, constraintName=FK714F9FB57AF9A3C0, referencedTableName=location','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-581','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:37',576,'EXECUTED','8:42f1e2ead1a180b6cc608eb56d9e2d7b','addForeignKeyConstraint baseTableName=unit_of_measure, constraintName=FK7348B491217F5972, referencedTableName=user','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-582','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:37',577,'EXECUTED','8:7e4117bd19fba2cf07bf57a8e922c36e','addForeignKeyConstraint baseTableName=unit_of_measure, constraintName=FK7348B491426DD105, referencedTableName=user','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-583','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:37',578,'EXECUTED','8:e1b0efc0500a2de6fbc37ecb028fa609','addForeignKeyConstraint baseTableName=unit_of_measure, constraintName=FK7348B49197D8303E, referencedTableName=unit_of_measure_class','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-584','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:37',579,'EXECUTED','8:f2e0bd6ee9dfb17d34ad31d4757a233a','addForeignKeyConstraint baseTableName=inventory_snapshot, constraintName=FK740B54769DB749D, referencedTableName=location','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-585','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:37',580,'EXECUTED','8:5da76991b19fd4edf2a06c6c9ee48a25','addForeignKeyConstraint baseTableName=inventory_snapshot, constraintName=FK740B5478ABEBD5, referencedTableName=location','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-586','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:37',581,'EXECUTED','8:8174eb15dc128a81443a08343d0254a4','addForeignKeyConstraint baseTableName=inventory_snapshot, constraintName=FK740B547AA992CED, referencedTableName=inventory_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-587','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:37',582,'EXECUTED','8:83a94c20e3910235eca83fa398c51901','addForeignKeyConstraint baseTableName=inventory_snapshot, constraintName=FK740B547DED5FAE7, referencedTableName=product','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-588','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:37',583,'EXECUTED','8:6033221c81b18ec94e9a1306342f52af','addForeignKeyConstraint baseTableName=order_event, constraintName=FK74D92A693D2E628A, referencedTableName=order','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-589','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:37',584,'EXECUTED','8:4a0e79eea52a370b70b4f15939dfb4c1','addForeignKeyConstraint baseTableName=order_event, constraintName=FK74D92A69786431F, referencedTableName=event','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-590','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:37',585,'EXECUTED','8:785bdf8c1cd6155b1b651e53a39c2f37','addForeignKeyConstraint baseTableName=local_transfer, constraintName=FK7975323F4CC49445, referencedTableName=transaction','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-591','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:37',586,'EXECUTED','8:728d0734f09ab7567b7ddc981328f420','addForeignKeyConstraint baseTableName=local_transfer, constraintName=FK7975323F57563498, referencedTableName=transaction','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-592','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:37',587,'EXECUTED','8:83ff599fb65d28774c21ead232e887c9','addForeignKeyConstraint baseTableName=location_group, constraintName=FK7A19D7561ED379F, referencedTableName=address','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-593','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:37',588,'EXECUTED','8:4c0efee63ccf1f3f286698a596188bd2','addForeignKeyConstraint baseTableName=location_type_supported_activities, constraintName=FK7AFF67F928F75F00, referencedTableName=location_type','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-594','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:37',589,'EXECUTED','8:d9d7a059c5e69b0e07598c77dcf43cda','addForeignKeyConstraint baseTableName=transaction, constraintName=FK7FA0D2DE1E2B3CDC, referencedTableName=location','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-595','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:37',590,'EXECUTED','8:6e52505a2c0e5e1f8512c69296fd5538','addForeignKeyConstraint baseTableName=transaction, constraintName=FK7FA0D2DE217F5972, referencedTableName=user','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-596','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:37',591,'EXECUTED','8:dd94796cbb69509394f33d4eeee6fdf9','addForeignKeyConstraint baseTableName=transaction, constraintName=FK7FA0D2DE3265A8A9, referencedTableName=user','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-597','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:37',592,'EXECUTED','8:817a58d6885f063e867383fe1d703d8f','addForeignKeyConstraint baseTableName=transaction, constraintName=FK7FA0D2DE426DD105, referencedTableName=user','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-598','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:37',593,'EXECUTED','8:528c56c715e4a44b3de6b71cd5d9cbfe','addForeignKeyConstraint baseTableName=transaction, constraintName=FK7FA0D2DE5DE9E374, referencedTableName=requisition','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-599','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:37',594,'EXECUTED','8:f71c126b4c983be200200b72a176d2c1','addForeignKeyConstraint baseTableName=transaction, constraintName=FK7FA0D2DE5F12AFED, referencedTableName=shipment','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-600','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:37',595,'EXECUTED','8:9ec1267d055fc013a7f494d595d0c82d','addForeignKeyConstraint baseTableName=transaction, constraintName=FK7FA0D2DE72A2C5B4, referencedTableName=inventory','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-601','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:37',596,'EXECUTED','8:b2b997316e50315584a9aa293c1046f4','addForeignKeyConstraint baseTableName=transaction, constraintName=FK7FA0D2DE828481AF, referencedTableName=location','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-602','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:37',597,'EXECUTED','8:ea352e8e4cd6beca6a000747879c5d9a','addForeignKeyConstraint baseTableName=transaction, constraintName=FK7FA0D2DEB3FB7111, referencedTableName=transaction_type','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-603','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:37',598,'EXECUTED','8:52efb923598da6d589b5e5fc9c74f8cf','addForeignKeyConstraint baseTableName=transaction, constraintName=FK7FA0D2DEB80B3233, referencedTableName=shipment','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-604','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:37',599,'EXECUTED','8:096159f4f2fca03ae147bd4798ada8fa','addForeignKeyConstraint baseTableName=transaction, constraintName=FK7FA0D2DED08EDBE6, referencedTableName=order','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-605','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:38',600,'EXECUTED','8:f2564603c0335a5e1c4adcce231b07cd','addForeignKeyConstraint baseTableName=transaction, constraintName=FK7FA0D2DEF7076438, referencedTableName=receipt','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-606','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:38',601,'EXECUTED','8:6c4ca2b8c4c21110a0b3214bb5d0c91c','addForeignKeyConstraint baseTableName=transaction_type_dimension, constraintName=FK7FA87A22B3FB7111, referencedTableName=transaction_type','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-607','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:38',602,'EXECUTED','8:866efeccc3c057cb2c6ae57a281f0f9e','addForeignKeyConstraint baseTableName=order_shipment, constraintName=FK9475736B3BE9D843, referencedTableName=order_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-608','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:38',603,'EXECUTED','8:7d6f544ce9997bb165725f142b8972e0','addForeignKeyConstraint baseTableName=order_shipment, constraintName=FK9475736BB06EC4FB, referencedTableName=shipment_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-609','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:38',604,'EXECUTED','8:218f2d38d87a6bc94ce37869c51faeb1','addForeignKeyConstraint baseTableName=product_attribute, constraintName=FK94A534C24DEBC91, referencedTableName=unit_of_measure','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-610','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:38',605,'EXECUTED','8:c0f91cf3380479216c193f474ca3096f','addForeignKeyConstraint baseTableName=product_attribute, constraintName=FK94A534C29542386, referencedTableName=product_supplier','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-611','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:38',606,'EXECUTED','8:6999763c00a5615d02f382c54c4ba6e1','addForeignKeyConstraint baseTableName=product_attribute, constraintName=FK94A534C47B0D087, referencedTableName=attribute','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-612','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:38',607,'EXECUTED','8:2aa56345ae51a8c28428c38c83adac59','addForeignKeyConstraint baseTableName=product_attribute, constraintName=FK94A534CDED5FAE7, referencedTableName=product','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-613','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:38',608,'EXECUTED','8:42e7887a1e58826d856348f252ae52b4','addForeignKeyConstraint baseTableName=synonym, constraintName=FK98293BFB217F5972, referencedTableName=user','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-614','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:38',609,'EXECUTED','8:c52b3118a5252a488c48f89754c09780','addForeignKeyConstraint baseTableName=synonym, constraintName=FK98293BFB426DD105, referencedTableName=user','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-615','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:38',610,'EXECUTED','8:a44c9ee871fb961858793d6e58f82191','addForeignKeyConstraint baseTableName=shipment_workflow_document, constraintName=FK9A945A36C800AA15, referencedTableName=document','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-616','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:38',611,'EXECUTED','8:b751bc4c871342a5f7642cd1d8335bda','addForeignKeyConstraint baseTableName=shipment_workflow_document, constraintName=FK9A945A36EC587CFB, referencedTableName=shipment_workflow','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-617','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:38',612,'EXECUTED','8:c7c7a41fcc8dc31e605dacdc1385e9bc','addForeignKeyConstraint baseTableName=product_category, constraintName=FKA0303E4EEF4C770D, referencedTableName=category','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-618','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:38',613,'EXECUTED','8:7b42bfc11245bb6d054e3c49bcd3d8e0','addForeignKeyConstraint baseTableName=product_tag, constraintName=FKA71CAC4A9740C85F, referencedTableName=tag','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-619','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:38',614,'EXECUTED','8:78d24c9877e2b13f6dbc830c75acc01e','addForeignKeyConstraint baseTableName=product_tag, constraintName=FKA71CAC4ADED5FAE7, referencedTableName=product','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-620','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:38',615,'EXECUTED','8:3b31401f7a2f7dc6c869fe3960d0cbe6','addForeignKeyConstraint baseTableName=consumption_fact, constraintName=FKA8B7A49072882836, referencedTableName=product_dimension','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-621','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:38',616,'EXECUTED','8:96f44ec7d9d81497824db8383fc42c9e','addForeignKeyConstraint baseTableName=consumption_fact, constraintName=FKA8B7A490A27827C2, referencedTableName=location_dimension','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-622','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:38',617,'EXECUTED','8:cae268102a1a70cf3341aef3c3f0c4b3','addForeignKeyConstraint baseTableName=consumption_fact, constraintName=FKA8B7A490CA32CFEF, referencedTableName=date_dimension','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-623','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:38',618,'EXECUTED','8:fe0af9d5f2fa662fcf22baa0ee3fd22e','addForeignKeyConstraint baseTableName=consumption_fact, constraintName=FKA8B7A490D1F27172, referencedTableName=lot_dimension','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-624','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:38',619,'EXECUTED','8:852369cfa83ba12969db7012975dc638','addForeignKeyConstraint baseTableName=transaction_entry, constraintName=FKABC21FD12EF4C7F4, referencedTableName=transaction','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-625','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:38',620,'EXECUTED','8:e03f326154aa82269bd1660bad70b871','addForeignKeyConstraint baseTableName=transaction_entry, constraintName=FKABC21FD169DB749D, referencedTableName=location','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-626','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:38',621,'EXECUTED','8:571de2e91b95802cfe755ef16ba37c28','addForeignKeyConstraint baseTableName=transaction_entry, constraintName=FKABC21FD1AA992CED, referencedTableName=inventory_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-627','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:38',622,'EXECUTED','8:e979df0abec564d3cef11f3c48e8f819','addForeignKeyConstraint baseTableName=transaction_entry, constraintName=FKABC21FD1DED5FAE7, referencedTableName=product','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-628','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:38',623,'EXECUTED','8:dbfe9049df29fff660ca42099a18c5a9','addForeignKeyConstraint baseTableName=receipt_item, constraintName=FKAE3064BA44979D51, referencedTableName=person','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-629','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:38',624,'EXECUTED','8:99cbe33c20df0bc90a014d9728ccd86d','addForeignKeyConstraint baseTableName=receipt_item, constraintName=FKAE3064BA69DB749D, referencedTableName=location','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-630','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:38',625,'EXECUTED','8:90de32fd8c4f7bd0e7728d14834f1655','addForeignKeyConstraint baseTableName=receipt_item, constraintName=FKAE3064BAAA992CED, referencedTableName=inventory_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-631','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:38',626,'EXECUTED','8:16a6de8270cb3905a6913660d95df92c','addForeignKeyConstraint baseTableName=receipt_item, constraintName=FKAE3064BAB06EC4FB, referencedTableName=shipment_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-632','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:38',627,'EXECUTED','8:a6d1c2572a0c3798c6d284a398139d3d','addForeignKeyConstraint baseTableName=receipt_item, constraintName=FKAE3064BADED5FAE7, referencedTableName=product','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-633','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:38',628,'EXECUTED','8:b3df62bcbf8f4f2694f928e3a39ddeea','addForeignKeyConstraint baseTableName=receipt_item, constraintName=FKAE3064BAF7076438, referencedTableName=receipt','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-634','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:38',629,'EXECUTED','8:a63aaf42f03c6084431075d9aa956277','addForeignKeyConstraint baseTableName=product_component, constraintName=FKB511C5AD20E351EA, referencedTableName=product','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-635','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:38',630,'EXECUTED','8:d29723b28e9a1e1500b7860a1c50be6c','addForeignKeyConstraint baseTableName=product_component, constraintName=FKB511C5AD24DEBC91, referencedTableName=unit_of_measure','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-636','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:38',631,'EXECUTED','8:762ebb3d8d5935e1b87abaecfb818d7a','addForeignKeyConstraint baseTableName=product_component, constraintName=FKB511C5ADFB4C199C, referencedTableName=product','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-637','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:38',632,'EXECUTED','8:f7851d23c0a5b00a0bda904dd5c62655','addForeignKeyConstraint baseTableName=inventory_item_snapshot, constraintName=FKBD34ABCD8ABEBD5, referencedTableName=location','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-638','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:38',633,'EXECUTED','8:3650cab349ea8fada86c3708b2e8adfd','addForeignKeyConstraint baseTableName=inventory_item_snapshot, constraintName=FKBD34ABCDAA992CED, referencedTableName=inventory_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-639','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:38',634,'EXECUTED','8:1d9a0afd0ac04d9d1dabd497ecd6c77c','addForeignKeyConstraint baseTableName=inventory_item_snapshot, constraintName=FKBD34ABCDDED5FAE7, referencedTableName=product','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-640','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:38',635,'EXECUTED','8:36830252ce023ae4fce54cd1aa2b00e8','addForeignKeyConstraint baseTableName=inventory_level, constraintName=FKC254A2E16CDADD53, referencedTableName=location','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-641','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:38',636,'EXECUTED','8:c80c1074943af37f0172ffd919f17984','addForeignKeyConstraint baseTableName=inventory_level, constraintName=FKC254A2E172A2C5B4, referencedTableName=inventory','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-642','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:38',637,'EXECUTED','8:cbfbb01fe249c2b0c07014f6ef2896c1','addForeignKeyConstraint baseTableName=inventory_level, constraintName=FKC254A2E1CFDCB4DF, referencedTableName=location','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-643','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:39',638,'EXECUTED','8:f2868c20e250bc45ffeb40e982f6d39b','addForeignKeyConstraint baseTableName=inventory_level, constraintName=FKC254A2E1DED5FAE7, referencedTableName=product','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-644','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:39',639,'EXECUTED','8:47d28fadd86f1c3db1679fdd75a5dc5b','addForeignKeyConstraint baseTableName=inventory_level, constraintName=FKC254A2E1F07D879A, referencedTableName=location','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-645','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:39',640,'EXECUTED','8:d83e65db7ba8b629877d13b05b10913d','addForeignKeyConstraint baseTableName=shipment_comment, constraintName=FKC398CCBAC4A49BBF, referencedTableName=comment','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-646','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:39',641,'EXECUTED','8:8692153e477806e8c5c1212f9e86b4e7','addForeignKeyConstraint baseTableName=product_dimension, constraintName=FKC73E1616DED5FAE7, referencedTableName=product','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-647','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:39',642,'EXECUTED','8:8fa48f951313209c48a77602fd7c7b65','addForeignKeyConstraint baseTableName=attribute, constraintName=FKC7AA9C4013CE80, referencedTableName=unit_of_measure_class','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-648','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:39',643,'EXECUTED','8:fb457473eaef715b34efc7eaa3599906','addForeignKeyConstraint baseTableName=consumption, constraintName=FKCD71F39B8ABEBD5, referencedTableName=location','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-649','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:39',644,'EXECUTED','8:73931a803d84f0e152074db5b461fd82','addForeignKeyConstraint baseTableName=consumption, constraintName=FKCD71F39BAA992CED, referencedTableName=inventory_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-650','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:39',645,'EXECUTED','8:6a342194db27ca58a23193ccd0a6540a','addForeignKeyConstraint baseTableName=consumption, constraintName=FKCD71F39BDED5FAE7, referencedTableName=product','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-651','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:39',646,'EXECUTED','8:f71f41279ee5ee16acfbf47065fda880','addForeignKeyConstraint baseTableName=product_document, constraintName=FKD08A526BC800AA15, referencedTableName=document','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-652','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:39',647,'EXECUTED','8:5e097a304815a8c4eb397c6dbc4f7619','addForeignKeyConstraint baseTableName=product_document, constraintName=FKD08A526BDED5FAE7, referencedTableName=product','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-653','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:39',648,'EXECUTED','8:5ac593520801e5e275505274c5282803','addForeignKeyConstraint baseTableName=lot_dimension, constraintName=FKD2EAD9F8AA992CED, referencedTableName=inventory_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-654','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:39',649,'EXECUTED','8:00ef3264d16d8db168333290e0612e39','addForeignKeyConstraint baseTableName=picklist, constraintName=FKD3F8383F217F5972, referencedTableName=user','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-655','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:39',650,'EXECUTED','8:82697ce69ecab095cec5e39d7bbb8b74','addForeignKeyConstraint baseTableName=picklist, constraintName=FKD3F8383F426DD105, referencedTableName=user','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-656','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:39',651,'EXECUTED','8:63ef270a42c4404f7686e6abf7056d90','addForeignKeyConstraint baseTableName=picklist, constraintName=FKD3F8383F5DE9E374, referencedTableName=requisition','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-657','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:39',652,'EXECUTED','8:30def295d4aa5ee5320ee3494de399e9','addForeignKeyConstraint baseTableName=picklist, constraintName=FKD3F8383FA3E976BC, referencedTableName=person','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-658','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:39',653,'EXECUTED','8:3020aac071f0ca3faa977bc57ab2875f','addForeignKeyConstraint baseTableName=product_availability, constraintName=FKD3FC6EAB69DB749D, referencedTableName=location','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-659','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:39',654,'EXECUTED','8:b75e5b00f03bc219c9e2b2b731c9f4f4','addForeignKeyConstraint baseTableName=product_availability, constraintName=FKD3FC6EAB8ABEBD5, referencedTableName=location','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-660','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:39',655,'EXECUTED','8:4b77d5c21397407f43e7fc76b8ae5923','addForeignKeyConstraint baseTableName=product_availability, constraintName=FKD3FC6EABAA992CED, referencedTableName=inventory_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-661','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:39',656,'EXECUTED','8:61b17aebf7c986cbe39d3187d5c2ef38','addForeignKeyConstraint baseTableName=product_availability, constraintName=FKD3FC6EABDED5FAE7, referencedTableName=product','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-662','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:39',657,'EXECUTED','8:944bad21ee2179387d2d719a90869938','addForeignKeyConstraint baseTableName=shipment_workflow, constraintName=FKD584C4C4FF77FF9B, referencedTableName=shipment_type','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-663','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:39',658,'EXECUTED','8:769ce8b74c21bd92ee8101e4d2e3d1c4','addForeignKeyConstraint baseTableName=reference_number, constraintName=FKD790DEBD154F600, referencedTableName=reference_number_type','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-664','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:39',659,'EXECUTED','8:6feada7c28d5b12993f98c9ba3a3a115','addForeignKeyConstraint baseTableName=shipment_item, constraintName=FKDA3BB2981CD3412D, referencedTableName=requisition_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-665','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:39',660,'EXECUTED','8:8ea69c2e00db12e48482229d3a532bac','addForeignKeyConstraint baseTableName=shipment_item, constraintName=FKDA3BB2983B5F6286, referencedTableName=shipment','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-666','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:39',661,'EXECUTED','8:862f941ea46fc9bae88ad5159feab193','addForeignKeyConstraint baseTableName=shipment_item, constraintName=FKDA3BB29844979D51, referencedTableName=person','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-667','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:39',662,'EXECUTED','8:635d785fa258800f64283686c7ff380f','addForeignKeyConstraint baseTableName=shipment_item, constraintName=FKDA3BB29849AB6B52, referencedTableName=donor','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-668','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:39',663,'EXECUTED','8:d68e90493afea3408ba7cbd7a41c7587','addForeignKeyConstraint baseTableName=shipment_item, constraintName=FKDA3BB29869DB749D, referencedTableName=location','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-669','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:39',664,'EXECUTED','8:dd0f27f1c7b095277af43d523b9ea641','addForeignKeyConstraint baseTableName=shipment_item, constraintName=FKDA3BB2987400E88E, referencedTableName=container','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-670','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:39',665,'EXECUTED','8:18024f6c891f91fdfe36b004800bfcb1','addForeignKeyConstraint baseTableName=shipment_item, constraintName=FKDA3BB298AA992CED, referencedTableName=inventory_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-671','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:39',666,'EXECUTED','8:17de652e1a44bb89ff53cde15d8813ca','addForeignKeyConstraint baseTableName=shipment_item, constraintName=FKDA3BB298DED5FAE7, referencedTableName=product','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-672','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:39',667,'EXECUTED','8:e4edd212a42b221b67a37fb59c288f43','addForeignKeyConstraint baseTableName=shipment_workflow_container_type, constraintName=FKDEF5AD1317A6E251, referencedTableName=container_type','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-673','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:39',668,'EXECUTED','8:a8622d5fd40fde893b0c7f676c597658','addForeignKeyConstraint baseTableName=shipper_service, constraintName=FKDF7559D73896C98E, referencedTableName=shipper','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-674','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:39',669,'EXECUTED','8:edd4c43f3c85ebcdd9816e8dc0d2394f','addForeignKeyConstraint baseTableName=fulfillment_item_shipment_item, constraintName=FKE071DE6DB06EC4FB, referencedTableName=shipment_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-675','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:39',670,'EXECUTED','8:37a486ca1358a758b56153f713e8ee7f','addForeignKeyConstraint baseTableName=fulfillment_item_shipment_item, constraintName=FKE071DE6DB42751E1, referencedTableName=fulfillment_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-676','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:39',671,'EXECUTED','8:32e5bdd0a7d990c6ccf52a0464c995e7','addForeignKeyConstraint baseTableName=shipment, constraintName=FKE139719A1E2B3CDC, referencedTableName=location','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-677','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:39',672,'EXECUTED','8:17dad61571c10eb824b61b0abc1b0665','addForeignKeyConstraint baseTableName=shipment, constraintName=FKE139719A217F5972, referencedTableName=user','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-678','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:40',673,'EXECUTED','8:1533d14820d0e34fc217ed721e66933c','addForeignKeyConstraint baseTableName=shipment, constraintName=FKE139719A294C1012, referencedTableName=person','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-679','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:40',674,'EXECUTED','8:edd87d52e9da652fbe53f32d907d0333','addForeignKeyConstraint baseTableName=shipment, constraintName=FKE139719A426DD105, referencedTableName=user','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-680','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:40',675,'EXECUTED','8:5c2b3cbbbf0189035307482434226ef1','addForeignKeyConstraint baseTableName=shipment, constraintName=FKE139719A44979D51, referencedTableName=person','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-681','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:40',676,'EXECUTED','8:e5b99b2824c9e1b638bcf6153654b3ab','addForeignKeyConstraint baseTableName=shipment, constraintName=FKE139719A49AB6B52, referencedTableName=donor','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-682','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:40',677,'EXECUTED','8:99b795e738486026ba86109effd86f77','addForeignKeyConstraint baseTableName=shipment, constraintName=FKE139719A5DE9E374, referencedTableName=requisition','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-683','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:40',678,'EXECUTED','8:89343f49900e1e257a30911f8c64a7a7','addForeignKeyConstraint baseTableName=shipment, constraintName=FKE139719AA28CC5FB, referencedTableName=shipment_method','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-684','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:40',679,'EXECUTED','8:7f6df3685331398fc14caa642a35f5ec','addForeignKeyConstraint baseTableName=shipment, constraintName=FKE139719AD95ACF25, referencedTableName=event','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-685','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:40',680,'EXECUTED','8:aa2d9d670be01099c94855026ea9e16d','addForeignKeyConstraint baseTableName=shipment, constraintName=FKE139719ADBDEDAC4, referencedTableName=location','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-686','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:40',681,'EXECUTED','8:a79a799bf1ef752a0aa0a4cc87c7d358','addForeignKeyConstraint baseTableName=shipment, constraintName=FKE139719AFF77FF9B, referencedTableName=shipment_type','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-687','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:40',682,'EXECUTED','8:4522650df8cd4e1228d7be1f88b4d634','addForeignKeyConstraint baseTableName=order_document, constraintName=FKE698D2ECC800AA15, referencedTableName=document','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-688','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:40',683,'EXECUTED','8:aed6ce981212dcf445d254e299792572','addForeignKeyConstraint baseTableName=order_document, constraintName=FKE698D2ECFE10118D, referencedTableName=order','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-689','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:40',684,'EXECUTED','8:faa2b0c5b12a03a828a67e1124cfd0ba','addForeignKeyConstraint baseTableName=picklist_item, constraintName=FKE7584B1369DB749D, referencedTableName=location','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-690','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:40',685,'EXECUTED','8:bd56c18a7475e21295a550f18e12c51d','addForeignKeyConstraint baseTableName=container, constraintName=FKE7814C8117A6E251, referencedTableName=container_type','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-691','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:40',686,'EXECUTED','8:6cf32d00fffb1814f886f6846f963bc4','addForeignKeyConstraint baseTableName=container, constraintName=FKE7814C813B5F6286, referencedTableName=shipment','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-692','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:40',687,'EXECUTED','8:affcf3352b76b5f5c277326d0af12123','addForeignKeyConstraint baseTableName=container, constraintName=FKE7814C8144979D51, referencedTableName=person','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-693','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:40',688,'EXECUTED','8:fe0724ba9245349dc0de33ee2993de7e','addForeignKeyConstraint baseTableName=container, constraintName=FKE7814C814B6A2E03, referencedTableName=container','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-694','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:40',689,'EXECUTED','8:73bce96dadacaeac840049bb2d121e40','addForeignKeyConstraint baseTableName=product_association, constraintName=FKED441931C8653BC0, referencedTableName=product','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-695','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:40',690,'EXECUTED','8:5628651a6c08dadb4ad7b70ac41bc867','addForeignKeyConstraint baseTableName=product_association, constraintName=FKED441931DED5FAE7, referencedTableName=product','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-696','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:40',691,'EXECUTED','8:f818dcdc063457ca8d49af550f0fd0af','addForeignKeyConstraint baseTableName=product, constraintName=FKED8DCCEF217F5972, referencedTableName=user','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-697','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:40',692,'EXECUTED','8:f7ad6350a8d7c5ebcba3da6c0388ba28','addForeignKeyConstraint baseTableName=product, constraintName=FKED8DCCEF426DD105, referencedTableName=user','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-698','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:40',693,'EXECUTED','8:0b392ac6df2495bd0995af9f9903a602','addForeignKeyConstraint baseTableName=product, constraintName=FKED8DCCEFABD88AC6, referencedTableName=product_type','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-699','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:40',694,'EXECUTED','8:6128d4475c783a0f5b26db76bf6da245','addForeignKeyConstraint baseTableName=product, constraintName=FKED8DCCEFEEB2908D, referencedTableName=unit_of_measure','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-700','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:40',695,'EXECUTED','8:ba56e67780315814f0e877dfa8b00331','addForeignKeyConstraint baseTableName=product, constraintName=FKED8DCCEFEF4C770D, referencedTableName=category','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-701','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:40',696,'EXECUTED','8:f6b1bd69efc0eb1a3f73c2c2118733ee','addForeignKeyConstraint baseTableName=fulfillment_item, constraintName=FKEDC55CD447EBE106, referencedTableName=requisition_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-702','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:40',697,'EXECUTED','8:1fcf2c1dbfbc91b9f4dae57cd787045f','addForeignKeyConstraint baseTableName=fulfillment_item, constraintName=FKEDC55CD494567276, referencedTableName=fulfillment','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-703','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:40',698,'EXECUTED','8:4a4f7880a2edc0eaaa19eb6d172a7b05','addForeignKeyConstraint baseTableName=fulfillment_item, constraintName=FKEDC55CD4AA992CED, referencedTableName=inventory_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-704','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:40',699,'EXECUTED','8:7911a3ee6130fc2330864caff9439a90','addForeignKeyConstraint baseTableName=location_supported_activities, constraintName=FKF58372688ABEBD5, referencedTableName=location','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-706','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:41',700,'EXECUTED','8:a338e8a051fb5da60b163dbfbde62595','addForeignKeyConstraint baseTableName=inventory_item, constraintName=FKFE019416DED5FAE7, referencedTableName=product','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-707','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:41',701,'EXECUTED','8:537376e4f070c593583296a85434790d','addForeignKeyConstraint baseTableName=budget_code, constraintName=fk_budget_code_created_by, referencedTableName=user','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-708','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:41',702,'EXECUTED','8:891eccc8c68d86814c0b993053f246fe','addForeignKeyConstraint baseTableName=budget_code, constraintName=fk_budget_code_organization, referencedTableName=party','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-709','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:41',703,'EXECUTED','8:990aea75669b9a65acee05ed207adf0c','addForeignKeyConstraint baseTableName=budget_code, constraintName=fk_budget_code_updated_by, referencedTableName=user','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-710','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:41',704,'EXECUTED','8:302d366b1123cb3d4cdb09c926f175fb','addForeignKeyConstraint baseTableName=category, constraintName=fk_category_gl_account, referencedTableName=gl_account','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-711','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:41',705,'EXECUTED','8:ee725aa0360a53eb0d13f32d83637ab7','addForeignKeyConstraint baseTableName=event, constraintName=fk_event_comment, referencedTableName=comment','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-712','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:41',706,'EXECUTED','8:30707a670b059225b0d4c34f6e7f8e6a','addForeignKeyConstraint baseTableName=event, constraintName=fk_event_created_by, referencedTableName=user','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-713','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:41',707,'EXECUTED','8:3da51d60b2f0ceb805d400c96c70cfb6','addForeignKeyConstraint baseTableName=gl_account, constraintName=fk_gl_account_created_by, referencedTableName=user','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-714','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:41',708,'EXECUTED','8:9c18d13c2c9e4d964e400e6f02927f53','addForeignKeyConstraint baseTableName=gl_account, constraintName=fk_gl_account_gl_account_type, referencedTableName=gl_account_type','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-715','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:41',709,'EXECUTED','8:4168d7da696da15b06b608badfac48a6','addForeignKeyConstraint baseTableName=gl_account_type, constraintName=fk_gl_account_type_created_by, referencedTableName=user','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-716','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:41',710,'EXECUTED','8:20b7a97d31ba30958f7d58b6505f13d4','addForeignKeyConstraint baseTableName=gl_account_type, constraintName=fk_gl_account_type_updated_by, referencedTableName=user','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-717','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:41',711,'EXECUTED','8:0561ab65451fec506b652136ef15ed33','addForeignKeyConstraint baseTableName=gl_account, constraintName=fk_gl_account_updated_by, referencedTableName=user','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-718','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:41',712,'EXECUTED','8:39726e8531a26237b2ddcd61ba2db1c5','addForeignKeyConstraint baseTableName=invoice, constraintName=fk_invoice_created_by, referencedTableName=user','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-719','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:41',713,'EXECUTED','8:2cff6f3310d6dd0007e1596e6c764603','addForeignKeyConstraint baseTableName=invoice, constraintName=fk_invoice_currency_uom, referencedTableName=unit_of_measure','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-720','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:41',714,'EXECUTED','8:8d167ca8935295ab0cc898c067311ede','addForeignKeyConstraint baseTableName=invoice_document, constraintName=fk_invoice_document_document, referencedTableName=document','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-721','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:41',715,'EXECUTED','8:9ed3f119ff5ca92e0b10b713710ef1d6','addForeignKeyConstraint baseTableName=invoice_document, constraintName=fk_invoice_document_invoice, referencedTableName=invoice','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-722','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:41',716,'EXECUTED','8:8715b89c2bcd30ad595cd4341b11252f','addForeignKeyConstraint baseTableName=invoice, constraintName=fk_invoice_invoice_type, referencedTableName=invoice_type','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-723','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:41',717,'EXECUTED','8:3ec9ace8127b05334d845347df89a784','addForeignKeyConstraint baseTableName=invoice_item, constraintName=fk_invoice_item_budget_code, referencedTableName=budget_code','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-724','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:41',718,'EXECUTED','8:caea9e6fa8ec1513d9a95d96aeff62a7','addForeignKeyConstraint baseTableName=invoice_item, constraintName=fk_invoice_item_created_by, referencedTableName=user','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-725','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:41',719,'EXECUTED','8:76d2fed6bf8d97ee2b8e83bcef2032f9','addForeignKeyConstraint baseTableName=invoice_item, constraintName=fk_invoice_item_gl_account, referencedTableName=gl_account','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-726','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:41',720,'EXECUTED','8:1160760afc3f878ad6309ae115a25edf','addForeignKeyConstraint baseTableName=invoice_item, constraintName=fk_invoice_item_invoice, referencedTableName=invoice','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-727','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:41',721,'EXECUTED','8:46dd0eb8418446b8f0a974a7133c4163','addForeignKeyConstraint baseTableName=invoice_item, constraintName=fk_invoice_item_product, referencedTableName=product','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-728','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:41',722,'EXECUTED','8:6123ef0c85730abb1d596999504bb46e','addForeignKeyConstraint baseTableName=invoice_item, constraintName=fk_invoice_item_quantity_uom, referencedTableName=unit_of_measure','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-729','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:41',723,'EXECUTED','8:fbe42192cde3345ae7448bd5c8743a6a','addForeignKeyConstraint baseTableName=invoice_item, constraintName=fk_invoice_item_updated_by, referencedTableName=user','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-730','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:41',724,'EXECUTED','8:c729c65d3e06ac0bcf429ce56c5dd887','addForeignKeyConstraint baseTableName=invoice, constraintName=fk_invoice_party, referencedTableName=party','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-731','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:41',725,'EXECUTED','8:15b2e696c9ddc76f2e13a44d236ede6a','addForeignKeyConstraint baseTableName=invoice, constraintName=fk_invoice_party_from, referencedTableName=party','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-732','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:41',726,'EXECUTED','8:a5eed2a093d4b45c7f4f421866f827bd','addForeignKeyConstraint baseTableName=invoice_reference_number, constraintName=fk_invoice_reference_number_invoice_id, referencedTableName=invoice','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-733','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:41',727,'EXECUTED','8:a4f26b6f9773083c3908a834e79e2e24','addForeignKeyConstraint baseTableName=invoice_reference_number, constraintName=fk_invoice_reference_number_reference_number_id, referencedTableName=reference_number','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-734','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:42',728,'EXECUTED','8:571ebab09d0253e50c36a5d500347eaf','addForeignKeyConstraint baseTableName=invoice_type, constraintName=fk_invoice_type_created_by, referencedTableName=user','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-735','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:42',729,'EXECUTED','8:a3b1d674a4e98f7149552c71a4c61b37','addForeignKeyConstraint baseTableName=invoice_type, constraintName=fk_invoice_type_updated_by, referencedTableName=user','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-736','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:42',730,'EXECUTED','8:ed6ad8a56aa2ed6ef08fd0d001f000b2','addForeignKeyConstraint baseTableName=invoice, constraintName=fk_invoice_updated_by, referencedTableName=user','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-737','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:42',731,'EXECUTED','8:fcdeaac24b9bb45b204371301a40233f','addForeignKeyConstraint baseTableName=order_adjustment, constraintName=fk_order_adjustment_budget_code, referencedTableName=budget_code','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-738','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:42',732,'EXECUTED','8:b5716789534cb6f938d544c371159333','addForeignKeyConstraint baseTableName=order_adjustment, constraintName=fk_order_adjustment_gl_account, referencedTableName=gl_account','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-739','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:42',733,'EXECUTED','8:e88b346f27e4817dcdaa21f04c0e1e52','addForeignKeyConstraint baseTableName=order_adjustment_type, constraintName=fk_order_adjustment_type_gl_account, referencedTableName=gl_account','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-740','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:42',734,'EXECUTED','8:1b44ff20d2cc270d114ac6e301debcf0','addForeignKeyConstraint baseTableName=order_item, constraintName=fk_order_item_budget_code, referencedTableName=budget_code','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-741','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:42',735,'EXECUTED','8:ebb20a6e3c970b52939d23ec176971c2','addForeignKeyConstraint baseTableName=order_item, constraintName=fk_order_item_gl_account, referencedTableName=gl_account','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-742','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:42',736,'EXECUTED','8:9bbf2d039af717bd501395c12460793d','addForeignKeyConstraint baseTableName=order_type, constraintName=fk_order_type_created_by, referencedTableName=user','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-743','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:42',737,'EXECUTED','8:407f4151ffe2a1a867616ddb82b81235','addForeignKeyConstraint baseTableName=order_type, constraintName=fk_order_type_updated_by, referencedTableName=user','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-744','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:42',738,'EXECUTED','8:c4d18a6c6a3a6452cec7e9ff2646726a','addForeignKeyConstraint baseTableName=picklist_item, constraintName=fk_picklist_item_order_item, referencedTableName=order_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-745','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:42',739,'EXECUTED','8:2e68f8d8621fe0cb570d975a314ba688','addForeignKeyConstraint baseTableName=picklist, constraintName=fk_picklist_order, referencedTableName=order','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-746','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:42',740,'EXECUTED','8:9747b9f714d88bf6ac0a6ef8cf138eb9','addForeignKeyConstraint baseTableName=preference_type, constraintName=fk_preference_type_created_by, referencedTableName=user','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-747','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:42',741,'EXECUTED','8:468275cbf4669e0e52c3f4ef0f8b8e9e','addForeignKeyConstraint baseTableName=preference_type, constraintName=fk_preference_type_updated_by, referencedTableName=user','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-748','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:42',742,'EXECUTED','8:2b34be35d78fb67413840ce62c4c6ec2','addForeignKeyConstraint baseTableName=product_association, constraintName=fk_product_association_mutual_association, referencedTableName=product_association','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-749','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:42',743,'EXECUTED','8:99c6b25b5fe54fcaa7d2b78ff9078945','addForeignKeyConstraint baseTableName=product, constraintName=fk_product_gl_account, referencedTableName=gl_account','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-750','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:42',744,'EXECUTED','8:f140f08b943124559d6bd7ac12b04d39','addForeignKeyConstraint baseTableName=product_merge_logger, constraintName=fk_product_merge_logger_created_by, referencedTableName=user','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-751','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:42',745,'EXECUTED','8:9f653c6cfc0ff25fc3fa23096533c202','addForeignKeyConstraint baseTableName=product_merge_logger, constraintName=fk_product_merge_logger_obsolete_product, referencedTableName=product','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-752','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:43',746,'EXECUTED','8:53fcc0c50bef8ef166889c93d0dc87e0','addForeignKeyConstraint baseTableName=product_merge_logger, constraintName=fk_product_merge_logger_primary_product, referencedTableName=product','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-753','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:43',747,'EXECUTED','8:0c48de442774b7d1b762035f6de6c815','addForeignKeyConstraint baseTableName=product_merge_logger, constraintName=fk_product_merge_logger_updated_by, referencedTableName=user','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-754','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:43',748,'EXECUTED','8:cf5daca2059335bb6ed683bc735f4a28','addForeignKeyConstraint baseTableName=product_price, constraintName=fk_product_price_created_by, referencedTableName=user','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-755','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:43',749,'EXECUTED','8:67e64fe4eb353650e8f82e3c99381b9a','addForeignKeyConstraint baseTableName=product_price, constraintName=fk_product_price_unit_of_measure, referencedTableName=unit_of_measure','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-756','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:43',750,'EXECUTED','8:b4783a2434e5ea9f0ad3eeaacf51464d','addForeignKeyConstraint baseTableName=product_price, constraintName=fk_product_price_updated_by, referencedTableName=user','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-757','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:43',751,'EXECUTED','8:3cac0496f6fcc0ab2813e3acce87b35f','addForeignKeyConstraint baseTableName=product, constraintName=fk_product_product_family, referencedTableName=product_group','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-758','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:43',752,'EXECUTED','8:3b0364c227f24abdcf7c47b263f10eff','addForeignKeyConstraint baseTableName=product_supplier_preference, constraintName=fk_product_supplier_preference_created_by, referencedTableName=user','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-759','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:43',753,'EXECUTED','8:11cf9be68fcb274af50cc350bb37e615','addForeignKeyConstraint baseTableName=product_supplier_preference, constraintName=fk_product_supplier_preference_destination_party, referencedTableName=party','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-760','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:43',754,'EXECUTED','8:5a81cc17b510efad54dbd5e810779cfb','addForeignKeyConstraint baseTableName=product_supplier_preference, constraintName=fk_product_supplier_preference_preference_type, referencedTableName=preference_type','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-761','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:43',755,'EXECUTED','8:cef9622df8fa759ca3f4748b07e25a51','addForeignKeyConstraint baseTableName=product_supplier_preference, constraintName=fk_product_supplier_preference_product_supplier, referencedTableName=product_supplier','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-762','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:43',756,'EXECUTED','8:51c90901db88ca74ac2bf796c1cf8cd9','addForeignKeyConstraint baseTableName=product_supplier_preference, constraintName=fk_product_supplier_preference_updated_by, referencedTableName=user','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-763','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:43',757,'EXECUTED','8:3a6144ecc90f7ab3727b851d456ed271','addForeignKeyConstraint baseTableName=product_type_displayed_fields, constraintName=fk_product_type_displayed_fields_product_type, referencedTableName=product_type','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-764','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:44',758,'EXECUTED','8:3d9797077f9b91eda7f2adc4d2958c80','addForeignKeyConstraint baseTableName=product_type_required_fields, constraintName=fk_product_type_required_fields_product_type, referencedTableName=product_type','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-765','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:44',759,'EXECUTED','8:83f8d7f66c5d23746c444955ba26b126','addForeignKeyConstraint baseTableName=product_type_supported_activities, constraintName=fk_product_type_supported_activities_product_type, referencedTableName=product_type','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-766','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:44',760,'EXECUTED','8:8cb0a69c30297feddc141f90c98c3302','addForeignKeyConstraint baseTableName=requisition, constraintName=fk_requisition_approved_by, referencedTableName=person','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-767','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:44',761,'EXECUTED','8:a5e0cea4117ee013c45990b21b612fe8','addForeignKeyConstraint baseTableName=requisition_approvers, constraintName=fk_requisition_approvers_person, referencedTableName=person','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-768','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:44',762,'EXECUTED','8:daf31d7d58321efd3589c2c6ed8086c0','addForeignKeyConstraint baseTableName=requisition_approvers, constraintName=fk_requisition_approvers_requisition, referencedTableName=requisition','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-769','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:44',763,'EXECUTED','8:ffab03a4c419383c716426351a3cc806','addForeignKeyConstraint baseTableName=requisition_comment, constraintName=fk_requisition_comment_comment, referencedTableName=comment','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-770','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:44',764,'EXECUTED','8:b5c0f16d40cb5e5079b17ab53e03af8b','addForeignKeyConstraint baseTableName=requisition_comment, constraintName=fk_requisition_comment_requisition, referencedTableName=requisition','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-771','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:44',765,'EXECUTED','8:b2ca94272361219197f91b3ebb1c7c96','addForeignKeyConstraint baseTableName=requisition_event, constraintName=fk_requisition_event_event, referencedTableName=event','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-772','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:44',766,'EXECUTED','8:24867371aade776c390dd305cc552efd','addForeignKeyConstraint baseTableName=requisition_event, constraintName=fk_requisition_event_requisition, referencedTableName=requisition','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-773','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:44',767,'EXECUTED','8:fa5c1bf7d2ac73a5cccd063085bfd0c1','addForeignKeyConstraint baseTableName=requisition, constraintName=fk_requisition_rejected_by, referencedTableName=person','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-774','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:44',768,'EXECUTED','8:7395da934005eee0a0171625ad822e36','addForeignKeyConstraint baseTableName=shipment_reference_number, constraintName=fk_shipment_reference_number_shipment, referencedTableName=shipment','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-775','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:44',769,'EXECUTED','8:b3a5eed19eb904120cb8ff7cbedb5b7b','addForeignKeyConstraint baseTableName=location_role, constraintName=location_role_ibfk_1, referencedTableName=user','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-776','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:44',770,'EXECUTED','8:65a5507585f03b02e3ca8b575e811775','addForeignKeyConstraint baseTableName=location_role, constraintName=location_role_ibfk_2, referencedTableName=role','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-777','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:44',771,'EXECUTED','8:13f43ed8f81913a616373e55064dfedd','addForeignKeyConstraint baseTableName=location_role, constraintName=location_role_ibfk_3, referencedTableName=location','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-778','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:44',772,'EXECUTED','8:02ae010fd1f199b1baa59e0f1c9d9bb6','addForeignKeyConstraint baseTableName=order_adjustment_invoice, constraintName=order_adjustment_invoice_ibfk_1, referencedTableName=order_adjustment','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-779','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:45',773,'EXECUTED','8:b10d3cbac1ccc21f76d7eae16a80e965','addForeignKeyConstraint baseTableName=order_adjustment_invoice, constraintName=order_adjustment_invoice_ibfk_2, referencedTableName=invoice_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-780','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:45',774,'EXECUTED','8:67eee024adb6b4f7e15b02a9568c9834','addForeignKeyConstraint baseTableName=picklist_item, constraintName=picklist_item_ibfk_1, referencedTableName=requisition_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-781','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:45',775,'EXECUTED','8:cb009fa426eac9382bdec795a9bbdba8','addForeignKeyConstraint baseTableName=picklist_item, constraintName=picklist_item_ibfk_2, referencedTableName=picklist','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-782','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:45',776,'EXECUTED','8:04c549465e9cf1ebe6932f75c55cdc27','addForeignKeyConstraint baseTableName=picklist_item, constraintName=picklist_item_ibfk_3, referencedTableName=user','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-783','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:46',777,'EXECUTED','8:6530ce4a7de576b2098c0020b9164a09','addForeignKeyConstraint baseTableName=picklist_item, constraintName=picklist_item_ibfk_4, referencedTableName=user','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-784','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:46',778,'EXECUTED','8:130330085faa252882a7fe4da7dbcc70','addForeignKeyConstraint baseTableName=picklist_item, constraintName=picklist_item_ibfk_5, referencedTableName=inventory_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-785','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:46',779,'EXECUTED','8:b892d010d6cb83c12330fc6665549cb0','addForeignKeyConstraint baseTableName=shipment_invoice, constraintName=shipment_invoice_ibfk_1, referencedTableName=shipment_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-786','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:46',780,'EXECUTED','8:c7d984aa7b81db2e78c34c1de691a407','addForeignKeyConstraint baseTableName=shipment_invoice, constraintName=shipment_invoice_ibfk_2, referencedTableName=invoice_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1700664714834-787','openboxes (generated)','install/changelog-add-foreign-key-constraints.groovy','2026-10-13 06:22:46',781,'EXECUTED','8:370555bc4c4e186f88c5b2dcaaede656','addForeignKeyConstraint baseTableName=location, constraintName=zone_location_ibfk_3, referencedTableName=location','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('disable-foreign-key-checks','jmiranda','install/changelog-disable-foreign-key-checks.groovy','2026-10-13 06:22:46',782,'EXECUTED','8:3b9473f6d6cdbcb392cbeb9da07ce9dd','sql','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1692069478960-3','openboxes (generated)','install/changelog-insert-system-data.groovy','2026-10-13 06:22:46',783,'EXECUTED','8:4de0a850f70e2345b016eb649879385f','insert tableName=container_type; insert tableName=container_type; insert tableName=container_type; insert tableName=container_type; insert tableName=container_type; insert tableName=container_type; insert tableName=container_type; insert tableName...','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1692069478960-5','openboxes (generated)','install/changelog-insert-system-data.groovy','2026-10-13 06:22:46',784,'EXECUTED','8:6d8ce1b34cd58c14df23c2ce55f6ed87','insert tableName=document_type; insert tableName=document_type; insert tableName=document_type; insert tableName=document_type; insert tableName=document_type; insert tableName=document_type; insert tableName=document_type; insert tableName=docume...','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1692069478960-7','openboxes (generated)','install/changelog-insert-system-data.groovy','2026-10-13 06:22:46',785,'EXECUTED','8:1813f036078a91413e013946588c61ce','insert tableName=event_type; insert tableName=event_type; insert tableName=event_type; insert tableName=event_type; insert tableName=event_type; insert tableName=event_type; insert tableName=event_type','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1692069478960-9','jmiranda (generated)','install/changelog-insert-system-data.groovy','2026-10-13 06:22:46',786,'EXECUTED','8:cf3a8e439293683dd4499a6f2920850c','insert tableName=invoice_type; insert tableName=invoice_type; insert tableName=invoice_type; insert tableName=invoice_type; insert tableName=invoice_type','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1692069478960-11','openboxes (generated)','install/changelog-insert-system-data.groovy','2026-10-13 06:22:46',787,'EXECUTED','8:0fbad92ec34c21f624f055f5f27f79ed','insert tableName=location_type; insert tableName=location_type; insert tableName=location_type; insert tableName=location_type; insert tableName=location_type; insert tableName=location_type; insert tableName=location_type; insert tableName=locati...','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1692069478960-12','openboxes (generated)','install/changelog-insert-system-data.groovy','2026-10-13 06:22:46',788,'EXECUTED','8:8f4ffb6eb181301e21267697d50c56a5','insert tableName=location_type_supported_activities; insert tableName=location_type_supported_activities; insert tableName=location_type_supported_activities; insert tableName=location_type_supported_activities; insert tableName=location_type_supp...','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1692069478960-13','openboxes (generated)','install/changelog-insert-system-data.groovy','2026-10-13 06:22:46',789,'EXECUTED','8:27eebb1b31fbaf0c62be8b7c28be20d6','insert tableName=order_adjustment_type; insert tableName=order_adjustment_type; insert tableName=order_adjustment_type; insert tableName=order_adjustment_type; insert tableName=order_adjustment_type; insert tableName=order_adjustment_type','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1692069478960-14','openboxes (generated)','install/changelog-insert-system-data.groovy','2026-10-13 06:22:46',790,'EXECUTED','8:7817ca7e5d69c6aa894e1830776b6b00','insert tableName=order_type; insert tableName=order_type; insert tableName=order_type; insert tableName=order_type; insert tableName=order_type; insert tableName=order_type; insert tableName=order_type','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1692069478960-17','openboxes (generated)','install/changelog-insert-system-data.groovy','2026-10-13 06:22:46',791,'EXECUTED','8:b30f671732ac767967f128d6427bf3cc','insert tableName=party_type; insert tableName=party_type','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1692069478960-18','openboxes (generated)','install/changelog-insert-system-data.groovy','2026-10-13 06:22:46',792,'EXECUTED','8:1cb0e793a478733e1a0a941923c91d24','insert tableName=payment_term; insert tableName=payment_term; insert tableName=payment_term; insert tableName=payment_term; insert tableName=payment_term; insert tableName=payment_term; insert tableName=payment_term','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1692069478960-20','openboxes (generated)','install/changelog-insert-system-data.groovy','2026-10-13 06:22:46',793,'EXECUTED','8:e449837b542c7ccca06a715cdcee5263','insert tableName=preference_type; insert tableName=preference_type; insert tableName=preference_type; insert tableName=preference_type; insert tableName=preference_type; insert tableName=preference_type','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1692069478960-21','openboxes (generated)','install/changelog-insert-system-data.groovy','2026-10-13 06:22:46',794,'EXECUTED','8:2ac048f9d0c9033d0e0b10f0308c13ea','insert tableName=product_type','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1692069478960-22','openboxes (generated)','install/changelog-insert-system-data.groovy','2026-10-13 06:22:46',795,'EXECUTED','8:22081b4fe2747663b8256eec559d848d','insert tableName=product_type_supported_activities','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1692069478960-23','openboxes (generated)','install/changelog-insert-system-data.groovy','2026-10-13 06:22:46',796,'EXECUTED','8:9bb3ed15ec0ebbd32564381fbf0130e4','insert tableName=reference_number_type; insert tableName=reference_number_type; insert tableName=reference_number_type; insert tableName=reference_number_type; insert tableName=reference_number_type; insert tableName=reference_number_type; insert ...','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1692069478960-24','openboxes (generated)','install/changelog-insert-system-data.groovy','2026-10-13 06:22:46',797,'EXECUTED','8:56822b332fdb8a0b2a6d21628e66bf0d','insert tableName=role; insert tableName=role; insert tableName=role; insert tableName=role; insert tableName=role; insert tableName=role; insert tableName=role; insert tableName=role; insert tableName=role; insert tableName=role; insert tableName=...','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1692069478960-25','openboxes (generated)','install/changelog-insert-system-data.groovy','2026-10-13 06:22:46',798,'EXECUTED','8:c1ec1ec3b8d777c68561d3a77129e9bd','insert tableName=shipment_type; insert tableName=shipment_type; insert tableName=shipment_type; insert tableName=shipment_type; insert tableName=shipment_type','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1692069478960-26','openboxes (generated)','install/changelog-insert-system-data.groovy','2026-10-13 06:22:46',799,'EXECUTED','8:eb2be4ca4bdbdf55d17ce4377972478c','insert tableName=shipment_workflow; insert tableName=shipment_workflow; insert tableName=shipment_workflow; insert tableName=shipment_workflow; insert tableName=shipment_workflow','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1692069478960-27','openboxes (generated)','install/changelog-insert-system-data.groovy','2026-10-13 06:22:46',800,'EXECUTED','8:5ae224c8db4e3ca73ecb404b261f43f9','insert tableName=shipment_workflow_container_type; insert tableName=shipment_workflow_container_type; insert tableName=shipment_workflow_container_type; insert tableName=shipment_workflow_container_type; insert tableName=shipment_workflow_containe...','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1692069478960-28','openboxes (generated)','install/changelog-insert-system-data.groovy','2026-10-13 06:22:46',801,'EXECUTED','8:366c2bdedd33a7a0239cf4396299c9e3','insert tableName=shipment_workflow_reference_number_type; insert tableName=shipment_workflow_reference_number_type; insert tableName=shipment_workflow_reference_number_type; insert tableName=shipment_workflow_reference_number_type; insert tableNam...','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1692069478960-31','openboxes (generated)','install/changelog-insert-system-data.groovy','2026-10-13 06:22:46',802,'EXECUTED','8:8dde5056b10c9cadd43d222fecb726de','insert tableName=transaction_type; insert tableName=transaction_type; insert tableName=transaction_type; insert tableName=transaction_type; insert tableName=transaction_type; insert tableName=transaction_type; insert tableName=transaction_type; in...','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1692069478960-32','openboxes (generated)','install/changelog-insert-system-data.groovy','2026-10-13 06:22:46',803,'EXECUTED','8:734ab51b29b0baf16d30bbbdfaecff37','insert tableName=unit_of_measure; insert tableName=unit_of_measure; insert tableName=unit_of_measure; insert tableName=unit_of_measure; insert tableName=unit_of_measure; insert tableName=unit_of_measure; insert tableName=unit_of_measure; insert ta...','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1692069478960-33','openboxes (generated)','install/changelog-insert-system-data.groovy','2026-10-13 06:22:46',804,'EXECUTED','8:51da36e0bb0cd4cd4ef6eb83dc6183fa','insert tableName=unit_of_measure_class; insert tableName=unit_of_measure_class','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1692069478960-1','openboxes (generated)','install/changelog-insert-data.groovy','2026-10-13 06:22:46',805,'EXECUTED','8:6dd58ea3c249556d1d86dddec8cccb17','insert tableName=address; insert tableName=address; insert tableName=address; insert tableName=address','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1692069478960-6','openboxes (generated)','install/changelog-insert-data.groovy','2026-10-13 06:22:46',806,'EXECUTED','8:38032adaac7c54ae13168eb1d2320572','insert tableName=donor; insert tableName=donor; insert tableName=donor','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1692069478960-8','openboxes (generated)','install/changelog-insert-data.groovy','2026-10-13 06:22:46',807,'EXECUTED','8:90b1e195ee77a9de154a04894f737173','insert tableName=inventory; insert tableName=inventory; insert tableName=inventory','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1692069478960-10','openboxes (generated)','install/changelog-insert-data.groovy','2026-10-13 06:22:46',808,'EXECUTED','8:c361e5a0cd6fbb3dd7868ccfb767ba54','insert tableName=location; insert tableName=location','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1692069478960-15','openboxes (generated)','install/changelog-insert-data.groovy','2026-10-13 06:22:46',809,'EXECUTED','8:d90b5b2a42b2631517c5b0e883ee6d8f','insert tableName=party; insert tableName=party','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1692069478960-16','openboxes (generated)','install/changelog-insert-data.groovy','2026-10-13 06:22:46',810,'EXECUTED','8:21d4f9a62ca24f7ce86dd263cc7a54c9','insert tableName=party_role; insert tableName=party_role','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1692069478960-19','openboxes (generated)','install/changelog-insert-data.groovy','2026-10-13 06:22:46',811,'EXECUTED','8:ef8278b4e47062931d21661693d28ece','insert tableName=person','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1692069478960-29','openboxes (generated)','install/changelog-insert-data.groovy','2026-10-13 06:22:46',812,'EXECUTED','8:fdbe9fb3f7749a55875e2afb6283ae54','insert tableName=shipper; insert tableName=shipper; insert tableName=shipper; insert tableName=shipper; insert tableName=shipper','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1692069478960-30','openboxes (generated)','install/changelog-insert-data.groovy','2026-10-13 06:22:46',813,'EXECUTED','8:fd46399b95e574889e0757be2ff249de','insert tableName=shipper_service; insert tableName=shipper_service; insert tableName=shipper_service; insert tableName=shipper_service; insert tableName=shipper_service; insert tableName=shipper_service; insert tableName=shipper_service; insert ta...','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1692069478960-34','openboxes (generated)','install/changelog-insert-data.groovy','2026-10-13 06:22:46',814,'EXECUTED','8:27580204b3edc536d339cbbdc84b3ed2','insert tableName=user','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1692069478960-35','openboxes (generated)','install/changelog-insert-data.groovy','2026-10-13 06:22:46',815,'EXECUTED','8:0c7912b4df5a9a4d6f529e16be084aa9','insert tableName=user_role; insert tableName=user_role; insert tableName=user_role; insert tableName=user_role','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('enable-foreign-key-checks','jmiranda','install/changelog-enable-foreign-key-checks.groovy','2026-10-13 06:22:46',816,'EXECUTED','8:f3d669608b9af27a3b9abc81cb0aeb3b','sql','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('210220231340-0','drodzewicz','0.9.x/changelog-2023-02-21-1340-alter-table-order-change-date-ordered-column-type.xml','2026-10-13 06:22:46',817,'EXECUTED','8:2dc2dd85aa9210dd4d3d78ee4f636fc5','sql','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('070920231140-0','drodzewicz','0.9.x/changelog-2023-09-07-1140-add-missing-is_root-value-to-root-catalog.xml','2026-10-13 06:22:46',818,'MARK_RAN','8:29db8889522cbafadcf69cb949922b68','update tableName=category','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('080920231340-0','drodzewicz','0.9.x/changelog-2023-09-08-1340-remove-product-price-fk-on-product-package-pointing-to-non-existing-record.xml','2026-10-13 06:22:46',819,'MARK_RAN','8:9c71efd893cb63794b9ed3fb46b43a96','sql','This migration is meant to fix a bug found on OBGM-687\n      which caused an issue when importing product sources.\n      An invalid product price was not persisted in the database,\n      but an id (FK) was added to the product_package table on pro...',NULL,'3.10.1',NULL,NULL,'1872545501'),
('061120231230-0','drodzewicz','0.9.x/changelog-2023-11-06-1230-add-missing-role-names.xml','2026-10-13 06:22:46',820,'MARK_RAN','8:889ef3949e5510963d3b3f0e74f0320a','update tableName=role','Add missing value for name column on \"ROLE\" table where role_type is ROLE_ADMIN',NULL,'3.10.1',NULL,NULL,'1872545501'),
('061120231230-1','drodzewicz','0.9.x/changelog-2023-11-06-1230-add-missing-role-names.xml','2026-10-13 06:22:46',821,'MARK_RAN','8:d9f88ebdd62b1abcb9776358e0876ee2','update tableName=role','Add missing value for name column on \"ROLE\" table where role_type is ROLE_MANAGER',NULL,'3.10.1',NULL,NULL,'1872545501'),
('061120231230-2','drodzewicz','0.9.x/changelog-2023-11-06-1230-add-missing-role-names.xml','2026-10-13 06:22:46',822,'MARK_RAN','8:e19c442ffe01e6de20d8bda710d9cdb2','update tableName=role','Add missing value for name column on \"ROLE\" table where role_type is ROLE_BROWSER',NULL,'3.10.1',NULL,NULL,'1872545501'),
('061120231230-3','drodzewicz','0.9.x/changelog-2023-11-06-1230-add-missing-role-names.xml','2026-10-13 06:22:46',823,'MARK_RAN','8:d6de6ab24e2dd6fa8e4952598a0c6a5b','update tableName=role','Add missing value for name column on \"ROLE\" table where role_type is ROLE_ASSISTANT',NULL,'3.10.1',NULL,NULL,'1872545501'),
('061120231230-4','drodzewicz','0.9.x/changelog-2023-11-06-1230-add-missing-role-names.xml','2026-10-13 06:22:46',824,'MARK_RAN','8:ce1e4eac4b4453a206de03dc0389ad86','update tableName=role','Add missing value for name column on \"ROLE\" table where role_type is ROLE_SUPERUSER',NULL,'3.10.1',NULL,NULL,'1872545501'),
('061120231230-5','drodzewicz','0.9.x/changelog-2023-11-06-1230-add-missing-role-names.xml','2026-10-13 06:22:46',825,'MARK_RAN','8:efcc1d2c30b70520311ca171cbb036a0','update tableName=role','Add missing value for name column on \"ROLE\" table where role_type is ROLE_ORDER_NOTIFICATION',NULL,'3.10.1',NULL,NULL,'1872545501'),
('061120231230-6','drodzewicz','0.9.x/changelog-2023-11-06-1230-add-missing-role-names.xml','2026-10-13 06:22:46',826,'MARK_RAN','8:982f2fa93f773321ca3987d50d32457a','update tableName=role','Add missing value for name column on \"ROLE\" table where role_type is ROLE_AUTHENTICATED',NULL,'3.10.1',NULL,NULL,'1872545501'),
('061120231230-7','drodzewicz','0.9.x/changelog-2023-11-06-1230-add-missing-role-names.xml','2026-10-13 06:22:46',827,'MARK_RAN','8:a91d7d8e42a25323856873b0ca6118a7','update tableName=role','Add missing value for name column on \"ROLE\" table where role_type is ROLE_USER_NOTIFICATION',NULL,'3.10.1',NULL,NULL,'1872545501'),
('061120231230-8','drodzewicz','0.9.x/changelog-2023-11-06-1230-add-missing-role-names.xml','2026-10-13 06:22:46',828,'MARK_RAN','8:b282a55d4ec24a17b23744c35e10c0f3','update tableName=role','Add missing value for name column on \"ROLE\" table where role_type is ROLE_PRODUCT_NOTIFICATION',NULL,'3.10.1',NULL,NULL,'1872545501'),
('061120231230-9','drodzewicz','0.9.x/changelog-2023-11-06-1230-add-missing-role-names.xml','2026-10-13 06:22:46',829,'MARK_RAN','8:426e6e998b3685938b91317f93120d2a','update tableName=role','Add missing value for name column on \"ROLE\" table where role_type is ROLE_SHIPMENT_NOTIFICATION',NULL,'3.10.1',NULL,NULL,'1872545501'),
('061120231230-10','drodzewicz','0.9.x/changelog-2023-11-06-1230-add-missing-role-names.xml','2026-10-13 06:22:46',830,'MARK_RAN','8:2ea9a5b7ea298e8eebabac1505d651fb','update tableName=role','Add missing value for name column on \"ROLE\" table where role_type is ROLE_ERROR_NOTIFICATION',NULL,'3.10.1',NULL,NULL,'1872545501'),
('061120231230-11','drodzewicz','0.9.x/changelog-2023-11-06-1230-add-missing-role-names.xml','2026-10-13 06:22:46',831,'MARK_RAN','8:f6537aca7e49ce9c96d6bc298f35cb75','update tableName=role','Add missing value for name column on \"ROLE\" table where role_type is ROLE_FEEDBACK_NOTIFICATION',NULL,'3.10.1',NULL,NULL,'1872545501'),
('100120241100-1','kchelstowski','0.9.x/changelog-2024-01-10-1100-add-missing-foreign-keys-for-product-price.xml','2026-10-13 06:22:47',832,'EXECUTED','8:8cdb8046b4e43487888e4d91db6fb315','addForeignKeyConstraint baseTableName=product_supplier, constraintName=fk_product_supplier_product_price, referencedTableName=product_price','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('100120241100-2','kchelstowski','0.9.x/changelog-2024-01-10-1100-add-missing-foreign-keys-for-product-price.xml','2026-10-13 06:22:47',833,'EXECUTED','8:2f03961394314f7a61f03a3a60680061','addForeignKeyConstraint baseTableName=product_package, constraintName=fk_product_package_product_price, referencedTableName=product_price','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('220220241300-0','kchelstowski','0.9.x/changelog-2024-02-22-1300-add-default-product-package-to-product-supplier.xml','2026-10-13 06:22:47',834,'EXECUTED','8:91ca486edd7c9b08a11e134c8fffd74c','addColumn tableName=product_supplier','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('220220241300-1','kchelstowski','0.9.x/changelog-2024-02-22-1300-add-default-product-package-to-product-supplier.xml','2026-10-13 06:22:47',835,'EXECUTED','8:a371ac4503fb6ead48cdd16908303dbd','addForeignKeyConstraint baseTableName=product_supplier, constraintName=fk_product_supplier_product_package, referencedTableName=product_package','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1709054923255-0','openboxes (generated)','0.9.x/changelog-2024-02-27-1630-add-tiered-pricing-to-product-supplier.groovy','2026-10-13 06:22:47',836,'EXECUTED','8:de9bb881116eaa11ca2cc5851c830adb','addColumn tableName=product_supplier','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('290420241230-0','anadolny','0.9.x/changelog-2024-04-29-1200-alter-table-picklist-item-add-quantity-picked.groovy','2026-10-13 06:22:47',837,'EXECUTED','8:935f9720d3fc4f3b51ac16d7fb200f59','addColumn tableName=picklist_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('290420241230-2','anadolny','0.9.x/changelog-2024-04-29-1200-alter-table-picklist-item-add-quantity-picked.groovy','2026-10-13 06:22:47',838,'EXECUTED','8:533c84dd5dbde45141b0f91f76842097','addColumn tableName=picklist_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('290420241230-3','anadolny','0.9.x/changelog-2024-04-29-1200-alter-table-picklist-item-add-quantity-picked.groovy','2026-10-13 06:22:47',839,'EXECUTED','8:6db2dbda61c9d8022d7df32cb3bc76fd','addColumn tableName=picklist_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('290420241230-4','anadolny','0.9.x/changelog-2024-04-29-1200-alter-table-picklist-item-add-quantity-picked.groovy','2026-10-13 06:22:47',840,'EXECUTED','8:0f26a6e62d4b37440790c5cc4f2d3c11','addForeignKeyConstraint baseTableName=picklist_item, constraintName=fk_picklist_item_picker_id_person, referencedTableName=person','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('080520241110-0','anadolny','0.9.x/changelog-2024-05-08-1110-rename-picker-to-pickedBy-column.groovy','2026-10-13 06:22:47',841,'EXECUTED','8:c626bb44387d8b3f5b01aa9b30ae230a','renameColumn newColumnName=picked_by_id, oldColumnName=picker_id, tableName=picklist_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('080520241110-1','anadolny','0.9.x/changelog-2024-05-08-1110-rename-picker-to-pickedBy-column.groovy','2026-10-13 06:22:48',842,'EXECUTED','8:c022214bede8651be07f6fbd726dc587','dropForeignKeyConstraint baseTableName=picklist_item, constraintName=fk_picklist_item_picker_id_person','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('080520241110-2','anadolny','0.9.x/changelog-2024-05-08-1110-rename-picker-to-pickedBy-column.groovy','2026-10-13 06:22:48',843,'EXECUTED','8:fdc85489c882aeb5642216cf150c077e','addForeignKeyConstraint baseTableName=picklist_item, constraintName=fk_picklist_item_picked_by_id_person, referencedTableName=person','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('270620241200-0','drodzewicz','0.9.x/changelog-2024-06-27-1200-add-auto-allocated-column-to-requisition-item.groovy','2026-10-13 06:22:48',844,'EXECUTED','8:9dd7cd6ee4b7a05ab97cdd5c828d3727','addColumn tableName=requisition_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('190820241100-0','awalkowiak','0.9.x/changelog-2024-08-19-1100-add-inverse-to-invoice-item.xml','2026-10-13 06:22:48',845,'EXECUTED','8:10a2551d67b889c864c2ed9118fd2c0f','addColumn tableName=invoice_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('190820241200-0','ewaterman','0.9.x/changelog-2024-08-19-1200-alter-table-invoice-item-set-invoice-non-null.xml','2026-10-13 06:22:48',846,'EXECUTED','8:2337ac2f92d4d7095a7f6402171db534','addNotNullConstraint columnName=inverse, tableName=invoice_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('200820240000-0','ewaterman','0.9.x/changelog-2024-08-20-0000-migrate-prepayment-invoices-add-amount-and-inverse-items.groovy','2026-10-13 06:22:49',847,'EXECUTED','8:01bb264dd31114111d21e071cbfc57e9','grailsChange','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('200820240000-1','ewaterman','0.9.x/changelog-2024-08-20-0000-migrate-prepayment-invoices-add-amount-and-inverse-items.groovy','2026-10-13 06:22:49',848,'EXECUTED','8:01bb264dd31114111d21e071cbfc57e9','grailsChange','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('041020241610-0','anadolny','0.9.x/changelog-2024-10-04-1610-assign-amount-to-invoice-items.xml','2026-10-13 06:22:49',849,'MARK_RAN','8:83db42cedd5755cf51e140c6855349ad','sql','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('281020241330-0','anadolny','0.9.x/changelog-2024-10-28-1330-add-column-date-delivery-requested-to-requisition.xml','2026-10-13 06:22:49',850,'EXECUTED','8:bb31fa5f70a7e77eea1391a1e46703ea','addColumn tableName=requisition','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('021220241330-0','ewaterman','0.9.x/changelog-2024-12-02-0000-alter-table-location-type-set-location-type-code-non-null.xml','2026-10-13 06:22:49',851,'EXECUTED','8:6c10c8db2ab48be682e86755eb1b1ba9','addNotNullConstraint columnName=location_type_code, tableName=location_type','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('181220241300-0','kchelstowski','0.9.x/changelog-2024-12-18-1300-create-table-cycle-count-request.xml','2026-10-13 06:22:49',852,'EXECUTED','8:2e9e3f01680dd2c0539cf4a3934f2600','createTable tableName=cycle_count_request','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('181220241300-1','kchelstowski','0.9.x/changelog-2024-12-18-1300-create-table-cycle-count-request.xml','2026-10-13 06:22:49',853,'EXECUTED','8:b543954dfb207d6ba66e8f3c3bafd4d4','addForeignKeyConstraint baseTableName=cycle_count_request, constraintName=fk_cycle_count_request_location, referencedTableName=location','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('181220241300-2','kchelstowski','0.9.x/changelog-2024-12-18-1300-create-table-cycle-count-request.xml','2026-10-13 06:22:49',854,'EXECUTED','8:216accf08ee539259c907747abc198df','addForeignKeyConstraint baseTableName=cycle_count_request, constraintName=fk_cycle_count_request_product, referencedTableName=product','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('181220241300-3','kchelstowski','0.9.x/changelog-2024-12-18-1300-create-table-cycle-count-request.xml','2026-10-13 06:22:49',855,'EXECUTED','8:bec3bea4479c62574cc94a293a2073c0','addForeignKeyConstraint baseTableName=cycle_count_request, constraintName=fk_cycle_count_request_created_by, referencedTableName=user','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('181220241300-4','kchelstowski','0.9.x/changelog-2024-12-18-1300-create-table-cycle-count-request.xml','2026-10-13 06:22:49',856,'EXECUTED','8:58ef9efad7c5f6670059a3bbe1254c57','addForeignKeyConstraint baseTableName=cycle_count_request, constraintName=fk_cycle_count_request_updated_by, referencedTableName=user','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('170120251800-0','kchelstowski','0.9.x/changelog-2025-01-17-1800-create-table-cycle-count.xml','2026-10-13 06:22:49',857,'EXECUTED','8:7ec3850ca4a90d9933c4dfa19780a6b3','createTable tableName=cycle_count','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('170120251800-1','kchelstowski','0.9.x/changelog-2025-01-17-1800-create-table-cycle-count.xml','2026-10-13 06:22:50',858,'EXECUTED','8:375b0fa512f279e558a61edb9e66947a','addForeignKeyConstraint baseTableName=cycle_count, constraintName=fk_cycle_count_location, referencedTableName=location','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('170120251800-3','kchelstowski','0.9.x/changelog-2025-01-17-1800-create-table-cycle-count.xml','2026-10-13 06:22:50',859,'EXECUTED','8:0f9edba47db3c8f6fe97b5c721061a16','addForeignKeyConstraint baseTableName=cycle_count, constraintName=fk_cycle_count_created_by, referencedTableName=user','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('170120251800-4','kchelstowski','0.9.x/changelog-2025-01-17-1800-create-table-cycle-count.xml','2026-10-13 06:22:50',860,'EXECUTED','8:77ba321e1a383bf6748c4350cb38b35a','addForeignKeyConstraint baseTableName=cycle_count, constraintName=fk_cycle_count_updated_by, referencedTableName=user','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('170120251830-0','kchelstowski','0.9.x/changelog-2025-01-17-1830-add-column-cycle-count-to-cycle-count-request.xml','2026-10-13 06:22:50',861,'MARK_RAN','8:ff3faa47879d8665108f8bb7e7c5dca4','addColumn tableName=cycle_count_request','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('170120251800-3','kchelstowski','0.9.x/changelog-2025-01-17-1830-add-column-cycle-count-to-cycle-count-request.xml','2026-10-13 06:22:50',862,'EXECUTED','8:8225c25027fe4d0605e8604da6b92519','addForeignKeyConstraint baseTableName=cycle_count_request, constraintName=fk_cycle_count_request_cycle_count, referencedTableName=cycle_count','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('170120251900-0','kchelstowski','0.9.x/changelog-2025-01-17-1900-create-table-cycle-count-item.xml','2026-10-13 06:22:50',863,'EXECUTED','8:8179257ddf18be3db15d63d9afcc527d','createTable tableName=cycle_count_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('170120251900-1','kchelstowski','0.9.x/changelog-2025-01-17-1900-create-table-cycle-count-item.xml','2026-10-13 06:22:50',864,'EXECUTED','8:78bc6336a87805f9448daf96bf3f0f4e','addForeignKeyConstraint baseTableName=cycle_count_item, constraintName=fk_cycle_count_item_location, referencedTableName=location','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('170120251900-2','kchelstowski','0.9.x/changelog-2025-01-17-1900-create-table-cycle-count-item.xml','2026-10-13 06:22:50',865,'EXECUTED','8:5724e42fb39451bb11602e46971cc34f','addForeignKeyConstraint baseTableName=cycle_count_item, constraintName=fk_cycle_count_item_created_by, referencedTableName=user','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('170120251800-3','kchelstowski','0.9.x/changelog-2025-01-17-1900-create-table-cycle-count-item.xml','2026-10-13 06:22:50',866,'EXECUTED','8:1b892ab1aae094e752f7e6342b25a977','addForeignKeyConstraint baseTableName=cycle_count_item, constraintName=fk_cycle_count_item_updated_by, referencedTableName=user','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('170120251800-4','kchelstowski','0.9.x/changelog-2025-01-17-1900-create-table-cycle-count-item.xml','2026-10-13 06:22:50',867,'EXECUTED','8:afe6bd49c678e5c6c3a9168430abb858','addForeignKeyConstraint baseTableName=cycle_count_item, constraintName=fk_cycle_count_item_cycle_count, referencedTableName=cycle_count','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('170120251800-5','kchelstowski','0.9.x/changelog-2025-01-17-1900-create-table-cycle-count-item.xml','2026-10-13 06:22:50',868,'EXECUTED','8:60dda13688dbcf0950869077e7b5911c','addForeignKeyConstraint baseTableName=cycle_count_item, constraintName=fk_cycle_count_item_inventory_item, referencedTableName=inventory_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('170120251800-6','kchelstowski','0.9.x/changelog-2025-01-17-1900-create-table-cycle-count-item.xml','2026-10-13 06:22:50',869,'EXECUTED','8:bdbbe4aa1302c3d3f42807b42ebca074','addForeignKeyConstraint baseTableName=cycle_count_item, constraintName=fk_cycle_count_item_product, referencedTableName=product','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('170120251800-7','kchelstowski','0.9.x/changelog-2025-01-17-1900-create-table-cycle-count-item.xml','2026-10-13 06:22:50',870,'EXECUTED','8:f5f55f83fd59380143f01eaf1115c3ad','addForeignKeyConstraint baseTableName=cycle_count_item, constraintName=fk_cycle_count_item_assignee, referencedTableName=user','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('050220251500-0','kchelstowski','0.9.x/changelog-2025-02-05-1500-add-column-location-to-cycle-count-item.xml','2026-10-13 06:22:50',871,'EXECUTED','8:471f0dc70963f5067fc92ee7b4e04a4f','addColumn tableName=cycle_count_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('050220251500-1','kchelstowski','0.9.x/changelog-2025-02-05-1500-add-column-location-to-cycle-count-item.xml','2026-10-13 06:22:51',872,'EXECUTED','8:4685594fc260eaeb72ae367f1b280f82','addForeignKeyConstraint baseTableName=cycle_count_item, constraintName=fk_cycle_count_item_bin_location, referencedTableName=location','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('060220250000-0','ewaterman','0.9.x/changelog-2025-02-06-0000-add-column-status-to-cycle-count.xml','2026-10-13 06:22:51',873,'EXECUTED','8:0b3523d75b4ec6344fb587c6d2fb3e88','addColumn tableName=cycle_count','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('060220252200-0','kchelstowski','0.9.x/changelog-2025-02-06-2200-drop-not-null-constraint-on-bin-location-in-cycle-count-item.xml','2026-10-13 06:22:51',874,'EXECUTED','8:61f26b4b051178932f054791d012cdf4','dropNotNullConstraint columnName=location_id, tableName=cycle_count_item','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('110220251530-0','kchelstowski','0.9.x/changelog-2025-02-11-1530-add-column-cycle-count-to-transaction.xml','2026-10-13 06:22:51',875,'EXECUTED','8:21ef927e61de0c9cf9e2f70a50235dbe','addColumn tableName=transaction','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('110220251530-1','kchelstowski','0.9.x/changelog-2025-02-11-1530-add-column-cycle-count-to-transaction.xml','2026-10-13 06:22:51',876,'EXECUTED','8:6e00a6343a71ec3c5ba9624d8c90e525','addForeignKeyConstraint baseTableName=transaction, constraintName=fk_transaction_cycle_count, referencedTableName=cycle_count','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('110320251300-0','kchelstowski','0.9.x/changelog-2025-03-11-1300-drop-user-foreign-key-from-assignee-in-cycle-count-item.xml','2026-10-13 06:22:51',877,'EXECUTED','8:2a48ec1de87f809b6c3bf5ed56fbaf14','dropForeignKeyConstraint baseTableName=cycle_count_item, constraintName=fk_cycle_count_item_assignee','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('110320251400-0','kchelstowski','0.9.x/changelog-2025-03-11-1400-add-person-foreign-key-for-assignee-in-cycle-count-item.xml','2026-10-13 06:22:51',878,'EXECUTED','8:f1f09791df53da41bf6275328d6f00a1','addForeignKeyConstraint baseTableName=cycle_count_item, constraintName=fk_cycle_count_item_assignee, referencedTableName=person','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1743040916119-1','jmiranda','0.9.x/changelog-2025-03-26-2057-update-abc-class-convert-empty-string-to-null.xml','2026-10-13 06:22:51',879,'EXECUTED','8:f0ff98db25ac64d14ad87d830d64f2d3','sql','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1743040916119-2','jmiranda','0.9.x/changelog-2025-03-26-2057-update-abc-class-convert-empty-string-to-null.xml','2026-10-13 06:22:51',880,'EXECUTED','8:ed6c3e51e74da315dc3b7a8c1f2fa962','sql','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('290420250000-0','ewaterman','0.9.x/changelog-2025-04-29-0000-add-inventory-baseline-transaction-type.xml','2026-10-13 06:22:51',881,'EXECUTED','8:47d76ecc9573af5d2b5616b42a17be26','insert tableName=transaction_type','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1749057610379-1','jmiranda','0.9.x/changelog-2025-06-04-1219-create-missing-indexes.xml','2026-10-13 06:22:51',882,'EXECUTED','8:a5a74e5984a7167ee16680041006d9f6','createIndex indexName=idx_location_name, tableName=location','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1749057610379-2','jmiranda','0.9.x/changelog-2025-06-04-1219-create-missing-indexes.xml','2026-10-13 06:22:51',883,'EXECUTED','8:e172292e292ed0b089f3e27538865b7b','createIndex indexName=idx_transaction_transaction_date, tableName=transaction','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1749057610379-3','jmiranda','0.9.x/changelog-2025-06-04-1219-create-missing-indexes.xml','2026-10-13 06:22:51',884,'EXECUTED','8:1e7bf94446b3eae6d20b19db55b35279','createIndex indexName=idx_transaction_type_transaction_code, tableName=transaction_type','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('050620250000-0','ewaterman','0.9.x/changelog-2025-06-05-0000-add-assignment-columns-to-cycle-count-request.xml','2026-10-13 06:22:51',885,'EXECUTED','8:5c8b00fa7aa8f07dae5bdeb0df881971','addColumn tableName=cycle_count_request; addForeignKeyConstraint baseTableName=cycle_count_request, constraintName=fk_cycle_count_request_count_assignee, referencedTableName=person','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('050620250000-1','ewaterman','0.9.x/changelog-2025-06-05-0000-add-assignment-columns-to-cycle-count-request.xml','2026-10-13 06:22:51',886,'EXECUTED','8:054f25c5f8984e391b4a849ac2da00fc','addColumn tableName=cycle_count_request; addForeignKeyConstraint baseTableName=cycle_count_request, constraintName=fk_cycle_count_request_recount_assignee, referencedTableName=person','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('050620250000-2','ewaterman','0.9.x/changelog-2025-06-05-0000-add-assignment-columns-to-cycle-count-request.xml','2026-10-13 06:22:51',887,'EXECUTED','8:0e0149553d1cc1175f6a5c96524907b5','addColumn tableName=cycle_count_request','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('050620250000-3','ewaterman','0.9.x/changelog-2025-06-05-0000-add-assignment-columns-to-cycle-count-request.xml','2026-10-13 06:22:51',888,'EXECUTED','8:c1e57802edd02e3948b567e285384506','addColumn tableName=cycle_count_request','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('081020251700-0','kchelstowski','0.9.x/changelog-2025-10-08-1700-create-table-transaction-source.xml','2026-10-13 06:22:51',889,'EXECUTED','8:2bc5c79d75faa30429593fc6d960157b','createTable tableName=transaction_source','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('081020251700-1','kchelstowski','0.9.x/changelog-2025-10-08-1700-create-table-transaction-source.xml','2026-10-13 06:22:52',890,'EXECUTED','8:253bc7818e1aa492200d703eb31e44f8','addForeignKeyConstraint baseTableName=transaction_source, constraintName=fk_transaction_source_shipment, referencedTableName=shipment','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('081020251700-2','kchelstowski','0.9.x/changelog-2025-10-08-1700-create-table-transaction-source.xml','2026-10-13 06:22:52',891,'EXECUTED','8:7a4562253e75757ed670f6e149668ac5','addForeignKeyConstraint baseTableName=transaction_source, constraintName=fk_transaction_source_requisition, referencedTableName=requisition','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('081020251700-3','kchelstowski','0.9.x/changelog-2025-10-08-1700-create-table-transaction-source.xml','2026-10-13 06:22:52',892,'EXECUTED','8:4e10d064d26ca0aba76d8a2658c350be','addForeignKeyConstraint baseTableName=transaction_source, constraintName=fk_transaction_source_receipt, referencedTableName=receipt','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('081020251700-4','kchelstowski','0.9.x/changelog-2025-10-08-1700-create-table-transaction-source.xml','2026-10-13 06:22:52',893,'EXECUTED','8:7e9d4c43a39c5da08a37bc589abf0d87','addForeignKeyConstraint baseTableName=transaction_source, constraintName=fk_transaction_source_order, referencedTableName=order','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('081020251700-5','kchelstowski','0.9.x/changelog-2025-10-08-1700-create-table-transaction-source.xml','2026-10-13 06:22:52',894,'EXECUTED','8:b31b01ba983c1f52b871c18b3d2e705c','addForeignKeyConstraint baseTableName=transaction_source, constraintName=fk_transaction_source_cycle_count, referencedTableName=cycle_count','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('081020251700-6','kchelstowski','0.9.x/changelog-2025-10-08-1700-create-table-transaction-source.xml','2026-10-13 06:22:52',895,'EXECUTED','8:ac8ec6f5da8044aa0d1f4323a4b2e5e5','addForeignKeyConstraint baseTableName=transaction_source, constraintName=fk_transaction_source_origin, referencedTableName=location','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('081020251700-7','kchelstowski','0.9.x/changelog-2025-10-08-1700-create-table-transaction-source.xml','2026-10-13 06:22:52',896,'EXECUTED','8:ba3717f78d6793859d700c21b0632182','addForeignKeyConstraint baseTableName=transaction_source, constraintName=fk_transaction_source_destination, referencedTableName=location','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('081020251700-8','kchelstowski','0.9.x/changelog-2025-10-08-1700-create-table-transaction-source.xml','2026-10-13 06:22:52',897,'EXECUTED','8:d63e677a259e9c8191448d128107f8df','addForeignKeyConstraint baseTableName=transaction_source, constraintName=fk_transaction_source_created_by, referencedTableName=user','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('081020251700-9','kchelstowski','0.9.x/changelog-2025-10-08-1700-create-table-transaction-source.xml','2026-10-13 06:22:52',898,'EXECUTED','8:c5a3dcd18f94a353ce045f187b2f1892','addForeignKeyConstraint baseTableName=transaction_source, constraintName=fk_transaction_source_updated_by, referencedTableName=user','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('091020251200-0','kchelstowski','0.9.x/changelog-2025-10-09-1200-add-transaction-source-column-to-transaction.xml','2026-10-13 06:22:52',899,'EXECUTED','8:cfe09d9c924514c51a605a2110e5071f','addColumn tableName=transaction','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('091020251200-1','kchelstowski','0.9.x/changelog-2025-10-09-1200-add-transaction-source-column-to-transaction.xml','2026-10-13 06:22:52',900,'EXECUTED','8:6788986fd1d63ae3e0315bc758923ba4','addForeignKeyConstraint baseTableName=transaction, constraintName=fk_transaction_transaction_source, referencedTableName=transaction_source','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('141020251200-0','ewaterman','0.9.x/changelog-2025-10-14-1200-add-user-columns-to-product-supplier.xml','2026-10-13 06:22:52',901,'EXECUTED','8:c673d2a5183798847a200621b9c252e3','addColumn tableName=product_supplier','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('141020251200-1','ewaterman','0.9.x/changelog-2025-10-14-1200-add-user-columns-to-product-supplier.xml','2026-10-13 06:22:52',902,'EXECUTED','8:3cd34a5fb970450c7df4dcfb8f66f14f','addColumn tableName=product_supplier','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('141020251200-2','ewaterman','0.9.x/changelog-2025-10-14-1200-add-user-columns-to-product-supplier.xml','2026-10-13 06:22:52',903,'EXECUTED','8:f2f642a783afabf4d41d8464f0dc1609','addForeignKeyConstraint baseTableName=product_supplier, constraintName=fk_product_supplier_created_by, referencedTableName=user','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('141020251200-3','ewaterman','0.9.x/changelog-2025-10-14-1200-add-user-columns-to-product-supplier.xml','2026-10-13 06:22:52',904,'EXECUTED','8:9f72c78f3a3fd0e3177f4e11b93163b3','addForeignKeyConstraint baseTableName=product_supplier, constraintName=fk_product_supplier_updated_by, referencedTableName=user','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('201120251300-1','kchelstowski','0.9.x/changelog-2025-11-20-1300-rename-transaction-source-columns.xml','2026-10-13 06:22:52',905,'EXECUTED','8:d41d8cd98f00b204e9800998ecf8427e','empty','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('201120251300-2','kchelstowski','0.9.x/changelog-2025-11-20-1300-rename-transaction-source-columns.xml','2026-10-13 06:22:52',906,'EXECUTED','8:81cf39a35e34ac70c542cdae49c6c1ff','renameColumn newColumnName=origin_id, oldColumnName=origin, tableName=transaction_source; dropForeignKeyConstraint baseTableName=transaction_source, constraintName=fk_transaction_source_origin; addForeignKeyConstraint baseTableName=transaction_sou...','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('201120251300-3','kchelstowski','0.9.x/changelog-2025-11-20-1300-rename-transaction-source-columns.xml','2026-10-13 06:22:52',907,'EXECUTED','8:136764e0d0d2b6b137c0449de88c89ed','renameColumn newColumnName=destination_id, oldColumnName=destination, tableName=transaction_source; dropForeignKeyConstraint baseTableName=transaction_source, constraintName=fk_transaction_source_destination; addForeignKeyConstraint baseTableName=...','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('201120251300-4','kchelstowski','0.9.x/changelog-2025-11-20-1300-rename-transaction-source-columns.xml','2026-10-13 06:22:52',908,'EXECUTED','8:0869bb01a5e4f479915cad47018f03f5','renameColumn newColumnName=shipment_id, oldColumnName=shipment, tableName=transaction_source; dropForeignKeyConstraint baseTableName=transaction_source, constraintName=fk_transaction_source_shipment; addForeignKeyConstraint baseTableName=transacti...','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('201120251300-5','kchelstowski','0.9.x/changelog-2025-11-20-1300-rename-transaction-source-columns.xml','2026-10-13 06:22:53',909,'EXECUTED','8:2779773bd700fa7fad307938c48d9074','renameColumn newColumnName=requisition_id, oldColumnName=requisition, tableName=transaction_source; dropForeignKeyConstraint baseTableName=transaction_source, constraintName=fk_transaction_source_requisition; addForeignKeyConstraint baseTableName=...','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('201120251300-6','kchelstowski','0.9.x/changelog-2025-11-20-1300-rename-transaction-source-columns.xml','2026-10-13 06:22:53',910,'EXECUTED','8:cec98b807b80b0c1c3c7b752e6dfebfa','renameColumn newColumnName=receipt_id, oldColumnName=receipt, tableName=transaction_source; dropForeignKeyConstraint baseTableName=transaction_source, constraintName=fk_transaction_source_receipt; addForeignKeyConstraint baseTableName=transaction_...','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('201120251300-7','kchelstowski','0.9.x/changelog-2025-11-20-1300-rename-transaction-source-columns.xml','2026-10-13 06:22:53',911,'EXECUTED','8:bd0ad3d6243f42c2e19673b05fb9080f','renameColumn newColumnName=order_id, oldColumnName=order, tableName=transaction_source; dropForeignKeyConstraint baseTableName=transaction_source, constraintName=fk_transaction_source_order; addForeignKeyConstraint baseTableName=transaction_source...','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('201120251300-8','kchelstowski','0.9.x/changelog-2025-11-20-1300-rename-transaction-source-columns.xml','2026-10-13 06:22:53',912,'EXECUTED','8:91b4d60c43f0d6ff3b6b6f099997c593','renameColumn newColumnName=cycle_count_id, oldColumnName=cycle_count, tableName=transaction_source; dropForeignKeyConstraint baseTableName=transaction_source, constraintName=fk_transaction_source_cycle_count; addForeignKeyConstraint baseTableName=...','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('101220251400-0','kchelstowski','0.9.x/changelog-2025-12-10-1400-add-accurate-column-to-transaction-source.xml','2026-10-13 06:22:53',913,'EXECUTED','8:309d1a6ba6d3bea2050611c7e1c8d791','addColumn tableName=transaction_source','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('190120261500-1','kchelstowski','0.9.x/changelog-2026-01-19-1500-add-assigning-parent-to-product-column-to-category.xml','2026-10-13 06:22:53',914,'EXECUTED','8:9904f1b27a3888a2411822fafc030586','addColumn tableName=category','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('100220260000-0','ewaterman','0.9.x/changelog-2026-02-10-0000-create-table-event-log.xml','2026-10-13 06:22:53',915,'EXECUTED','8:8dd9860293f58d0d65151cc24bc96bf7','createTable tableName=event_log','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('100220260000-1','ewaterman','0.9.x/changelog-2026-02-10-0000-create-table-event-log.xml','2026-10-13 06:22:53',916,'EXECUTED','8:992b0509e273ffade72250286670ddf8','addForeignKeyConstraint baseTableName=event_log, constraintName=fk_event_log_event, referencedTableName=event','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('100220260000-2','ewaterman','0.9.x/changelog-2026-02-10-0000-create-table-event-log.xml','2026-10-13 06:22:53',917,'EXECUTED','8:7c1f556e61fb6d869f0f3bc228363b63','addForeignKeyConstraint baseTableName=event_log, constraintName=fk_event_log_location, referencedTableName=location','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('100220260000-3','ewaterman','0.9.x/changelog-2026-02-10-0000-create-table-event-log.xml','2026-10-13 06:22:53',918,'EXECUTED','8:46b144dbd6da352ec74e54e034c6c8dc','addForeignKeyConstraint baseTableName=event_log, constraintName=fk_event_log_created_by, referencedTableName=user','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('100220260000-4','ewaterman','0.9.x/changelog-2026-02-10-0000-create-table-event-log.xml','2026-10-13 06:22:53',919,'EXECUTED','8:97e5c65b1ec2efc807eaae4f8ab671b3','addForeignKeyConstraint baseTableName=event_log, constraintName=fk_event_log_updated_by, referencedTableName=user','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('100220261200-0','ewaterman','0.9.x/changelog-2026-02-10-1200-create-table-shipment-event-log.xml','2026-10-13 06:22:53',920,'EXECUTED','8:941cc33f92b8ab2b6ebc37b51b549844','createTable tableName=shipment_event_log','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('100220261200-1','ewaterman','0.9.x/changelog-2026-02-10-1200-create-table-shipment-event-log.xml','2026-10-13 06:22:53',921,'EXECUTED','8:8962fdcf09803ba09afce1bdfdb5009f','addForeignKeyConstraint baseTableName=shipment_event_log, constraintName=fk_shipment_event_log_shipment, referencedTableName=shipment','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('100220261200-2','ewaterman','0.9.x/changelog-2026-02-10-1200-create-table-shipment-event-log.xml','2026-10-13 06:22:53',922,'EXECUTED','8:4772e8f149f4e7c55326c2600cb81a71','addForeignKeyConstraint baseTableName=shipment_event_log, constraintName=fk_shipment_event_log_event_log, referencedTableName=event_log','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('300320260000-0','ewaterman','0.9.x/changelog-2026-03-30-0000-create-table-order-event-log.xml','2026-10-13 06:22:53',923,'EXECUTED','8:613adef2a3bbfaf013b3922bb8a4251f','createTable tableName=order_event_log','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('300320260000-1','ewaterman','0.9.x/changelog-2026-03-30-0000-create-table-order-event-log.xml','2026-10-13 06:22:53',924,'EXECUTED','8:a4defac21ef356e34f8f3458675feb91','addForeignKeyConstraint baseTableName=order_event_log, constraintName=fk_order_event_log_order, referencedTableName=order','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('300320260000-2','ewaterman','0.9.x/changelog-2026-03-30-0000-create-table-order-event-log.xml','2026-10-13 06:22:53',925,'EXECUTED','8:7cc7e8fd3c86245f2da3047518ec88be','addForeignKeyConstraint baseTableName=order_event_log, constraintName=fk_order_event_log_event_log, referencedTableName=event_log','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('040120261400-0','anadolny','0.9.x/changelog-2026-04-01-1500-add-unique-constraint-party-code.xml','2026-10-13 06:22:53',926,'MARK_RAN','8:22896aa802ffea52a828c0ab068cd43c','sql','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('040120261400-1','anadolny','0.9.x/changelog-2026-04-01-1500-add-unique-constraint-party-code.xml','2026-10-13 06:22:53',927,'EXECUTED','8:59f769e4ab80de987fdcdaa789abc0d8','addUniqueConstraint constraintName=unique_party_code, tableName=party','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('260420260000-0','ewaterman','0.9.x/changelog-2026-04-29-0000-add-active-to-event-type.xml','2026-10-13 06:22:53',928,'EXECUTED','8:d463a4d979066042fcd5af0c16a59c6e','addColumn tableName=event_type','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('210720261200-0','awalkowiak','0.9.x/changelog-2026-07-21-1200-add-shipping-xls-template-document-type.xml','2026-10-13 06:22:53',929,'EXECUTED','8:e5ec9952aaf490a4d2bbaf8d2fb592c0','insert tableName=document_type','',NULL,'3.10.1',NULL,NULL,'1872545501'),
('1580848680306-1','jmiranda','views/changelog.xml','2026-10-13 07:49:26',1040,'RERAN','8:397769d5edde13e082a508dd6dc51fd5','sqlFile','',NULL,'3.10.1',NULL,NULL,'1877765999'),
('1580848680306-1b','jmiranda','views/changelog.xml','2026-10-13 07:49:26',1041,'RERAN','8:e3b47f5b3c2f70b8eedb83f765ae9137','sqlFile','',NULL,'3.10.1',NULL,NULL,'1877765999'),
('1580848680306-2','jmiranda','views/changelog.xml','2026-10-13 07:49:26',1042,'RERAN','8:66e7aeb7d7c77b5aaf6ff55cf4dbb66f','sqlFile','',NULL,'3.10.1',NULL,NULL,'1877765999'),
('1580848680306-3','jmiranda','views/changelog.xml','2026-10-13 07:49:26',1043,'RERAN','8:9eb6342a7206f8478872527d1ad837c2','sqlFile','',NULL,'3.10.1',NULL,NULL,'1877765999'),
('1580848680306-4','jmiranda','views/changelog.xml','2026-10-13 07:49:26',1044,'RERAN','8:5ac0a83a91869ae07ed5ecef9a3fa31c','sqlFile','',NULL,'3.10.1',NULL,NULL,'1877765999'),
('1580848680306-5','jmiranda','views/changelog.xml','2026-10-13 07:49:26',1045,'RERAN','8:97921c21bbf3dee1eff6199e2f64e9b1','sqlFile','',NULL,'3.10.1',NULL,NULL,'1877765999'),
('1580848680306-6','jmiranda','views/changelog.xml','2026-10-13 07:49:26',1046,'RERAN','8:e83dd20b317dd9175ab2aeb92506c12d','sqlFile','',NULL,'3.10.1',NULL,NULL,'1877765999'),
('1580848680306-7','jmiranda','views/changelog.xml','2026-10-13 07:49:26',1047,'RERAN','8:3a3eb4489840fb1ff91c03f7acfb3812','sqlFile','',NULL,'3.10.1',NULL,NULL,'1877765999'),
('1580848680306-8','jmiranda','views/changelog.xml','2026-10-13 07:49:26',1048,'RERAN','8:6765aacee0a2ef4127563859fab6ff72','sqlFile','',NULL,'3.10.1',NULL,NULL,'1877765999'),
('1580848680306-9','jmiranda','views/changelog.xml','2026-10-13 07:49:26',1049,'RERAN','8:5b51107029ba03a1c69cc523bb6c9f04','sqlFile','',NULL,'3.10.1',NULL,NULL,'1877765999'),
('1580848680306-10','dhatala','views/changelog.xml','2026-10-13 07:49:26',1050,'RERAN','8:360d2bcdbed9c13c9dcf0dfc3c0cd90f','sqlFile','',NULL,'3.10.1',NULL,NULL,'1877765999'),
('1580848680306-11','jmiranda','views/changelog.xml','2026-10-13 07:49:26',1051,'RERAN','8:f0993fbb430ee2f59c44e6b087959411','sqlFile','',NULL,'3.10.1',NULL,NULL,'1877765999'),
('1580848680306-13','jmiranda','views/changelog.xml','2026-10-13 07:49:26',1052,'RERAN','8:10cbd261c826679b1ed39e990254ebef','sqlFile','',NULL,'3.10.1',NULL,NULL,'1877765999'),
('1580848680306-14','dhatala','views/changelog.xml','2026-10-13 07:49:26',1053,'RERAN','8:bfbc69bff0ec95267d28426bcbb12310','sqlFile','',NULL,'3.10.1',NULL,NULL,'1877765999'),
('1580848680306-15','dhatala','views/changelog.xml','2026-10-13 07:49:26',1054,'RERAN','8:aa010d5e95ac867bd37723d939e67fca','sqlFile','',NULL,'3.10.1',NULL,NULL,'1877765999'),
('1580848680306-16','dhatala','views/changelog.xml','2026-10-13 07:49:26',1055,'RERAN','8:e407a21aeff6b0b8cea801641762c073','sqlFile','',NULL,'3.10.1',NULL,NULL,'1877765999'),
('1580848680306-17','dhatala','views/changelog.xml','2026-10-13 07:49:26',1056,'RERAN','8:a77bffadc40f56b7cb4f182b3c5bfd83','sqlFile','',NULL,'3.10.1',NULL,NULL,'1877765999'),
('1580848680306-18','jmiranda','views/changelog.xml','2026-10-13 07:49:26',1057,'RERAN','8:278336aa5adf680f36793bd2ae4f3ca7','sqlFile','',NULL,'3.10.1',NULL,NULL,'1877765999'),
('1580848680306-19','dhatala','views/changelog.xml','2026-10-13 07:49:26',1058,'RERAN','8:1f92d3e0ad1d65d3b1ae1ba99866a741','sqlFile','',NULL,'3.10.1',NULL,NULL,'1877765999'),
('1580848680306-20','dhatala','views/changelog.xml','2026-10-13 07:49:26',1059,'RERAN','8:173732be985ec7db311b50fc9c93e182','sqlFile','',NULL,'3.10.1',NULL,NULL,'1877765999'),
('1580848680306-21','pmuchowski','views/changelog.xml','2026-10-13 07:49:26',1060,'RERAN','8:7f07b24364355455ffaffeb10e118c32','sqlFile','',NULL,'3.10.1',NULL,NULL,'1877765999'),
('1580848680306-22','dhatala','views/changelog.xml','2026-10-13 07:49:26',1061,'RERAN','8:51eb5cd464c03c29d6360cc184de8e39','sqlFile','',NULL,'3.10.1',NULL,NULL,'1877765999'),
('1580848680306-23','awalkowiak','views/changelog.xml','2026-10-13 07:49:26',1062,'RERAN','8:94c0906905dc7b04e12b823ae5001d53','sqlFile','',NULL,'3.10.1',NULL,NULL,'1877765999'),
('1580848680306-23b','awalkowiak','views/changelog.xml','2026-10-13 07:49:26',1063,'RERAN','8:88342fb51f5b2c8f9364b3b14cb70200','sqlFile','',NULL,'3.10.1',NULL,NULL,'1877765999'),
('1580848680306-24','pmuchowski','views/changelog.xml','2026-10-13 07:49:26',1064,'RERAN','8:bd69dbca00453f93023a05855cea9074','sqlFile','',NULL,'3.10.1',NULL,NULL,'1877765999'),
('1580848680306-25','dbienkowska','views/changelog.xml','2026-10-13 07:49:26',1065,'RERAN','8:7eda099350d047a0091203b079e7c8b6','sqlFile','',NULL,'3.10.1',NULL,NULL,'1877765999'),
('1580848680306-26','awalkowiak','views/changelog.xml','2026-10-13 07:49:26',1066,'RERAN','8:75e8c81390fa398879f50358226388c6','sqlFile','',NULL,'3.10.1',NULL,NULL,'1877765999'),
('1580848680306-27','pmuchowski','views/changelog.xml','2026-10-13 07:49:26',1067,'RERAN','8:b2228e8ff0eaf062ce52a116721c9caa','sqlFile','',NULL,'3.10.1',NULL,NULL,'1877765999'),
('1580848680306-28','pmuchowski','views/changelog.xml','2026-10-13 07:49:26',1068,'RERAN','8:77e0182d3f995f1b26c775833b77fef5','sqlFile','',NULL,'3.10.1',NULL,NULL,'1877765999'),
('1580848680306-29','awalkowiak','views/changelog.xml','2026-10-13 07:49:26',1069,'RERAN','8:eca0f558330e2c936090d46df2a0c606','sqlFile','',NULL,'3.10.1',NULL,NULL,'1877765999'),
('1580848680306-30','awalkowiak','views/changelog.xml','2026-10-13 07:49:26',1070,'RERAN','8:e6716f13f8fe0b71c00914996c461682','sqlFile','',NULL,'3.10.1',NULL,NULL,'1877765999'),
('1740696149645-0','kchelstowski','views/changelog.xml','2026-10-13 07:49:26',1071,'RERAN','8:c4710bab5dbde7a3dd3eb42afcead71c','sqlFile','',NULL,'3.10.1',NULL,NULL,'1877765999'),
('1748970410098-6','kchelstowski','views/changelog.xml','2026-10-13 07:49:27',1072,'RERAN','8:c557346af906770588fa5949154e8b0c','sqlFile','',NULL,'3.10.1',NULL,NULL,'1877765999'),
('1740696149645-1','jmiranda','views/changelog.xml','2026-10-13 07:49:27',1073,'RERAN','8:e72d8aab6986e786e46d15c50b8d2000','sqlFile','',NULL,'3.10.1',NULL,NULL,'1877765999'),
('1740696149645-2','jmiranda','views/changelog.xml','2026-10-13 07:49:27',1074,'RERAN','8:3cc580f38b5afd53d69825d3342ede79','sqlFile','',NULL,'3.10.1',NULL,NULL,'1877765999'),
('1740696149645-3','jmiranda','views/changelog.xml','2026-10-13 07:49:27',1075,'RERAN','8:f38bd84a7926b20c7cfa4a10e28608cd','sqlFile','',NULL,'3.10.1',NULL,NULL,'1877765999'),
('1740696149645-4','jmiranda','views/changelog.xml','2026-10-13 07:49:27',1076,'RERAN','8:1180b84bae9d50e5d46319ef0fe5e98f','sqlFile','',NULL,'3.10.1',NULL,NULL,'1877765999'),
('1740696149645-7','jmiranda','views/changelog.xml','2026-10-13 07:49:27',1077,'RERAN','8:54a7d75f960a7c5180fc49624f2979e8','sqlFile','',NULL,'3.10.1',NULL,NULL,'1877765999'),
('1740696149645-6','jmiranda','views/changelog.xml','2026-10-13 07:49:27',1078,'RERAN','8:9ed3130e9b245c48d061f1fcbead4531','sqlFile','',NULL,'3.10.1',NULL,NULL,'1877765999'),
('1740696149645-5','jmiranda','views/changelog.xml','2026-10-13 07:49:27',1079,'RERAN','8:29798a3ae4b9346f8f73f747186f63f2','sqlFile','',NULL,'3.10.1',NULL,NULL,'1877765999'),
('1580848680306-31','kchelstowski','views/changelog.xml','2026-10-13 07:49:27',1080,'RERAN','8:728672942ebfd26c455a4bb9bb45d110','sqlFile','',NULL,'3.10.1',NULL,NULL,'1877765999'),
('1740696149645-8','jmiranda','views/changelog.xml','2026-10-13 07:49:27',1081,'RERAN','8:089203da62a945b913e2bdd272309781','sqlFile','',NULL,'3.10.1',NULL,NULL,'1877765999'),
('1740696149645-9','kchelstowski','views/changelog.xml','2026-10-13 07:49:27',1082,'RERAN','8:ff6f29c14b50a2f28e93e63d9cb9aa32','sqlFile','',NULL,'3.10.1',NULL,NULL,'1877765999'),
('1746501428101-','jmiranda','views/changelog.xml','2026-10-13 07:49:27',1083,'RERAN','8:4b6f1d1300dc305f2d3ff5295b85d35a','sqlFile','',NULL,'3.10.1',NULL,NULL,'1877765999'),
('1746501428101-2','jmiranda','views/changelog.xml','2026-10-13 07:49:27',1084,'RERAN','8:2fd52d2df464c8c3cc910a2d5d5d892f','sqlFile','',NULL,'3.10.1',NULL,NULL,'1877765999'),
('1748970410098-1','jmiranda','views/changelog.xml','2026-10-13 07:49:27',1085,'RERAN','8:0a3de22be4b5122d6d55a05c4d3183da','sqlFile','',NULL,'3.10.1',NULL,NULL,'1877765999'),
('1748970410098-3','jmiranda','views/changelog.xml','2026-10-13 07:49:27',1086,'RERAN','8:6e3ca0ee92283727529a0a151266e08a','sqlFile','',NULL,'3.10.1',NULL,NULL,'1877765999'),
('1748970410098-2','jmiranda','views/changelog.xml','2026-10-13 07:49:27',1087,'RERAN','8:0f752a817d02d80367227d7b0538466b','sqlFile','',NULL,'3.10.1',NULL,NULL,'1877765999'),
('1748970410098-3','slib','views/changelog.xml','2026-10-13 07:49:27',1088,'RERAN','8:a2a212a753e9ad6b702977d32972c97a','sqlFile','',NULL,'3.10.1',NULL,NULL,'1877765999'),
('1748970410098-4','slib','views/changelog.xml','2026-10-13 07:49:27',1089,'RERAN','8:887e07f1bc54802d351ae6f2c673f05f','sqlFile','',NULL,'3.10.1',NULL,NULL,'1877765999'),
('1748970410098-5','kchelstowski','views/changelog.xml','2026-10-13 07:49:27',1090,'RERAN','8:34f1720daf941bc9f17ee2146371b8db','sqlFile','',NULL,'3.10.1',NULL,NULL,'1877765999'),
('1748970410098-5b','kchelstowski','views/changelog.xml','2026-10-13 07:49:27',1091,'RERAN','8:e068294a8d63e8cc6087ee68af645d5f','sqlFile','',NULL,'3.10.1',NULL,NULL,'1877765999'),
('1748970410098-7','kchelstowski','views/changelog.xml','2026-10-13 07:49:27',1092,'RERAN','8:77b197610551b5bf09e71292fcce11ff','sqlFile','',NULL,'3.10.1',NULL,NULL,'1877765999'),
('1748970410098-8','slib','views/changelog.xml','2026-10-13 07:49:27',1093,'RERAN','8:5416a4a5b204f2fd6c70f40348334acb','sqlFile','',NULL,'3.10.1',NULL,NULL,'1877765999');
/*!40000 ALTER TABLE `DATABASECHANGELOG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DATABASECHANGELOGLOCK`
--

DROP TABLE IF EXISTS `DATABASECHANGELOGLOCK`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `DATABASECHANGELOGLOCK` (
  `ID` int(11) NOT NULL,
  `LOCKED` bit(1) NOT NULL,
  `LOCKGRANTED` datetime DEFAULT NULL,
  `LOCKEDBY` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DATABASECHANGELOGLOCK`
--

LOCK TABLES `DATABASECHANGELOGLOCK` WRITE;
/*!40000 ALTER TABLE `DATABASECHANGELOGLOCK` DISABLE KEYS */;
INSERT INTO `DATABASECHANGELOGLOCK` VALUES
(1,'\0',NULL,NULL);
/*!40000 ALTER TABLE `DATABASECHANGELOGLOCK` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `address`
--

DROP TABLE IF EXISTS `address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `address` (
  `id` char(38) NOT NULL,
  `version` bigint(20) NOT NULL,
  `address` varchar(255) NOT NULL,
  `address2` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `last_updated` datetime NOT NULL,
  `postal_code` varchar(255) DEFAULT NULL,
  `state_or_province` varchar(255) DEFAULT NULL,
  `description` varchar(4000) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `address`
--

LOCK TABLES `address` WRITE;
/*!40000 ALTER TABLE `address` DISABLE KEYS */;
INSERT INTO `address` VALUES
('1',0,'888 Commonwealth Avenue','Third Floor','Boston','United States','2010-08-25 00:00:00','2010-08-25 00:00:00','02215','MA',NULL),
('2',0,'1000 State Street','Building A','Miami','United States','2010-08-25 00:00:00','2010-08-25 00:00:00','33126','FL',NULL),
('3',0,'12345 Main Street','Suite 401','Tabarre','Haiti','2010-08-25 00:00:00','2010-08-25 00:00:00',NULL,NULL,NULL),
('4',0,'2482 Massachusetts Ave','','Boston','United Status','2010-08-25 00:00:00','2010-08-25 00:00:00','02215','MA',NULL);
/*!40000 ALTER TABLE `address` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `adjustment_candidate`
--

DROP TABLE IF EXISTS `adjustment_candidate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `adjustment_candidate` (
  `transaction_id` char(38) DEFAULT NULL,
  `product_id` char(38) DEFAULT NULL,
  `transaction_date` datetime NOT NULL,
  `inventory_id` char(38) DEFAULT NULL,
  `facility_id` char(38) NOT NULL,
  KEY `idx_product_inventory_date` (`product_id`,`inventory_id`,`transaction_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `adjustment_candidate`
--

LOCK TABLES `adjustment_candidate` WRITE;
/*!40000 ALTER TABLE `adjustment_candidate` DISABLE KEYS */;
/*!40000 ALTER TABLE `adjustment_candidate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `attribute`
--

DROP TABLE IF EXISTS `attribute`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `attribute` (
  `id` char(38) NOT NULL,
  `version` bigint(20) NOT NULL,
  `date_created` datetime NOT NULL,
  `last_updated` datetime NOT NULL,
  `name` varchar(255) NOT NULL,
  `allow_other` bit(1) DEFAULT NULL,
  `active` bit(1) DEFAULT NULL,
  `allow_multiple` bit(1) DEFAULT NULL,
  `code` varchar(255) DEFAULT NULL,
  `default_value` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `required` bit(1) DEFAULT NULL,
  `exportable` bit(1) DEFAULT b'1',
  `unit_of_measure_class_id` char(38) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `FKC7AA9C4013CE80` (`unit_of_measure_class_id`),
  CONSTRAINT `FKC7AA9C4013CE80` FOREIGN KEY (`unit_of_measure_class_id`) REFERENCES `unit_of_measure_class` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attribute`
--

LOCK TABLES `attribute` WRITE;
/*!40000 ALTER TABLE `attribute` DISABLE KEYS */;
/*!40000 ALTER TABLE `attribute` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `attribute_entity_type_codes`
--

DROP TABLE IF EXISTS `attribute_entity_type_codes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `attribute_entity_type_codes` (
  `attribute_id` char(38) DEFAULT NULL,
  `entity_type_code` varchar(255) DEFAULT NULL,
  KEY `FK38EE09DA47B0D087` (`attribute_id`),
  CONSTRAINT `FK38EE09DA47B0D087` FOREIGN KEY (`attribute_id`) REFERENCES `attribute` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attribute_entity_type_codes`
--

LOCK TABLES `attribute_entity_type_codes` WRITE;
/*!40000 ALTER TABLE `attribute_entity_type_codes` DISABLE KEYS */;
/*!40000 ALTER TABLE `attribute_entity_type_codes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `attribute_options`
--

DROP TABLE IF EXISTS `attribute_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `attribute_options` (
  `attribute_id` char(38) DEFAULT NULL,
  `options_string` varchar(255) DEFAULT NULL,
  `options_idx` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attribute_options`
--

LOCK TABLES `attribute_options` WRITE;
/*!40000 ALTER TABLE `attribute_options` DISABLE KEYS */;
/*!40000 ALTER TABLE `attribute_options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `budget_code`
--

DROP TABLE IF EXISTS `budget_code`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `budget_code` (
  `id` char(38) NOT NULL,
  `code` longtext NOT NULL,
  `name` longtext DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `organization_id` char(38) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `last_updated` datetime DEFAULT NULL,
  `created_by_id` char(38) DEFAULT NULL,
  `updated_by_id` char(38) DEFAULT NULL,
  `active` bit(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_budget_code_created_by` (`created_by_id`),
  KEY `fk_budget_code_organization` (`organization_id`),
  KEY `fk_budget_code_updated_by` (`updated_by_id`),
  CONSTRAINT `fk_budget_code_created_by` FOREIGN KEY (`created_by_id`) REFERENCES `user` (`id`),
  CONSTRAINT `fk_budget_code_organization` FOREIGN KEY (`organization_id`) REFERENCES `party` (`id`),
  CONSTRAINT `fk_budget_code_updated_by` FOREIGN KEY (`updated_by_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `budget_code`
--

LOCK TABLES `budget_code` WRITE;
/*!40000 ALTER TABLE `budget_code` DISABLE KEYS */;
/*!40000 ALTER TABLE `budget_code` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `category` (
  `id` char(38) NOT NULL,
  `version` bigint(20) NOT NULL,
  `date_created` datetime NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `last_updated` datetime NOT NULL,
  `name` varchar(255) NOT NULL,
  `parent_category_id` char(38) DEFAULT NULL,
  `sort_order` int(11) DEFAULT NULL,
  `is_root` tinyint(3) DEFAULT NULL,
  `gl_account_id` char(38) DEFAULT NULL,
  `assigning_parent_to_product_enabled` bit(1) DEFAULT b'0',
  PRIMARY KEY (`id`),
  KEY `FK302BCFE619A2EF8` (`parent_category_id`),
  KEY `fk_category_gl_account` (`gl_account_id`),
  CONSTRAINT `FK302BCFE619A2EF8` FOREIGN KEY (`parent_category_id`) REFERENCES `category` (`id`),
  CONSTRAINT `fk_category_gl_account` FOREIGN KEY (`gl_account_id`) REFERENCES `gl_account` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category`
--

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` VALUES
('seed-cat-batik',0,'2026-10-13 07:48:45',NULL,'2026-10-13 07:48:45','Batik','seed-cat-root',5,0,NULL,'\0'),
('seed-cat-buku',0,'2026-10-13 07:48:45',NULL,'2026-10-13 07:48:45','Buku','seed-cat-root',3,0,NULL,'\0'),
('seed-cat-busana',0,'2026-10-13 07:48:45',NULL,'2026-10-13 07:48:45','Busana Muslimah','seed-cat-root',7,0,NULL,'\0'),
('seed-cat-ihrom',0,'2026-10-13 07:48:45',NULL,'2026-10-13 07:48:45','Ihrom','seed-cat-root',8,0,NULL,'\0'),
('seed-cat-koper',0,'2026-10-13 07:48:45',NULL,'2026-10-13 07:48:45','Koper','seed-cat-root',1,0,NULL,'\0'),
('seed-cat-root',0,'2026-10-13 07:48:45',NULL,'2026-10-13 07:48:45','ROOT',NULL,0,1,NULL,'\0'),
('seed-cat-seragam',0,'2026-10-13 07:48:45',NULL,'2026-10-13 07:48:45','Seragam','seed-cat-root',6,0,NULL,'\0'),
('seed-cat-syal',0,'2026-10-13 07:48:45',NULL,'2026-10-13 07:48:45','Syal','seed-cat-root',4,0,NULL,'\0'),
('seed-cat-tas',0,'2026-10-13 07:48:45',NULL,'2026-10-13 07:48:45','Tas','seed-cat-root',2,0,NULL,'\0');
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comment`
--

DROP TABLE IF EXISTS `comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `comment` (
  `id` char(38) NOT NULL,
  `version` bigint(20) NOT NULL,
  `comment` text DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `date_read` datetime DEFAULT NULL,
  `date_sent` datetime DEFAULT NULL,
  `last_updated` datetime NOT NULL,
  `recipient_id` char(38) DEFAULT NULL,
  `sender_id` char(38) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK38A5EE5FAF1302EB` (`sender_id`),
  KEY `FK38A5EE5FF885F087` (`recipient_id`),
  CONSTRAINT `FK38A5EE5FAF1302EB` FOREIGN KEY (`sender_id`) REFERENCES `user` (`id`),
  CONSTRAINT `FK38A5EE5FF885F087` FOREIGN KEY (`recipient_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comment`
--

LOCK TABLES `comment` WRITE;
/*!40000 ALTER TABLE `comment` DISABLE KEYS */;
/*!40000 ALTER TABLE `comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `consumption`
--

DROP TABLE IF EXISTS `consumption`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `consumption` (
  `id` char(38) NOT NULL,
  `version` bigint(20) NOT NULL,
  `day` int(11) DEFAULT NULL,
  `inventory_item_id` char(38) DEFAULT NULL,
  `month` int(11) DEFAULT NULL,
  `product_id` char(38) DEFAULT NULL,
  `year` int(11) DEFAULT NULL,
  `location_id` char(38) DEFAULT NULL,
  `transaction_date` datetime DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `last_updated` datetime DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKCD71F39B8ABEBD5` (`location_id`),
  KEY `FKCD71F39BAA992CED` (`inventory_item_id`),
  KEY `FKCD71F39BDED5FAE7` (`product_id`),
  CONSTRAINT `FKCD71F39B8ABEBD5` FOREIGN KEY (`location_id`) REFERENCES `location` (`id`),
  CONSTRAINT `FKCD71F39BAA992CED` FOREIGN KEY (`inventory_item_id`) REFERENCES `inventory_item` (`id`),
  CONSTRAINT `FKCD71F39BDED5FAE7` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `consumption`
--

LOCK TABLES `consumption` WRITE;
/*!40000 ALTER TABLE `consumption` DISABLE KEYS */;
/*!40000 ALTER TABLE `consumption` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `consumption_fact`
--

DROP TABLE IF EXISTS `consumption_fact`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `consumption_fact` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `version` bigint(20) NOT NULL,
  `date_created` datetime NOT NULL,
  `last_updated` datetime NOT NULL,
  `location_key_id` bigint(20) NOT NULL,
  `lot_key_id` bigint(20) NOT NULL,
  `product_key_id` bigint(20) NOT NULL,
  `quantity` decimal(19,2) NOT NULL,
  `transaction_code` varchar(255) NOT NULL,
  `transaction_date_key_id` bigint(20) NOT NULL,
  `transaction_number` varchar(255) NOT NULL,
  `transaction_type` varchar(255) NOT NULL,
  `unit_cost` decimal(19,2) NOT NULL,
  `unit_price` decimal(19,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKA8B7A49072882836` (`product_key_id`),
  KEY `FKA8B7A490A27827C2` (`location_key_id`),
  KEY `FKA8B7A490CA32CFEF` (`transaction_date_key_id`),
  KEY `FKA8B7A490D1F27172` (`lot_key_id`),
  CONSTRAINT `FKA8B7A49072882836` FOREIGN KEY (`product_key_id`) REFERENCES `product_dimension` (`id`),
  CONSTRAINT `FKA8B7A490A27827C2` FOREIGN KEY (`location_key_id`) REFERENCES `location_dimension` (`id`),
  CONSTRAINT `FKA8B7A490CA32CFEF` FOREIGN KEY (`transaction_date_key_id`) REFERENCES `date_dimension` (`id`),
  CONSTRAINT `FKA8B7A490D1F27172` FOREIGN KEY (`lot_key_id`) REFERENCES `lot_dimension` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `consumption_fact`
--

LOCK TABLES `consumption_fact` WRITE;
/*!40000 ALTER TABLE `consumption_fact` DISABLE KEYS */;
/*!40000 ALTER TABLE `consumption_fact` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `container`
--

DROP TABLE IF EXISTS `container`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `container` (
  `id` char(38) NOT NULL,
  `version` bigint(20) NOT NULL,
  `container_number` varchar(255) DEFAULT NULL,
  `container_type_id` char(38) DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `height` float(12,3) DEFAULT NULL,
  `last_updated` datetime NOT NULL,
  `length` float(12,3) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `parent_container_id` char(38) DEFAULT NULL,
  `recipient_id` char(38) DEFAULT NULL,
  `shipment_id` char(38) DEFAULT NULL,
  `volume_units` varchar(255) DEFAULT NULL,
  `weight` float(12,3) DEFAULT NULL,
  `weight_units` varchar(255) DEFAULT NULL,
  `width` float(12,3) DEFAULT NULL,
  `container_status` varchar(255) DEFAULT NULL,
  `sort_order` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKE7814C8117A6E251` (`container_type_id`),
  KEY `FKE7814C813B5F6286` (`shipment_id`),
  KEY `FKE7814C8144979D51` (`recipient_id`),
  KEY `FKE7814C814B6A2E03` (`parent_container_id`),
  CONSTRAINT `FKE7814C8117A6E251` FOREIGN KEY (`container_type_id`) REFERENCES `container_type` (`id`),
  CONSTRAINT `FKE7814C813B5F6286` FOREIGN KEY (`shipment_id`) REFERENCES `shipment` (`id`),
  CONSTRAINT `FKE7814C8144979D51` FOREIGN KEY (`recipient_id`) REFERENCES `person` (`id`),
  CONSTRAINT `FKE7814C814B6A2E03` FOREIGN KEY (`parent_container_id`) REFERENCES `container` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `container`
--

LOCK TABLES `container` WRITE;
/*!40000 ALTER TABLE `container` DISABLE KEYS */;
/*!40000 ALTER TABLE `container` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `container_type`
--

DROP TABLE IF EXISTS `container_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `container_type` (
  `id` char(38) NOT NULL,
  `version` bigint(20) NOT NULL,
  `date_created` datetime NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `last_updated` datetime NOT NULL,
  `name` varchar(255) NOT NULL,
  `sort_order` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `container_type`
--

LOCK TABLES `container_type` WRITE;
/*!40000 ALTER TABLE `container_type` DISABLE KEYS */;
INSERT INTO `container_type` VALUES
('1',0,'2010-08-25 00:00:00',NULL,'2010-08-25 00:00:00','Container',0),
('2',0,'2010-08-25 00:00:00',NULL,'2010-08-25 00:00:00','Pallet',0),
('3',0,'2010-08-25 00:00:00',NULL,'2010-08-25 00:00:00','Suitcase',0),
('4',0,'2010-08-25 00:00:00',NULL,'2010-08-25 00:00:00','Box',0),
('5',0,'2010-08-25 00:00:00',NULL,'2010-08-25 00:00:00','Trunk',0),
('6',0,'2010-08-25 00:00:00',NULL,'2010-08-25 00:00:00','Item',0),
('7',0,'2010-08-25 00:00:00',NULL,'2010-08-25 00:00:00','Other',0),
('8',0,'2011-02-25 00:00:00',NULL,'2011-02-25 00:00:00','Crate',0);
/*!40000 ALTER TABLE `container_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cycle_count`
--

DROP TABLE IF EXISTS `cycle_count`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cycle_count` (
  `id` char(38) NOT NULL,
  `version` bigint(20) NOT NULL,
  `facility_id` char(38) NOT NULL,
  `date_last_refreshed` datetime NOT NULL,
  `date_created` datetime NOT NULL,
  `last_updated` datetime NOT NULL,
  `created_by_id` char(38) NOT NULL,
  `updated_by_id` char(38) NOT NULL,
  `status` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_cycle_count_location` (`facility_id`),
  KEY `fk_cycle_count_created_by` (`created_by_id`),
  KEY `fk_cycle_count_updated_by` (`updated_by_id`),
  CONSTRAINT `fk_cycle_count_created_by` FOREIGN KEY (`created_by_id`) REFERENCES `user` (`id`),
  CONSTRAINT `fk_cycle_count_location` FOREIGN KEY (`facility_id`) REFERENCES `location` (`id`),
  CONSTRAINT `fk_cycle_count_updated_by` FOREIGN KEY (`updated_by_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cycle_count`
--

LOCK TABLES `cycle_count` WRITE;
/*!40000 ALTER TABLE `cycle_count` DISABLE KEYS */;
/*!40000 ALTER TABLE `cycle_count` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `cycle_count_candidate`
--

DROP TABLE IF EXISTS `cycle_count_candidate`;
/*!50001 DROP VIEW IF EXISTS `cycle_count_candidate`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `cycle_count_candidate` AS SELECT
 NULL AS `id`,
 NULL AS `inventory_id`,
 NULL AS `product_id`,
 NULL AS `facility_id`,
 NULL AS `cycle_count_request_id`,
 NULL AS `abc_class`,
 NULL AS `status`,
 NULL AS `product_active`,
 NULL AS `inventory_item_count`,
 NULL AS `internal_locations`,
 NULL AS `quantity_on_hand`,
 NULL AS `quantity_allocated`,
 NULL AS `negative_item_count`,
 NULL AS `date_last_count`,
 NULL AS `days_since_last_count`,
 NULL AS `date_next_count`,
 NULL AS `days_until_next_count`,
 NULL AS `date_latest_inventory`,
 NULL AS `has_stock_on_hand_or_negative_stock`,
 NULL AS `sort_order` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `cycle_count_details`
--

DROP TABLE IF EXISTS `cycle_count_details`;
/*!50001 DROP VIEW IF EXISTS `cycle_count_details`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `cycle_count_details` AS SELECT
 NULL AS `id`,
 NULL AS `cycle_count_id`,
 NULL AS `transaction_number`,
 NULL AS `date_requested`,
 NULL AS `date_initiated`,
 NULL AS `date_recorded`,
 NULL AS `requested_by_id`,
 NULL AS `initiated_by_id`,
 NULL AS `recorded_by_id`,
 NULL AS `facility_id`,
 NULL AS `location_id`,
 NULL AS `product_id`,
 NULL AS `inventory_item_id`,
 NULL AS `blind_count_date_counted`,
 NULL AS `blind_count_assignee_id`,
 NULL AS `blind_count_quantity_on_hand`,
 NULL AS `blind_count_quantity_counted`,
 NULL AS `blind_count_quantity_variance`,
 NULL AS `blind_count_variance_percentage`,
 NULL AS `blind_count_variance_reason_code`,
 NULL AS `blind_count_variance_comment`,
 NULL AS `blind_count_count_index`,
 NULL AS `verification_count_date_counted`,
 NULL AS `verification_count_assignee_id`,
 NULL AS `verification_count_quantity_on_hand`,
 NULL AS `verification_count_quantity_counted`,
 NULL AS `verification_count_quantity_variance`,
 NULL AS `verification_count_variance_percentage`,
 NULL AS `verification_count_variance_reason_code`,
 NULL AS `verification_count_variance_comment`,
 NULL AS `verification_count_count_index` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `cycle_count_frequency`
--

DROP TABLE IF EXISTS `cycle_count_frequency`;
/*!50001 DROP VIEW IF EXISTS `cycle_count_frequency`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `cycle_count_frequency` AS SELECT
 NULL AS `abc_class`,
 NULL AS `facility_id`,
 NULL AS `frequency` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `cycle_count_item`
--

DROP TABLE IF EXISTS `cycle_count_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cycle_count_item` (
  `id` char(38) NOT NULL,
  `version` bigint(20) NOT NULL,
  `facility_id` char(38) NOT NULL,
  `cycle_count_id` char(38) NOT NULL,
  `inventory_item_id` char(38) NOT NULL,
  `product_id` char(38) NOT NULL,
  `assignee_id` char(38) DEFAULT NULL,
  `count_index` int(11) NOT NULL,
  `status` varchar(100) NOT NULL,
  `quantity_on_hand` int(11) DEFAULT NULL,
  `quantity_counted` int(11) DEFAULT NULL,
  `discrepancy_reason_code` varchar(100) DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `custom` bit(1) NOT NULL,
  `date_counted` datetime DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `last_updated` datetime NOT NULL,
  `created_by_id` char(38) NOT NULL,
  `updated_by_id` char(38) NOT NULL,
  `location_id` char(38) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_cycle_count_item_location` (`facility_id`),
  KEY `fk_cycle_count_item_created_by` (`created_by_id`),
  KEY `fk_cycle_count_item_updated_by` (`updated_by_id`),
  KEY `fk_cycle_count_item_cycle_count` (`cycle_count_id`),
  KEY `fk_cycle_count_item_inventory_item` (`inventory_item_id`),
  KEY `fk_cycle_count_item_product` (`product_id`),
  KEY `fk_cycle_count_item_bin_location` (`location_id`),
  KEY `fk_cycle_count_item_assignee` (`assignee_id`),
  CONSTRAINT `fk_cycle_count_item_assignee` FOREIGN KEY (`assignee_id`) REFERENCES `person` (`id`),
  CONSTRAINT `fk_cycle_count_item_bin_location` FOREIGN KEY (`location_id`) REFERENCES `location` (`id`),
  CONSTRAINT `fk_cycle_count_item_created_by` FOREIGN KEY (`created_by_id`) REFERENCES `user` (`id`),
  CONSTRAINT `fk_cycle_count_item_cycle_count` FOREIGN KEY (`cycle_count_id`) REFERENCES `cycle_count` (`id`),
  CONSTRAINT `fk_cycle_count_item_inventory_item` FOREIGN KEY (`inventory_item_id`) REFERENCES `inventory_item` (`id`),
  CONSTRAINT `fk_cycle_count_item_location` FOREIGN KEY (`facility_id`) REFERENCES `location` (`id`),
  CONSTRAINT `fk_cycle_count_item_product` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`),
  CONSTRAINT `fk_cycle_count_item_updated_by` FOREIGN KEY (`updated_by_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cycle_count_item`
--

LOCK TABLES `cycle_count_item` WRITE;
/*!40000 ALTER TABLE `cycle_count_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `cycle_count_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `cycle_count_metadata`
--

DROP TABLE IF EXISTS `cycle_count_metadata`;
/*!50001 DROP VIEW IF EXISTS `cycle_count_metadata`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `cycle_count_metadata` AS SELECT
 NULL AS `id`,
 NULL AS `inventory_id`,
 NULL AS `product_id`,
 NULL AS `date_counted`,
 NULL AS `abc_class`,
 NULL AS `frequency`,
 NULL AS `days_since_last_count`,
 NULL AS `date_expected`,
 NULL AS `days_until_next_count` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `cycle_count_product_summary`
--

DROP TABLE IF EXISTS `cycle_count_product_summary`;
/*!50001 DROP VIEW IF EXISTS `cycle_count_product_summary`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `cycle_count_product_summary` AS SELECT
 NULL AS `cycle_count_id`,
 NULL AS `transaction_date`,
 NULL AS `facility_id`,
 NULL AS `product_id`,
 NULL AS `quantity_variance` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `cycle_count_request`
--

DROP TABLE IF EXISTS `cycle_count_request`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cycle_count_request` (
  `id` char(38) NOT NULL,
  `version` bigint(20) NOT NULL,
  `facility_id` char(38) NOT NULL,
  `product_id` char(38) DEFAULT NULL,
  `status` varchar(100) NOT NULL,
  `cycle_count_id` char(38) DEFAULT NULL,
  `blind_count` bit(1) NOT NULL,
  `request_type` varchar(100) NOT NULL,
  `date_created` datetime NOT NULL,
  `last_updated` datetime NOT NULL,
  `created_by_id` char(38) NOT NULL,
  `updated_by_id` char(38) NOT NULL,
  `count_assignee_id` char(38) DEFAULT NULL,
  `recount_assignee_id` char(38) DEFAULT NULL,
  `count_deadline` datetime DEFAULT NULL,
  `recount_deadline` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_cycle_count_request_location` (`facility_id`),
  KEY `fk_cycle_count_request_product` (`product_id`),
  KEY `fk_cycle_count_request_created_by` (`created_by_id`),
  KEY `fk_cycle_count_request_updated_by` (`updated_by_id`),
  KEY `fk_cycle_count_request_cycle_count` (`cycle_count_id`),
  KEY `fk_cycle_count_request_count_assignee` (`count_assignee_id`),
  KEY `fk_cycle_count_request_recount_assignee` (`recount_assignee_id`),
  CONSTRAINT `fk_cycle_count_request_count_assignee` FOREIGN KEY (`count_assignee_id`) REFERENCES `person` (`id`),
  CONSTRAINT `fk_cycle_count_request_created_by` FOREIGN KEY (`created_by_id`) REFERENCES `user` (`id`),
  CONSTRAINT `fk_cycle_count_request_cycle_count` FOREIGN KEY (`cycle_count_id`) REFERENCES `cycle_count` (`id`),
  CONSTRAINT `fk_cycle_count_request_location` FOREIGN KEY (`facility_id`) REFERENCES `location` (`id`),
  CONSTRAINT `fk_cycle_count_request_product` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`),
  CONSTRAINT `fk_cycle_count_request_recount_assignee` FOREIGN KEY (`recount_assignee_id`) REFERENCES `person` (`id`),
  CONSTRAINT `fk_cycle_count_request_updated_by` FOREIGN KEY (`updated_by_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cycle_count_request`
--

LOCK TABLES `cycle_count_request` WRITE;
/*!40000 ALTER TABLE `cycle_count_request` DISABLE KEYS */;
/*!40000 ALTER TABLE `cycle_count_request` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `cycle_count_session`
--

DROP TABLE IF EXISTS `cycle_count_session`;
/*!50001 DROP VIEW IF EXISTS `cycle_count_session`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `cycle_count_session` AS SELECT
 NULL AS `id`,
 NULL AS `inventory_id`,
 NULL AS `product_id`,
 NULL AS `facility_id`,
 NULL AS `cycle_count_request_id`,
 NULL AS `abc_class`,
 NULL AS `status`,
 NULL AS `product_active`,
 NULL AS `inventory_item_count`,
 NULL AS `internal_locations`,
 NULL AS `quantity_on_hand`,
 NULL AS `quantity_allocated`,
 NULL AS `negative_item_count`,
 NULL AS `date_last_count`,
 NULL AS `days_since_last_count`,
 NULL AS `date_next_count`,
 NULL AS `days_until_next_count`,
 NULL AS `date_latest_inventory` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `cycle_count_summary`
--

DROP TABLE IF EXISTS `cycle_count_summary`;
/*!50001 DROP VIEW IF EXISTS `cycle_count_summary`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `cycle_count_summary` AS SELECT
 NULL AS `id`,
 NULL AS `cycle_count_id`,
 NULL AS `product_id`,
 NULL AS `transaction_number`,
 NULL AS `date_requested`,
 NULL AS `date_initiated`,
 NULL AS `date_recorded`,
 NULL AS `requested_by_id`,
 NULL AS `initiated_by_id`,
 NULL AS `recorded_by_id`,
 NULL AS `facility_id`,
 NULL AS `location_id`,
 NULL AS `blind_count_date_counted`,
 NULL AS `blind_count_assignee_id`,
 NULL AS `blind_count_quantity_counted`,
 NULL AS `blind_count_quantity_on_hand`,
 NULL AS `blind_count_quantity_variance`,
 NULL AS `blind_count_variance_reason_code`,
 NULL AS `blind_count_variance_comment`,
 NULL AS `verification_count_date_counted`,
 NULL AS `verification_count_assignee_id`,
 NULL AS `verification_count_quantity_counted`,
 NULL AS `verification_count_quantity_on_hand`,
 NULL AS `verification_count_quantity_variance`,
 NULL AS `verification_count_variance_reason_code`,
 NULL AS `verification_count_variance_comment` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `date_dimension`
--

DROP TABLE IF EXISTS `date_dimension`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `date_dimension` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `version` bigint(20) NOT NULL,
  `date` datetime NOT NULL,
  `day_of_month` int(11) NOT NULL,
  `day_of_week` int(11) NOT NULL,
  `month` int(11) NOT NULL,
  `month_name` varchar(255) NOT NULL,
  `month_year` varchar(255) NOT NULL,
  `week` int(11) NOT NULL,
  `weekday_name` varchar(255) NOT NULL,
  `year` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `date` (`date`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `date_dimension`
--

LOCK TABLES `date_dimension` WRITE;
/*!40000 ALTER TABLE `date_dimension` DISABLE KEYS */;
INSERT INTO `date_dimension` VALUES
(1,0,'2026-10-12 00:00:00',12,2,10,'October','10-2026',42,'Monday',2026);
/*!40000 ALTER TABLE `date_dimension` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `document`
--

DROP TABLE IF EXISTS `document`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `document` (
  `id` char(38) NOT NULL,
  `version` bigint(20) NOT NULL,
  `content_type` varchar(255) DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `document_number` varchar(255) DEFAULT NULL,
  `document_type_id` char(38) DEFAULT NULL,
  `extension` varchar(255) DEFAULT NULL,
  `file_contents` mediumblob DEFAULT NULL,
  `file_uri` longtext DEFAULT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `last_updated` datetime NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK335CD11B6631D8CC` (`document_type_id`),
  CONSTRAINT `FK335CD11B6631D8CC` FOREIGN KEY (`document_type_id`) REFERENCES `document_type` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `document`
--

LOCK TABLES `document` WRITE;
/*!40000 ALTER TABLE `document` DISABLE KEYS */;
/*!40000 ALTER TABLE `document` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `document_type`
--

DROP TABLE IF EXISTS `document_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `document_type` (
  `id` char(38) NOT NULL,
  `version` bigint(20) NOT NULL,
  `date_created` datetime NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `last_updated` datetime NOT NULL,
  `name` varchar(255) NOT NULL,
  `sort_order` int(11) DEFAULT NULL,
  `document_code` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `document_type`
--

LOCK TABLES `document_type` WRITE;
/*!40000 ALTER TABLE `document_type` DISABLE KEYS */;
INSERT INTO `document_type` VALUES
('1',0,'2010-08-25 00:00:00',NULL,'2010-08-25 00:00:00','Facture donn',0,NULL),
('2',0,'2010-08-25 00:00:00',NULL,'2010-08-25 00:00:00','Bill of Lading',0,NULL),
('3',0,'2010-08-25 00:00:00',NULL,'2010-08-25 00:00:00','Packing List',0,NULL),
('4',0,'2010-08-25 00:00:00',NULL,'2010-08-25 00:00:00','Certificate of Donation',0,NULL),
('5',0,'2010-08-25 00:00:00',NULL,'2010-08-25 00:00:00','Commercial Invoice',0,NULL),
('6',0,'2010-08-25 00:00:00',NULL,'2010-08-25 00:00:00','Material Safey Data Sheet',0,NULL),
('66762f6c61e34cfd9297ecb0fcee2df2',0,'2023-08-14 15:06:59',NULL,'2023-08-14 15:06:59','Invoice Template',0,'INVOICE_TEMPLATE'),
('7',0,'2010-08-25 00:00:00',NULL,'2010-08-25 00:00:00','Certificate of Analysis',0,NULL),
('8',0,'2010-08-25 00:00:00',NULL,'2010-08-25 00:00:00','Manifest',0,NULL),
('9',0,'2010-08-25 00:00:00',NULL,'2010-08-25 00:00:00','Other',0,NULL),
('ff80818166ac5f350166ac84c2150001',0,'2018-10-25 00:00:00',NULL,'2018-10-25 00:00:00','Shipping Template',0,'SHIPPING_TEMPLATE'),
('REQUISITION_TEMPLATE',0,'2023-08-14 15:09:29',NULL,'2023-08-14 15:09:29','Requisition Template',0,'REQUISITION_TEMPLATE'),
('SHIPPING_XLS_TEMPLATE',0,'2026-10-13 06:22:53',NULL,'2026-10-13 06:22:53','Shipping XLS Template',0,'SHIPPING_XLS_TEMPLATE');
/*!40000 ALTER TABLE `document_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `donor`
--

DROP TABLE IF EXISTS `donor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `donor` (
  `id` char(38) NOT NULL,
  `version` bigint(20) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `last_updated` datetime DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `donor`
--

LOCK TABLES `donor` WRITE;
/*!40000 ALTER TABLE `donor` DISABLE KEYS */;
INSERT INTO `donor` VALUES
('1',0,'2010-08-25 00:00:00',NULL,'2010-08-25 00:00:00','Donor Organization ABC'),
('2',0,'2010-08-25 00:00:00',NULL,'2010-08-25 00:00:00','Donor Organization XYZ'),
('3',0,'2010-08-25 00:00:00',NULL,'2010-08-25 00:00:00','Donor Organization 123');
/*!40000 ALTER TABLE `donor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `edit_page_item`
--

DROP TABLE IF EXISTS `edit_page_item`;
/*!50001 DROP VIEW IF EXISTS `edit_page_item`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `edit_page_item` AS SELECT
 NULL AS `id`,
 NULL AS `requisition_item_type`,
 NULL AS `parent_requisition_item_id`,
 NULL AS `requisition_id`,
 NULL AS `origin_id`,
 NULL AS `destination_id`,
 NULL AS `product_id`,
 NULL AS `product_code`,
 NULL AS `name`,
 NULL AS `quantity`,
 NULL AS `quantity_canceled`,
 NULL AS `quantity_revised`,
 NULL AS `quantity_counted`,
 NULL AS `sort_order`,
 NULL AS `cancel_reason_code`,
 NULL AS `comments`,
 NULL AS `substitution_status` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `event`
--

DROP TABLE IF EXISTS `event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `event` (
  `id` char(38) NOT NULL,
  `version` bigint(20) NOT NULL,
  `date_created` datetime NOT NULL,
  `event_date` datetime DEFAULT NULL,
  `event_location_id` char(38) DEFAULT NULL,
  `event_type_id` char(38) DEFAULT NULL,
  `last_updated` datetime NOT NULL,
  `created_by_id` char(38) DEFAULT NULL,
  `comment_id` char(38) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK5C6729A3D970DB4` (`event_type_id`),
  KEY `FK5C6729A4415A5B0` (`event_location_id`),
  KEY `fk_event_comment` (`comment_id`),
  KEY `fk_event_created_by` (`created_by_id`),
  CONSTRAINT `FK5C6729A3D970DB4` FOREIGN KEY (`event_type_id`) REFERENCES `event_type` (`id`),
  CONSTRAINT `FK5C6729A4415A5B0` FOREIGN KEY (`event_location_id`) REFERENCES `location` (`id`),
  CONSTRAINT `fk_event_comment` FOREIGN KEY (`comment_id`) REFERENCES `comment` (`id`),
  CONSTRAINT `fk_event_created_by` FOREIGN KEY (`created_by_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event`
--

LOCK TABLES `event` WRITE;
/*!40000 ALTER TABLE `event` DISABLE KEYS */;
/*!40000 ALTER TABLE `event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_log`
--

DROP TABLE IF EXISTS `event_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `event_log` (
  `id` char(38) NOT NULL,
  `version` bigint(20) NOT NULL,
  `event_id` char(38) DEFAULT NULL,
  `event_code` varchar(50) DEFAULT NULL,
  `event_date` datetime NOT NULL,
  `event_log_code` varchar(50) NOT NULL,
  `message` varchar(255) DEFAULT NULL,
  `location_id` char(38) DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `last_updated` datetime NOT NULL,
  `created_by_id` char(38) NOT NULL,
  `updated_by_id` char(38) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_event_log_event` (`event_id`),
  KEY `fk_event_log_location` (`location_id`),
  KEY `fk_event_log_created_by` (`created_by_id`),
  KEY `fk_event_log_updated_by` (`updated_by_id`),
  CONSTRAINT `fk_event_log_created_by` FOREIGN KEY (`created_by_id`) REFERENCES `user` (`id`),
  CONSTRAINT `fk_event_log_event` FOREIGN KEY (`event_id`) REFERENCES `event` (`id`),
  CONSTRAINT `fk_event_log_location` FOREIGN KEY (`location_id`) REFERENCES `location` (`id`),
  CONSTRAINT `fk_event_log_updated_by` FOREIGN KEY (`updated_by_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_log`
--

LOCK TABLES `event_log` WRITE;
/*!40000 ALTER TABLE `event_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_type`
--

DROP TABLE IF EXISTS `event_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `event_type` (
  `id` char(38) NOT NULL,
  `version` bigint(20) NOT NULL,
  `date_created` datetime NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `event_code` varchar(255) DEFAULT NULL,
  `last_updated` datetime NOT NULL,
  `name` varchar(255) NOT NULL,
  `sort_order` int(11) DEFAULT NULL,
  `active` bit(1) NOT NULL DEFAULT b'1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_type`
--

LOCK TABLES `event_type` WRITE;
/*!40000 ALTER TABLE `event_type` DISABLE KEYS */;
INSERT INTO `event_type` VALUES
('1738ff9b-b9fb-4369-81d6-08f61f058137',0,'2023-09-21 00:00:00','Request has been approved','APPROVED','2023-09-21 00:00:00','Approved',0,''),
('2',0,'2011-03-03 00:00:00','Shipment has been shipped','SHIPPED','2011-03-03 00:00:00','Shipped',2,''),
('3',0,'2011-03-03 00:00:00','Shipment has been received','RECEIVED','2011-03-03 00:00:00','Received',3,''),
('30e81101-e20e-47cc-aef0-9004609dd38e',0,'2023-09-21 00:00:00','Request has been submitted','SUBMITTED','2023-09-21 00:00:00','Submitted',0,''),
('32fa3298-439c-4f12-a3bc-9a29ddf11a21',0,'2023-09-21 00:00:00','Request has been rejected','REJECTED','2023-09-21 00:00:00','Rejected',0,''),
('4',0,'2018-09-10 00:00:00','Shipment has been partially received','PARTIALLY_RECEIVED','2018-09-10 00:00:00','Partially Received',3,''),
('abb5b3d2-da3e-4a4c-9e3c-de139147f822',0,'2023-09-21 00:00:00','Request has been sent for approval','PENDING_APPROVAL','2023-09-21 00:00:00','Waiting for approval',1,'');
/*!40000 ALTER TABLE `event_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `fill_rate`
--

DROP TABLE IF EXISTS `fill_rate`;
/*!50001 DROP VIEW IF EXISTS `fill_rate`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `fill_rate` AS SELECT
 NULL AS `id`,
 NULL AS `status`,
 NULL AS `quantity`,
 NULL AS `quantity_canceled`,
 NULL AS `cancel_reason_code`,
 NULL AS `requisition_item_type`,
 NULL AS `product_id`,
 NULL AS `product_code`,
 NULL AS `product_name`,
 NULL AS `transaction_date`,
 NULL AS `month`,
 NULL AS `year`,
 NULL AS `origin_id`,
 NULL AS `origin_name`,
 NULL AS `destination_id`,
 NULL AS `destination_name`,
 NULL AS `formulary`,
 NULL AS `fill_rate` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `fulfillment`
--

DROP TABLE IF EXISTS `fulfillment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fulfillment` (
  `id` char(38) NOT NULL,
  `version` bigint(20) NOT NULL,
  `date_created` datetime NOT NULL,
  `date_fulfilled` datetime DEFAULT NULL,
  `fulfilled_by_id` char(38) DEFAULT NULL,
  `last_updated` datetime NOT NULL,
  `status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK5A2551DEAC392B33` (`fulfilled_by_id`),
  CONSTRAINT `FK5A2551DEAC392B33` FOREIGN KEY (`fulfilled_by_id`) REFERENCES `person` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fulfillment`
--

LOCK TABLES `fulfillment` WRITE;
/*!40000 ALTER TABLE `fulfillment` DISABLE KEYS */;
/*!40000 ALTER TABLE `fulfillment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fulfillment_item`
--

DROP TABLE IF EXISTS `fulfillment_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fulfillment_item` (
  `id` char(38) NOT NULL,
  `version` bigint(20) NOT NULL,
  `date_created` datetime NOT NULL,
  `fulfillment_id` char(38) DEFAULT NULL,
  `inventory_item_id` char(38) DEFAULT NULL,
  `last_updated` datetime NOT NULL,
  `quantity` int(11) DEFAULT NULL,
  `requisition_item_id` char(38) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKEDC55CD447EBE106` (`requisition_item_id`),
  KEY `FKEDC55CD494567276` (`fulfillment_id`),
  KEY `FKEDC55CD4AA992CED` (`inventory_item_id`),
  CONSTRAINT `FKEDC55CD447EBE106` FOREIGN KEY (`requisition_item_id`) REFERENCES `requisition_item` (`id`),
  CONSTRAINT `FKEDC55CD494567276` FOREIGN KEY (`fulfillment_id`) REFERENCES `fulfillment` (`id`),
  CONSTRAINT `FKEDC55CD4AA992CED` FOREIGN KEY (`inventory_item_id`) REFERENCES `inventory_item` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fulfillment_item`
--

LOCK TABLES `fulfillment_item` WRITE;
/*!40000 ALTER TABLE `fulfillment_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `fulfillment_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fulfillment_item_shipment_item`
--

DROP TABLE IF EXISTS `fulfillment_item_shipment_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fulfillment_item_shipment_item` (
  `fulfillment_item_shipment_items_id` char(38) DEFAULT NULL,
  `shipment_item_id` char(38) DEFAULT NULL,
  KEY `FKE071DE6DB06EC4FB` (`shipment_item_id`),
  KEY `FKE071DE6DB42751E1` (`fulfillment_item_shipment_items_id`),
  CONSTRAINT `FKE071DE6DB06EC4FB` FOREIGN KEY (`shipment_item_id`) REFERENCES `shipment_item` (`id`),
  CONSTRAINT `FKE071DE6DB42751E1` FOREIGN KEY (`fulfillment_item_shipment_items_id`) REFERENCES `fulfillment_item` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fulfillment_item_shipment_item`
--

LOCK TABLES `fulfillment_item_shipment_item` WRITE;
/*!40000 ALTER TABLE `fulfillment_item_shipment_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `fulfillment_item_shipment_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gl_account`
--

DROP TABLE IF EXISTS `gl_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `gl_account` (
  `id` char(38) NOT NULL,
  `code` longtext NOT NULL,
  `name` longtext DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `gl_account_type_id` char(38) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `last_updated` datetime DEFAULT NULL,
  `created_by_id` char(38) DEFAULT NULL,
  `updated_by_id` char(38) DEFAULT NULL,
  `active` bit(1) DEFAULT b'1',
  PRIMARY KEY (`id`),
  KEY `fk_gl_account_created_by` (`created_by_id`),
  KEY `fk_gl_account_gl_account_type` (`gl_account_type_id`),
  KEY `fk_gl_account_updated_by` (`updated_by_id`),
  CONSTRAINT `fk_gl_account_created_by` FOREIGN KEY (`created_by_id`) REFERENCES `user` (`id`),
  CONSTRAINT `fk_gl_account_gl_account_type` FOREIGN KEY (`gl_account_type_id`) REFERENCES `gl_account_type` (`id`),
  CONSTRAINT `fk_gl_account_updated_by` FOREIGN KEY (`updated_by_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gl_account`
--

LOCK TABLES `gl_account` WRITE;
/*!40000 ALTER TABLE `gl_account` DISABLE KEYS */;
/*!40000 ALTER TABLE `gl_account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gl_account_type`
--

DROP TABLE IF EXISTS `gl_account_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `gl_account_type` (
  `id` char(38) NOT NULL,
  `code` longtext NOT NULL,
  `name` longtext DEFAULT NULL,
  `gl_account_type_code` varchar(100) DEFAULT 'ASSET',
  `date_created` datetime DEFAULT NULL,
  `last_updated` datetime DEFAULT NULL,
  `created_by_id` char(38) DEFAULT NULL,
  `updated_by_id` char(38) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_gl_account_type_created_by` (`created_by_id`),
  KEY `fk_gl_account_type_updated_by` (`updated_by_id`),
  CONSTRAINT `fk_gl_account_type_created_by` FOREIGN KEY (`created_by_id`) REFERENCES `user` (`id`),
  CONSTRAINT `fk_gl_account_type_updated_by` FOREIGN KEY (`updated_by_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gl_account_type`
--

LOCK TABLES `gl_account_type` WRITE;
/*!40000 ALTER TABLE `gl_account_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `gl_account_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `inbound_stock_movement_list_item`
--

DROP TABLE IF EXISTS `inbound_stock_movement_list_item`;
/*!50001 DROP VIEW IF EXISTS `inbound_stock_movement_list_item`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `inbound_stock_movement_list_item` AS SELECT
 NULL AS `id`,
 NULL AS `name`,
 NULL AS `identifier`,
 NULL AS `description`,
 NULL AS `origin_id`,
 NULL AS `destination_id`,
 NULL AS `date_created`,
 NULL AS `last_updated`,
 NULL AS `date_requested`,
 NULL AS `requested_by_id`,
 NULL AS `created_by_id`,
 NULL AS `updated_by_id`,
 NULL AS `shipment_id`,
 NULL AS `requisition_id`,
 NULL AS `order_id`,
 NULL AS `stocklist_id`,
 NULL AS `current_status`,
 NULL AS `shipment_type_id` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `indicator`
--

DROP TABLE IF EXISTS `indicator`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `indicator` (
  `id` char(38) NOT NULL,
  `version` bigint(20) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` varchar(2000) NOT NULL,
  `expression` text NOT NULL,
  `date_created` datetime NOT NULL,
  `last_updated` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `indicator`
--

LOCK TABLES `indicator` WRITE;
/*!40000 ALTER TABLE `indicator` DISABLE KEYS */;
/*!40000 ALTER TABLE `indicator` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory`
--

DROP TABLE IF EXISTS `inventory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventory` (
  `id` char(38) NOT NULL,
  `version` bigint(20) NOT NULL,
  `last_inventory_date` datetime DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `last_updated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory`
--

LOCK TABLES `inventory` WRITE;
/*!40000 ALTER TABLE `inventory` DISABLE KEYS */;
INSERT INTO `inventory` VALUES
('1',0,NULL,'2011-02-17 00:00:00','2011-02-17 00:00:00'),
('2',0,NULL,'2011-02-17 00:00:00','2011-02-17 00:00:00'),
('ff8081813a512a91013a512f140a0001',0,NULL,'2012-10-11 14:56:10','2012-10-11 14:56:10'),
('seed-inv-bandung',0,NULL,'2026-10-13 07:48:45','2026-10-13 07:48:45'),
('seed-inv-bintaro',0,NULL,'2026-10-13 07:48:45','2026-10-13 07:48:45'),
('seed-inv-cibubur',0,NULL,'2026-10-13 07:48:45','2026-10-13 07:48:45');
/*!40000 ALTER TABLE `inventory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `inventory_audit_details`
--

DROP TABLE IF EXISTS `inventory_audit_details`;
/*!50001 DROP VIEW IF EXISTS `inventory_audit_details`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `inventory_audit_details` AS SELECT
 NULL AS `facility_id`,
 NULL AS `facility_name`,
 NULL AS `product_id`,
 NULL AS `product_code`,
 NULL AS `product_name`,
 NULL AS `price_per_unit`,
 NULL AS `abc_class`,
 NULL AS `cycle_count_id`,
 NULL AS `transaction_id`,
 NULL AS `transaction_number`,
 NULL AS `transaction_date`,
 NULL AS `transaction_type_id`,
 NULL AS `transaction_type_name`,
 NULL AS `inventory_item_id`,
 NULL AS `location_id`,
 NULL AS `quantity_adjusted`,
 NULL AS `quantity_on_hand` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `inventory_audit_rollup`
--

DROP TABLE IF EXISTS `inventory_audit_rollup`;
/*!50001 DROP VIEW IF EXISTS `inventory_audit_rollup`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `inventory_audit_rollup` AS SELECT
 NULL AS `facility_id`,
 NULL AS `product_id`,
 NULL AS `transaction_id`,
 NULL AS `facility_name`,
 NULL AS `product_code`,
 NULL AS `transaction_number`,
 NULL AS `transaction_date`,
 NULL AS `quantity_adjusted`,
 NULL AS `price_per_unit`,
 NULL AS `abc_class`,
 NULL AS `variance_type_code` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `inventory_audit_summary`
--

DROP TABLE IF EXISTS `inventory_audit_summary`;
/*!50001 DROP VIEW IF EXISTS `inventory_audit_summary`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `inventory_audit_summary` AS SELECT
 NULL AS `facility_id`,
 NULL AS `product_id`,
 NULL AS `transaction_id`,
 NULL AS `facility_name`,
 NULL AS `product_code`,
 NULL AS `transaction_number`,
 NULL AS `transaction_date`,
 NULL AS `quantity_adjusted`,
 NULL AS `price_per_unit`,
 NULL AS `abc_class`,
 NULL AS `variance_type_code` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `inventory_baseline_candidate`
--

DROP TABLE IF EXISTS `inventory_baseline_candidate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventory_baseline_candidate` (
  `transaction_id` char(38) DEFAULT NULL,
  `product_id` char(38) DEFAULT NULL,
  `transaction_date` datetime NOT NULL,
  `inventory_id` char(38) DEFAULT NULL,
  `facility_id` char(38) NOT NULL,
  KEY `idx_inventory_product_date` (`inventory_id`,`product_id`,`transaction_date`),
  KEY `idx_transaction_id` (`transaction_id`),
  KEY `idx_product_inventory_base` (`product_id`,`inventory_id`,`transaction_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory_baseline_candidate`
--

LOCK TABLES `inventory_baseline_candidate` WRITE;
/*!40000 ALTER TABLE `inventory_baseline_candidate` DISABLE KEYS */;
/*!40000 ALTER TABLE `inventory_baseline_candidate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `inventory_counts`
--

DROP TABLE IF EXISTS `inventory_counts`;
/*!50001 DROP VIEW IF EXISTS `inventory_counts`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `inventory_counts` AS SELECT
 NULL AS `id`,
 NULL AS `transaction_id`,
 NULL AS `product_id`,
 NULL AS `facility_id`,
 NULL AS `date_recorded`,
 NULL AS `inventory_count_type_code`,
 NULL AS `associated_transaction_id` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `inventory_item`
--

DROP TABLE IF EXISTS `inventory_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventory_item` (
  `id` char(38) NOT NULL,
  `version` bigint(20) NOT NULL,
  `date_created` datetime NOT NULL,
  `last_updated` datetime NOT NULL,
  `lot_number` varchar(255) DEFAULT NULL,
  `product_id` char(38) DEFAULT NULL,
  `expiration_date` datetime DEFAULT NULL,
  `comments` varchar(255) DEFAULT NULL,
  `lot_status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `product_id` (`product_id`,`lot_number`),
  CONSTRAINT `FKFE019416DED5FAE7` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory_item`
--

LOCK TABLES `inventory_item` WRITE;
/*!40000 ALTER TABLE `inventory_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `inventory_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory_item_snapshot`
--

DROP TABLE IF EXISTS `inventory_item_snapshot`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventory_item_snapshot` (
  `id` char(38) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `product_id` char(38) DEFAULT NULL,
  `location_id` char(38) DEFAULT NULL,
  `inventory_item_id` char(38) DEFAULT NULL,
  `quantity_on_hand` int(11) DEFAULT NULL,
  `quantity_available_to_promise` int(11) DEFAULT NULL,
  `quantity_inbound` int(11) DEFAULT NULL,
  `quantity_outbound` int(11) DEFAULT NULL,
  `last_updated` datetime DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  UNIQUE KEY `inventory_item_snapshot_key` (`date`,`location_id`,`product_id`,`inventory_item_id`),
  KEY `FKBD34ABCD8ABEBD5` (`location_id`),
  KEY `FKBD34ABCDAA992CED` (`inventory_item_id`),
  KEY `FKBD34ABCDDED5FAE7` (`product_id`),
  CONSTRAINT `FKBD34ABCD8ABEBD5` FOREIGN KEY (`location_id`) REFERENCES `location` (`id`),
  CONSTRAINT `FKBD34ABCDAA992CED` FOREIGN KEY (`inventory_item_id`) REFERENCES `inventory_item` (`id`),
  CONSTRAINT `FKBD34ABCDDED5FAE7` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory_item_snapshot`
--

LOCK TABLES `inventory_item_snapshot` WRITE;
/*!40000 ALTER TABLE `inventory_item_snapshot` DISABLE KEYS */;
/*!40000 ALTER TABLE `inventory_item_snapshot` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory_level`
--

DROP TABLE IF EXISTS `inventory_level`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventory_level` (
  `id` char(38) NOT NULL,
  `version` bigint(20) NOT NULL,
  `inventory_id` char(38) DEFAULT NULL,
  `min_quantity` int(11) DEFAULT NULL,
  `product_id` char(38) DEFAULT NULL,
  `reorder_quantity` int(11) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `last_updated` datetime DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `max_quantity` int(11) DEFAULT NULL,
  `bin_location` varchar(255) DEFAULT NULL,
  `abc_class` varchar(255) DEFAULT NULL,
  `preferred` tinyint(3) DEFAULT NULL,
  `expected_lead_time_days` decimal(19,2) DEFAULT NULL,
  `forecast_period_days` decimal(19,2) DEFAULT NULL,
  `forecast_quantity` decimal(19,2) DEFAULT NULL,
  `preferred_bin_location_id` char(38) DEFAULT NULL,
  `replenishment_location_id` char(38) DEFAULT NULL,
  `comments` varchar(255) DEFAULT NULL,
  `internal_location_id` char(38) DEFAULT NULL,
  `replenishment_period_days` decimal(19,2) DEFAULT NULL,
  `demand_time_period_days` decimal(19,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKC254A2E16CDADD53` (`internal_location_id`),
  KEY `FKC254A2E172A2C5B4` (`inventory_id`),
  KEY `FKC254A2E1CFDCB4DF` (`preferred_bin_location_id`),
  KEY `FKC254A2E1DED5FAE7` (`product_id`),
  KEY `FKC254A2E1F07D879A` (`replenishment_location_id`),
  CONSTRAINT `FKC254A2E16CDADD53` FOREIGN KEY (`internal_location_id`) REFERENCES `location` (`id`),
  CONSTRAINT `FKC254A2E172A2C5B4` FOREIGN KEY (`inventory_id`) REFERENCES `inventory` (`id`),
  CONSTRAINT `FKC254A2E1CFDCB4DF` FOREIGN KEY (`preferred_bin_location_id`) REFERENCES `location` (`id`),
  CONSTRAINT `FKC254A2E1DED5FAE7` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`),
  CONSTRAINT `FKC254A2E1F07D879A` FOREIGN KEY (`replenishment_location_id`) REFERENCES `location` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory_level`
--

LOCK TABLES `inventory_level` WRITE;
/*!40000 ALTER TABLE `inventory_level` DISABLE KEYS */;
/*!40000 ALTER TABLE `inventory_level` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory_movement_summary`
--

DROP TABLE IF EXISTS `inventory_movement_summary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventory_movement_summary` (
  `product_id` char(38) DEFAULT NULL,
  `transaction_date` datetime NOT NULL,
  `product_code` varchar(255) DEFAULT NULL,
  `inventory_id` char(38) DEFAULT NULL,
  `transaction_id` char(38) NOT NULL,
  `quantity_sum` decimal(32,0) DEFAULT NULL,
  KEY `idx_product_code_inventory` (`product_code`,`inventory_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory_movement_summary`
--

LOCK TABLES `inventory_movement_summary` WRITE;
/*!40000 ALTER TABLE `inventory_movement_summary` DISABLE KEYS */;
/*!40000 ALTER TABLE `inventory_movement_summary` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory_snapshot`
--

DROP TABLE IF EXISTS `inventory_snapshot`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventory_snapshot` (
  `id` char(38) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `product_id` char(38) DEFAULT NULL,
  `location_id` char(38) DEFAULT NULL,
  `inventory_item_id` char(38) DEFAULT NULL,
  `quantity_on_hand` int(11) DEFAULT NULL,
  `quantity_available_to_promise` int(11) DEFAULT NULL,
  `quantity_inbound` int(11) DEFAULT NULL,
  `quantity_outbound` int(11) DEFAULT NULL,
  `last_updated` datetime DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `bin_location_id` char(38) DEFAULT NULL,
  `product_code` varchar(255) NOT NULL,
  `lot_number` varchar(255) DEFAULT 'DEFAULT',
  `expiration_date` datetime DEFAULT NULL,
  `bin_location_name` varchar(255) DEFAULT 'DEFAULT',
  UNIQUE KEY `inventory_snapshot_uniq_idx` (`date`,`location_id`,`product_code`,`lot_number`,`bin_location_name`),
  KEY `FK740B54769DB749D` (`bin_location_id`),
  KEY `FK740B547AA992CED` (`inventory_item_id`),
  KEY `FK740B547DED5FAE7` (`product_id`),
  KEY `inventory_snapshot_date_idx` (`date`),
  KEY `inventory_snapshot_last_updated_idx` (`location_id`,`last_updated`),
  CONSTRAINT `FK740B54769DB749D` FOREIGN KEY (`bin_location_id`) REFERENCES `location` (`id`),
  CONSTRAINT `FK740B5478ABEBD5` FOREIGN KEY (`location_id`) REFERENCES `location` (`id`),
  CONSTRAINT `FK740B547AA992CED` FOREIGN KEY (`inventory_item_id`) REFERENCES `inventory_item` (`id`),
  CONSTRAINT `FK740B547DED5FAE7` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory_snapshot`
--

LOCK TABLES `inventory_snapshot` WRITE;
/*!40000 ALTER TABLE `inventory_snapshot` DISABLE KEYS */;
/*!40000 ALTER TABLE `inventory_snapshot` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoice`
--

DROP TABLE IF EXISTS `invoice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `invoice` (
  `id` char(38) NOT NULL,
  `invoice_number` varchar(255) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `invoice_type_id` char(38) DEFAULT NULL,
  `party_from_id` char(38) DEFAULT NULL,
  `party_id` char(38) DEFAULT NULL,
  `date_invoiced` datetime DEFAULT NULL,
  `date_submitted` datetime DEFAULT NULL,
  `date_due` datetime DEFAULT NULL,
  `date_paid` datetime DEFAULT NULL,
  `currency_uom_id` char(38) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `last_updated` datetime DEFAULT NULL,
  `created_by_id` char(38) DEFAULT NULL,
  `updated_by_id` char(38) DEFAULT NULL,
  `version` bigint(20) NOT NULL,
  `date_posted` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_invoice_created_by` (`created_by_id`),
  KEY `fk_invoice_currency_uom` (`currency_uom_id`),
  KEY `fk_invoice_invoice_type` (`invoice_type_id`),
  KEY `fk_invoice_party` (`party_id`),
  KEY `fk_invoice_party_from` (`party_from_id`),
  KEY `fk_invoice_updated_by` (`updated_by_id`),
  CONSTRAINT `fk_invoice_created_by` FOREIGN KEY (`created_by_id`) REFERENCES `user` (`id`),
  CONSTRAINT `fk_invoice_currency_uom` FOREIGN KEY (`currency_uom_id`) REFERENCES `unit_of_measure` (`id`),
  CONSTRAINT `fk_invoice_invoice_type` FOREIGN KEY (`invoice_type_id`) REFERENCES `invoice_type` (`id`),
  CONSTRAINT `fk_invoice_party` FOREIGN KEY (`party_id`) REFERENCES `party` (`id`),
  CONSTRAINT `fk_invoice_party_from` FOREIGN KEY (`party_from_id`) REFERENCES `party` (`id`),
  CONSTRAINT `fk_invoice_updated_by` FOREIGN KEY (`updated_by_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoice`
--

LOCK TABLES `invoice` WRITE;
/*!40000 ALTER TABLE `invoice` DISABLE KEYS */;
/*!40000 ALTER TABLE `invoice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoice_document`
--

DROP TABLE IF EXISTS `invoice_document`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `invoice_document` (
  `invoice_id` char(38) DEFAULT NULL,
  `document_id` char(38) DEFAULT NULL,
  KEY `fk_invoice_document_document` (`document_id`),
  KEY `fk_invoice_document_invoice` (`invoice_id`),
  CONSTRAINT `fk_invoice_document_document` FOREIGN KEY (`document_id`) REFERENCES `document` (`id`),
  CONSTRAINT `fk_invoice_document_invoice` FOREIGN KEY (`invoice_id`) REFERENCES `invoice` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoice_document`
--

LOCK TABLES `invoice_document` WRITE;
/*!40000 ALTER TABLE `invoice_document` DISABLE KEYS */;
/*!40000 ALTER TABLE `invoice_document` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoice_item`
--

DROP TABLE IF EXISTS `invoice_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `invoice_item` (
  `id` char(38) NOT NULL,
  `invoice_id` char(38) NOT NULL,
  `product_id` char(38) DEFAULT NULL,
  `gl_account_id` char(38) DEFAULT NULL,
  `budget_code_id` char(38) DEFAULT NULL,
  `quantity` decimal(19,2) NOT NULL,
  `quantity_uom_id` char(38) DEFAULT NULL,
  `quantity_per_uom` decimal(19,2) NOT NULL,
  `amount` decimal(19,4) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `last_updated` datetime DEFAULT NULL,
  `created_by_id` char(38) DEFAULT NULL,
  `updated_by_id` char(38) DEFAULT NULL,
  `version` bigint(20) NOT NULL,
  `unit_price` decimal(19,4) DEFAULT NULL,
  `inverse` bit(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_invoice_item_budget_code` (`budget_code_id`),
  KEY `fk_invoice_item_created_by` (`created_by_id`),
  KEY `fk_invoice_item_gl_account` (`gl_account_id`),
  KEY `fk_invoice_item_invoice` (`invoice_id`),
  KEY `fk_invoice_item_product` (`product_id`),
  KEY `fk_invoice_item_quantity_uom` (`quantity_uom_id`),
  KEY `fk_invoice_item_updated_by` (`updated_by_id`),
  CONSTRAINT `fk_invoice_item_budget_code` FOREIGN KEY (`budget_code_id`) REFERENCES `budget_code` (`id`),
  CONSTRAINT `fk_invoice_item_created_by` FOREIGN KEY (`created_by_id`) REFERENCES `user` (`id`),
  CONSTRAINT `fk_invoice_item_gl_account` FOREIGN KEY (`gl_account_id`) REFERENCES `gl_account` (`id`),
  CONSTRAINT `fk_invoice_item_invoice` FOREIGN KEY (`invoice_id`) REFERENCES `invoice` (`id`),
  CONSTRAINT `fk_invoice_item_product` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`),
  CONSTRAINT `fk_invoice_item_quantity_uom` FOREIGN KEY (`quantity_uom_id`) REFERENCES `unit_of_measure` (`id`),
  CONSTRAINT `fk_invoice_item_updated_by` FOREIGN KEY (`updated_by_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoice_item`
--

LOCK TABLES `invoice_item` WRITE;
/*!40000 ALTER TABLE `invoice_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `invoice_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `invoice_item_candidate`
--

DROP TABLE IF EXISTS `invoice_item_candidate`;
/*!50001 DROP VIEW IF EXISTS `invoice_item_candidate`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `invoice_item_candidate` AS SELECT
 NULL AS `id`,
 NULL AS `order_number`,
 NULL AS `order_id`,
 NULL AS `shipment_id`,
 NULL AS `shipment_number`,
 NULL AS `budget_code_id`,
 NULL AS `gl_account_id`,
 NULL AS `product_code`,
 NULL AS `description`,
 NULL AS `quantity`,
 NULL AS `quantity_to_invoice`,
 NULL AS `quantity_uom_id`,
 NULL AS `unit_price`,
 NULL AS `quantity_per_uom`,
 NULL AS `order_item_quantity`,
 NULL AS `currency_code`,
 NULL AS `vendor_id`,
 NULL AS `adjustment_amount`,
 NULL AS `adjustment_percentage`,
 NULL AS `supplier_code` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `invoice_list`
--

DROP TABLE IF EXISTS `invoice_list`;
/*!50001 DROP VIEW IF EXISTS `invoice_list`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `invoice_list` AS SELECT
 NULL AS `invoice_id`,
 NULL AS `invoice_number`,
 NULL AS `vendor_invoice_number`,
 NULL AS `party_from_id`,
 NULL AS `party_id`,
 NULL AS `party_code`,
 NULL AS `party_name`,
 NULL AS `invoice_type_code`,
 NULL AS `status`,
 NULL AS `currency`,
 NULL AS `item_count`,
 NULL AS `date_invoiced`,
 NULL AS `date_created`,
 NULL AS `created_by_id`,
 NULL AS `created_by_name` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `invoice_reference_number`
--

DROP TABLE IF EXISTS `invoice_reference_number`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `invoice_reference_number` (
  `invoice_reference_numbers_id` char(38) DEFAULT NULL,
  `reference_number_id` char(38) DEFAULT NULL,
  `reference_numbers_idx` int(11) DEFAULT NULL,
  KEY `fk_invoice_reference_number_invoice_id` (`invoice_reference_numbers_id`),
  KEY `fk_invoice_reference_number_reference_number_id` (`reference_number_id`),
  CONSTRAINT `fk_invoice_reference_number_invoice_id` FOREIGN KEY (`invoice_reference_numbers_id`) REFERENCES `invoice` (`id`),
  CONSTRAINT `fk_invoice_reference_number_reference_number_id` FOREIGN KEY (`reference_number_id`) REFERENCES `reference_number` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoice_reference_number`
--

LOCK TABLES `invoice_reference_number` WRITE;
/*!40000 ALTER TABLE `invoice_reference_number` DISABLE KEYS */;
/*!40000 ALTER TABLE `invoice_reference_number` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoice_type`
--

DROP TABLE IF EXISTS `invoice_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `invoice_type` (
  `id` char(38) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `code` varchar(100) DEFAULT 'INVOICE',
  `date_created` datetime DEFAULT NULL,
  `last_updated` datetime DEFAULT NULL,
  `created_by_id` char(38) DEFAULT NULL,
  `updated_by_id` char(38) DEFAULT NULL,
  `version` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_invoice_type_created_by` (`created_by_id`),
  KEY `fk_invoice_type_updated_by` (`updated_by_id`),
  CONSTRAINT `fk_invoice_type_created_by` FOREIGN KEY (`created_by_id`) REFERENCES `user` (`id`),
  CONSTRAINT `fk_invoice_type_updated_by` FOREIGN KEY (`updated_by_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoice_type`
--

LOCK TABLES `invoice_type` WRITE;
/*!40000 ALTER TABLE `invoice_type` DISABLE KEYS */;
INSERT INTO `invoice_type` VALUES
('1','Purchase Invoice','','INVOICE','2023-08-14 15:00:15','2023-08-14 15:00:15',NULL,NULL,0),
('2','Sales Invoice','','INVOICE','2023-08-14 15:00:15','2023-08-14 15:00:15',NULL,NULL,0),
('3','Return Invoice','','INVOICE','2023-08-14 15:00:15','2023-08-14 15:00:15',NULL,NULL,0),
('4','Credit Note','','CREDIT_NOTE','2023-08-14 15:00:15','2023-08-14 15:00:15',NULL,NULL,0),
('5','Prepayment Invoice',NULL,'PREPAYMENT_INVOICE','2023-08-14 15:02:59','2023-08-14 15:02:59',NULL,NULL,0);
/*!40000 ALTER TABLE `invoice_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `latest_transaction_per_cycle_count`
--

DROP TABLE IF EXISTS `latest_transaction_per_cycle_count`;
/*!50001 DROP VIEW IF EXISTS `latest_transaction_per_cycle_count`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `latest_transaction_per_cycle_count` AS SELECT
 NULL AS `cycle_count_id`,
 NULL AS `latest_transaction_date` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `local_transfer`
--

DROP TABLE IF EXISTS `local_transfer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `local_transfer` (
  `id` char(38) NOT NULL,
  `source_transaction_id` char(38) DEFAULT NULL,
  `destination_transaction_id` char(38) DEFAULT NULL,
  `version` bigint(20) NOT NULL,
  `date_created` datetime NOT NULL,
  `last_updated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK7975323F4CC49445` (`destination_transaction_id`),
  KEY `FK7975323F57563498` (`source_transaction_id`),
  CONSTRAINT `FK7975323F4CC49445` FOREIGN KEY (`destination_transaction_id`) REFERENCES `transaction` (`id`),
  CONSTRAINT `FK7975323F57563498` FOREIGN KEY (`source_transaction_id`) REFERENCES `transaction` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `local_transfer`
--

LOCK TABLES `local_transfer` WRITE;
/*!40000 ALTER TABLE `local_transfer` DISABLE KEYS */;
/*!40000 ALTER TABLE `local_transfer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `localization`
--

DROP TABLE IF EXISTS `localization`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `localization` (
  `id` char(38) NOT NULL,
  `version` bigint(20) NOT NULL,
  `code` varchar(250) NOT NULL,
  `date_created` datetime NOT NULL,
  `last_updated` datetime NOT NULL,
  `locale` varchar(255) NOT NULL,
  `text` varchar(2000) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `localization_code_locale_idx` (`code`,`locale`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `localization`
--

LOCK TABLES `localization` WRITE;
/*!40000 ALTER TABLE `localization` DISABLE KEYS */;
/*!40000 ALTER TABLE `localization` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `location`
--

DROP TABLE IF EXISTS `location`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `location` (
  `id` char(38) NOT NULL,
  `version` bigint(20) NOT NULL,
  `address_id` char(38) DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `last_updated` datetime NOT NULL,
  `logo_url` varchar(255) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `inventory_id` char(38) DEFAULT NULL,
  `manager_id` char(38) DEFAULT NULL,
  `logo` mediumblob DEFAULT NULL,
  `managed_locally` bit(1) DEFAULT NULL,
  `active` bit(1) DEFAULT NULL,
  `location_type_id` char(38) DEFAULT NULL,
  `parent_location_id` char(38) DEFAULT NULL,
  `bg_color` varchar(255) DEFAULT NULL,
  `fg_color` varchar(255) DEFAULT NULL,
  `location_group_id` char(38) DEFAULT NULL,
  `sort_order` int(11) DEFAULT 0,
  `location_number` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `organization_id` char(38) DEFAULT NULL,
  `zone_id` char(38) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK714F9FB528F75F00` (`location_type_id`),
  KEY `FK714F9FB53BB36E94` (`location_group_id`),
  KEY `FK714F9FB541E07A73` (`manager_id`),
  KEY `FK714F9FB5606C7D95` (`organization_id`),
  KEY `FK714F9FB561ED379F` (`address_id`),
  KEY `FK714F9FB572A2C5B4` (`inventory_id`),
  KEY `FK714F9FB57AF9A3C0` (`parent_location_id`),
  KEY `zone_location_ibfk_3` (`zone_id`),
  KEY `idx_location_name` (`name`),
  CONSTRAINT `FK714F9FB528F75F00` FOREIGN KEY (`location_type_id`) REFERENCES `location_type` (`id`),
  CONSTRAINT `FK714F9FB53BB36E94` FOREIGN KEY (`location_group_id`) REFERENCES `location_group` (`id`),
  CONSTRAINT `FK714F9FB541E07A73` FOREIGN KEY (`manager_id`) REFERENCES `user` (`id`),
  CONSTRAINT `FK714F9FB5606C7D95` FOREIGN KEY (`organization_id`) REFERENCES `party` (`id`),
  CONSTRAINT `FK714F9FB561ED379F` FOREIGN KEY (`address_id`) REFERENCES `address` (`id`),
  CONSTRAINT `FK714F9FB572A2C5B4` FOREIGN KEY (`inventory_id`) REFERENCES `inventory` (`id`),
  CONSTRAINT `FK714F9FB57AF9A3C0` FOREIGN KEY (`parent_location_id`) REFERENCES `location` (`id`),
  CONSTRAINT `zone_location_ibfk_3` FOREIGN KEY (`zone_id`) REFERENCES `location` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `location`
--

LOCK TABLES `location` WRITE;
/*!40000 ALTER TABLE `location` DISABLE KEYS */;
INSERT INTO `location` VALUES
('1',0,'1','2010-08-25 00:00:00','2010-08-25 00:00:00',NULL,'Main Warehouse','1','1',NULL,NULL,'','2',NULL,'FFFFFF','000000',NULL,0,NULL,NULL,'1',NULL),
('2',0,NULL,'2010-08-25 00:00:00','2010-08-25 00:00:00',NULL,'Main Supplier',NULL,NULL,NULL,NULL,'','4',NULL,'FFFFFF','000000',NULL,0,NULL,NULL,'2',NULL),
('seed-wh-bandung',0,NULL,'2026-10-13 07:48:45','2026-10-13 07:48:45',NULL,'Bandung','seed-inv-bandung','1',NULL,NULL,'','2',NULL,'FFFFFF','000000',NULL,1,'BDG',NULL,'1',NULL),
('seed-wh-bintaro',0,NULL,'2026-10-13 07:48:45','2026-10-13 07:48:45',NULL,'Bintaro','seed-inv-bintaro','1',NULL,NULL,'','2',NULL,'FFFFFF','000000',NULL,3,'BTR',NULL,'1',NULL),
('seed-wh-cibubur',0,NULL,'2026-10-13 07:48:45','2026-10-13 07:48:45',NULL,'Cibubur','seed-inv-cibubur','1',NULL,NULL,'','2',NULL,'FFFFFF','000000',NULL,2,'CBB',NULL,'1',NULL);
/*!40000 ALTER TABLE `location` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `location_dimension`
--

DROP TABLE IF EXISTS `location_dimension`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `location_dimension` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `version` bigint(20) NOT NULL,
  `location_group_name` varchar(255) DEFAULT NULL,
  `location_id` char(38) NOT NULL,
  `location_name` varchar(255) NOT NULL,
  `location_number` varchar(255) DEFAULT NULL,
  `location_type_code` varchar(255) NOT NULL,
  `location_type_name` varchar(255) NOT NULL,
  `parent_location_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK1143A95C8ABEBD5` (`location_id`),
  CONSTRAINT `FK1143A95C8ABEBD5` FOREIGN KEY (`location_id`) REFERENCES `location` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `location_dimension`
--

LOCK TABLES `location_dimension` WRITE;
/*!40000 ALTER TABLE `location_dimension` DISABLE KEYS */;
/*!40000 ALTER TABLE `location_dimension` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `location_group`
--

DROP TABLE IF EXISTS `location_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `location_group` (
  `id` char(38) NOT NULL,
  `version` bigint(20) NOT NULL,
  `date_created` datetime NOT NULL,
  `last_updated` datetime NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `address_id` char(38) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK7A19D7561ED379F` (`address_id`),
  CONSTRAINT `FK7A19D7561ED379F` FOREIGN KEY (`address_id`) REFERENCES `address` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `location_group`
--

LOCK TABLES `location_group` WRITE;
/*!40000 ALTER TABLE `location_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `location_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `location_role`
--

DROP TABLE IF EXISTS `location_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `location_role` (
  `user_id` char(38) DEFAULT NULL,
  `location_id` char(38) DEFAULT NULL,
  `role_id` char(38) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `id` char(38) DEFAULT NULL,
  `location_roles_idx` int(11) DEFAULT NULL,
  KEY `location_role_ibfk_1` (`user_id`),
  KEY `location_role_ibfk_2` (`role_id`),
  KEY `location_role_ibfk_3` (`location_id`),
  CONSTRAINT `location_role_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`),
  CONSTRAINT `location_role_ibfk_2` FOREIGN KEY (`role_id`) REFERENCES `role` (`id`),
  CONSTRAINT `location_role_ibfk_3` FOREIGN KEY (`location_id`) REFERENCES `location` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `location_role`
--

LOCK TABLES `location_role` WRITE;
/*!40000 ALTER TABLE `location_role` DISABLE KEYS */;
/*!40000 ALTER TABLE `location_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `location_supported_activities`
--

DROP TABLE IF EXISTS `location_supported_activities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `location_supported_activities` (
  `location_id` char(38) DEFAULT NULL,
  `supported_activities_string` varchar(255) DEFAULT NULL,
  KEY `FKF58372688ABEBD5` (`location_id`),
  CONSTRAINT `FKF58372688ABEBD5` FOREIGN KEY (`location_id`) REFERENCES `location` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `location_supported_activities`
--

LOCK TABLES `location_supported_activities` WRITE;
/*!40000 ALTER TABLE `location_supported_activities` DISABLE KEYS */;
/*!40000 ALTER TABLE `location_supported_activities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `location_type`
--

DROP TABLE IF EXISTS `location_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `location_type` (
  `id` char(38) NOT NULL,
  `version` bigint(20) NOT NULL,
  `date_created` datetime NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `last_updated` datetime NOT NULL,
  `name` varchar(255) NOT NULL,
  `sort_order` int(11) DEFAULT NULL,
  `location_type_code` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `location_type`
--

LOCK TABLES `location_type` WRITE;
/*!40000 ALTER TABLE `location_type` DISABLE KEYS */;
INSERT INTO `location_type` VALUES
('2',0,'2010-12-06 00:00:00','Depot','2010-12-06 00:00:00','Depot',0,'DEPOT'),
('3',0,'2010-12-06 00:00:00','Dispensary','2011-11-14 00:00:00','Dispensary',0,'DISPENSARY'),
('4',0,'2010-12-06 00:00:00','Supplier','2010-12-06 00:00:00','Supplier',0,'SUPPLIER'),
('5',0,'2012-12-06 00:00:00','Ward','2012-12-06 00:00:00','Ward',0,'WARD'),
('6',0,'2012-12-06 00:00:00','Pharmacy','2012-12-06 00:00:00','Pharmacy',0,'DISPENSARY'),
('cab2b48e649c71940164a13750f40001',0,'2018-07-15 00:00:00','Default receiving location type','2018-07-15 00:00:00','Cross-docking',0,'INTERNAL'),
('cab2b4f35ba2d867015ba2e17e390001',0,'2017-08-07 00:00:00','Default bin location type','2017-08-07 00:00:00','Bin Location',0,'BIN_LOCATION'),
('ff8081816482352b01648249e8cc0001',0,'2018-07-09 00:00:00','Default receiving location type','2018-07-09 00:00:00','Receiving',0,'INTERNAL'),
('HOLD_LOCATION',0,'2023-08-14 15:05:15','Default hold location type','2023-08-14 15:05:15','Hold',0,'INTERNAL'),
('ZONE',0,'2021-05-28 00:00:00','Default zone location type','2021-05-28 00:00:00','Zone',0,'ZONE');
/*!40000 ALTER TABLE `location_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `location_type_supported_activities`
--

DROP TABLE IF EXISTS `location_type_supported_activities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `location_type_supported_activities` (
  `location_type_id` char(38) DEFAULT NULL,
  `supported_activities_string` varchar(255) DEFAULT NULL,
  KEY `FK7AFF67F928F75F00` (`location_type_id`),
  CONSTRAINT `FK7AFF67F928F75F00` FOREIGN KEY (`location_type_id`) REFERENCES `location_type` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `location_type_supported_activities`
--

LOCK TABLES `location_type_supported_activities` WRITE;
/*!40000 ALTER TABLE `location_type_supported_activities` DISABLE KEYS */;
INSERT INTO `location_type_supported_activities` VALUES
('2','MANAGE_INVENTORY'),
('2','PLACE_ORDER'),
('2','PLACE_REQUEST'),
('2','FULFILL_REQUEST'),
('2','SEND_STOCK'),
('2','RECEIVE_STOCK'),
('2','EXTERNAL'),
('2','ADJUST_INVENTORY'),
('2','SUBMIT_REQUEST'),
('2','ENABLE_REQUESTOR_APPROVAL_NOTIFICATIONS'),
('2','ENABLE_FULFILLER_APPROVAL_NOTIFICATIONS'),
('2','PICK_STOCK'),
('2','PUTAWAY_STOCK'),
('3','DYNAMIC_CREATION'),
('3','SEND_STOCK'),
('3','RECEIVE_STOCK'),
('4','FULFILL_ORDER'),
('4','SEND_STOCK'),
('4','EXTERNAL'),
('5','DYNAMIC_CREATION'),
('6','DYNAMIC_CREATION'),
('ff8081816482352b01648249e8cc0001','RECEIVE_STOCK'),
('ff8081816482352b01648249e8cc0001','PUTAWAY_STOCK'),
('ff8081816482352b01648249e8cc0001','PICK_STOCK'),
('cab2b4f35ba2d867015ba2e17e390001','PUTAWAY_STOCK'),
('cab2b4f35ba2d867015ba2e17e390001','PICK_STOCK'),
('cab2b48e649c71940164a13750f40001','RECEIVE_STOCK'),
('cab2b48e649c71940164a13750f40001','PUTAWAY_STOCK'),
('cab2b48e649c71940164a13750f40001','PICK_STOCK'),
('HOLD_LOCATION','HOLD_STOCK'),
('HOLD_LOCATION','PUTAWAY_STOCK');
/*!40000 ALTER TABLE `location_type_supported_activities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lot_dimension`
--

DROP TABLE IF EXISTS `lot_dimension`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `lot_dimension` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `version` bigint(20) NOT NULL,
  `expiration_date` datetime DEFAULT NULL,
  `inventory_item_id` char(38) NOT NULL,
  `lot_number` varchar(255) DEFAULT NULL,
  `product_code` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKD2EAD9F8AA992CED` (`inventory_item_id`),
  CONSTRAINT `FKD2EAD9F8AA992CED` FOREIGN KEY (`inventory_item_id`) REFERENCES `inventory_item` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lot_dimension`
--

LOCK TABLES `lot_dimension` WRITE;
/*!40000 ALTER TABLE `lot_dimension` DISABLE KEYS */;
/*!40000 ALTER TABLE `lot_dimension` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `on_order_order_item_summary`
--

DROP TABLE IF EXISTS `on_order_order_item_summary`;
/*!50001 DROP VIEW IF EXISTS `on_order_order_item_summary`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `on_order_order_item_summary` AS SELECT
 NULL AS `product_id`,
 NULL AS `destination_id`,
 NULL AS `quantity_ordered_not_shipped`,
 NULL AS `quantity_shipped_not_received` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `on_order_shipment_item_summary`
--

DROP TABLE IF EXISTS `on_order_shipment_item_summary`;
/*!50001 DROP VIEW IF EXISTS `on_order_shipment_item_summary`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `on_order_shipment_item_summary` AS SELECT
 NULL AS `product_id`,
 NULL AS `destination_id`,
 NULL AS `quantity_ordered_not_shipped`,
 NULL AS `quantity_shipped_not_received` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `on_order_summary`
--

DROP TABLE IF EXISTS `on_order_summary`;
/*!50001 DROP VIEW IF EXISTS `on_order_summary`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `on_order_summary` AS SELECT
 NULL AS `product_id`,
 NULL AS `destination_id`,
 NULL AS `quantity_ordered_not_shipped`,
 NULL AS `quantity_shipped_not_received` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `order`
--

DROP TABLE IF EXISTS `order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `order` (
  `id` char(38) NOT NULL,
  `version` bigint(20) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `date_ordered` datetime DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `destination_id` char(38) DEFAULT NULL,
  `last_updated` datetime DEFAULT NULL,
  `order_number` varchar(255) DEFAULT NULL,
  `ordered_by_id` char(38) DEFAULT NULL,
  `origin_id` char(38) DEFAULT NULL,
  `recipient_id` char(38) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `completed_by_id` char(38) DEFAULT NULL,
  `date_completed` datetime DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `currency_code` char(3) DEFAULT NULL,
  `exchange_rate` decimal(19,8) DEFAULT NULL,
  `payment_method_type_id` char(38) DEFAULT NULL,
  `payment_term_id` char(38) DEFAULT NULL,
  `approved_by_id` char(38) DEFAULT NULL,
  `date_approved` datetime DEFAULT NULL,
  `destination_party_id` char(38) DEFAULT NULL,
  `origin_party_id` char(38) DEFAULT NULL,
  `created_by_id` char(38) DEFAULT NULL,
  `updated_by_id` char(38) DEFAULT NULL,
  `order_type_id` char(38) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK651874E1E2B3CDC` (`destination_id`),
  KEY `FK651874E240896CB` (`approved_by_id`),
  KEY `FK651874E35D76CB0` (`destination_party_id`),
  KEY `FK651874E41B7275F` (`completed_by_id`),
  KEY `FK651874E44979D51` (`recipient_id`),
  KEY `FK651874E6A8010C1` (`payment_method_type_id`),
  KEY `FK651874E6D91063C` (`created_by_id`),
  KEY `FK651874E8AF312E3` (`order_type_id`),
  KEY `FK651874E8E7F7DCF` (`updated_by_id`),
  KEY `FK651874E9E52B00C` (`payment_term_id`),
  KEY `FK651874EAF6D8801` (`ordered_by_id`),
  KEY `FK651874EDBDEDAC4` (`origin_id`),
  CONSTRAINT `FK651874E1E2B3CDC` FOREIGN KEY (`destination_id`) REFERENCES `location` (`id`),
  CONSTRAINT `FK651874E240896CB` FOREIGN KEY (`approved_by_id`) REFERENCES `person` (`id`),
  CONSTRAINT `FK651874E35D76CB0` FOREIGN KEY (`destination_party_id`) REFERENCES `party` (`id`),
  CONSTRAINT `FK651874E41B7275F` FOREIGN KEY (`completed_by_id`) REFERENCES `person` (`id`),
  CONSTRAINT `FK651874E44979D51` FOREIGN KEY (`recipient_id`) REFERENCES `person` (`id`),
  CONSTRAINT `FK651874E6A8010C1` FOREIGN KEY (`payment_method_type_id`) REFERENCES `payment_method_type` (`id`),
  CONSTRAINT `FK651874E6D91063C` FOREIGN KEY (`created_by_id`) REFERENCES `person` (`id`),
  CONSTRAINT `FK651874E8AF312E3` FOREIGN KEY (`order_type_id`) REFERENCES `order_type` (`id`),
  CONSTRAINT `FK651874E8E7F7DCF` FOREIGN KEY (`updated_by_id`) REFERENCES `person` (`id`),
  CONSTRAINT `FK651874E9E52B00C` FOREIGN KEY (`payment_term_id`) REFERENCES `payment_term` (`id`),
  CONSTRAINT `FK651874EAF6D8801` FOREIGN KEY (`ordered_by_id`) REFERENCES `person` (`id`),
  CONSTRAINT `FK651874EDBDEDAC4` FOREIGN KEY (`origin_id`) REFERENCES `location` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order`
--

LOCK TABLES `order` WRITE;
/*!40000 ALTER TABLE `order` DISABLE KEYS */;
/*!40000 ALTER TABLE `order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_adjustment`
--

DROP TABLE IF EXISTS `order_adjustment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_adjustment` (
  `id` char(38) NOT NULL,
  `version` bigint(20) NOT NULL,
  `order_id` char(38) NOT NULL,
  `order_item_id` char(38) DEFAULT NULL,
  `order_adjustment_type_id` char(38) DEFAULT NULL,
  `amount` decimal(19,4) DEFAULT NULL,
  `percentage` decimal(19,2) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `comments` varchar(255) DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `last_updated` datetime NOT NULL,
  `budget_code_id` char(38) DEFAULT NULL,
  `gl_account_id` char(38) DEFAULT NULL,
  `canceled` bit(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK4A1ABEFE3BE9D843` (`order_item_id`),
  KEY `FK4A1ABEFED08EDBE6` (`order_id`),
  KEY `FK4A1ABEFEE1A39520` (`order_adjustment_type_id`),
  KEY `fk_order_adjustment_budget_code` (`budget_code_id`),
  KEY `fk_order_adjustment_gl_account` (`gl_account_id`),
  CONSTRAINT `FK4A1ABEFE3BE9D843` FOREIGN KEY (`order_item_id`) REFERENCES `order_item` (`id`),
  CONSTRAINT `FK4A1ABEFED08EDBE6` FOREIGN KEY (`order_id`) REFERENCES `order` (`id`),
  CONSTRAINT `FK4A1ABEFEE1A39520` FOREIGN KEY (`order_adjustment_type_id`) REFERENCES `order_adjustment_type` (`id`),
  CONSTRAINT `fk_order_adjustment_budget_code` FOREIGN KEY (`budget_code_id`) REFERENCES `budget_code` (`id`),
  CONSTRAINT `fk_order_adjustment_gl_account` FOREIGN KEY (`gl_account_id`) REFERENCES `gl_account` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_adjustment`
--

LOCK TABLES `order_adjustment` WRITE;
/*!40000 ALTER TABLE `order_adjustment` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_adjustment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `order_adjustment_details`
--

DROP TABLE IF EXISTS `order_adjustment_details`;
/*!50001 DROP VIEW IF EXISTS `order_adjustment_details`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `order_adjustment_details` AS SELECT
 NULL AS `id`,
 NULL AS `total_adjustment` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `order_adjustment_invoice`
--

DROP TABLE IF EXISTS `order_adjustment_invoice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_adjustment_invoice` (
  `invoice_item_id` char(38) DEFAULT NULL,
  `order_adjustment_id` char(38) DEFAULT NULL,
  KEY `order_adjustment_invoice_ibfk_1` (`order_adjustment_id`),
  KEY `order_adjustment_invoice_ibfk_2` (`invoice_item_id`),
  CONSTRAINT `order_adjustment_invoice_ibfk_1` FOREIGN KEY (`order_adjustment_id`) REFERENCES `order_adjustment` (`id`),
  CONSTRAINT `order_adjustment_invoice_ibfk_2` FOREIGN KEY (`invoice_item_id`) REFERENCES `invoice_item` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_adjustment_invoice`
--

LOCK TABLES `order_adjustment_invoice` WRITE;
/*!40000 ALTER TABLE `order_adjustment_invoice` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_adjustment_invoice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `order_adjustment_payment_status`
--

DROP TABLE IF EXISTS `order_adjustment_payment_status`;
/*!50001 DROP VIEW IF EXISTS `order_adjustment_payment_status`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `order_adjustment_payment_status` AS SELECT
 NULL AS `order_id`,
 NULL AS `order_number`,
 NULL AS `adjustment_id`,
 NULL AS `invoice_item_id`,
 NULL AS `order_status`,
 NULL AS `quantity_invoiced`,
 NULL AS `invoiced_amount` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `order_adjustment_type`
--

DROP TABLE IF EXISTS `order_adjustment_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_adjustment_type` (
  `id` char(38) NOT NULL,
  `version` bigint(20) NOT NULL,
  `name` varchar(255) NOT NULL,
  `code` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `last_updated` datetime NOT NULL,
  `gl_account_id` char(38) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_order_adjustment_type_gl_account` (`gl_account_id`),
  CONSTRAINT `fk_order_adjustment_type_gl_account` FOREIGN KEY (`gl_account_id`) REFERENCES `gl_account` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_adjustment_type`
--

LOCK TABLES `order_adjustment_type` WRITE;
/*!40000 ALTER TABLE `order_adjustment_type` DISABLE KEYS */;
INSERT INTO `order_adjustment_type` VALUES
('DISCOUNT',0,'Discount','DISCOUNT_ADJUSTMENT',NULL,'2020-02-27 00:00:00','2020-02-27 00:00:00',NULL),
('FEE',0,'Fee','FEE',NULL,'2020-02-27 00:00:00','2020-02-27 00:00:00',NULL),
('MISCELLANEOUS',0,'Miscellaneous Charge','MISCELLANEOUS_CHARGE',NULL,'2020-02-27 00:00:00','2020-02-27 00:00:00',NULL),
('SALES_TAX',0,'Sales Tax','SALES_TAX',NULL,'2020-02-27 00:00:00','2020-02-27 00:00:00',NULL),
('SHIPPING_CHARGE',0,'Shipping Charge','SHIPPING_CHARGE',NULL,'2020-02-27 00:00:00','2020-02-27 00:00:00',NULL),
('SURCHARGE',0,'Surcharge','SURCHARGE_ADJUSTMENT',NULL,'2020-02-27 00:00:00','2020-02-27 00:00:00',NULL);
/*!40000 ALTER TABLE `order_adjustment_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_comment`
--

DROP TABLE IF EXISTS `order_comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_comment` (
  `order_comments_id` char(38) DEFAULT NULL,
  `comment_id` char(38) DEFAULT NULL,
  KEY `FK2DE9EE6EB8839C0F` (`order_comments_id`),
  KEY `FK2DE9EE6EC4A49BBF` (`comment_id`),
  CONSTRAINT `FK2DE9EE6EB8839C0F` FOREIGN KEY (`order_comments_id`) REFERENCES `order` (`id`),
  CONSTRAINT `FK2DE9EE6EC4A49BBF` FOREIGN KEY (`comment_id`) REFERENCES `comment` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_comment`
--

LOCK TABLES `order_comment` WRITE;
/*!40000 ALTER TABLE `order_comment` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_document`
--

DROP TABLE IF EXISTS `order_document`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_document` (
  `order_documents_id` char(38) DEFAULT NULL,
  `document_id` char(38) DEFAULT NULL,
  KEY `FKE698D2ECC800AA15` (`document_id`),
  KEY `FKE698D2ECFE10118D` (`order_documents_id`),
  CONSTRAINT `FKE698D2ECC800AA15` FOREIGN KEY (`document_id`) REFERENCES `document` (`id`),
  CONSTRAINT `FKE698D2ECFE10118D` FOREIGN KEY (`order_documents_id`) REFERENCES `order` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_document`
--

LOCK TABLES `order_document` WRITE;
/*!40000 ALTER TABLE `order_document` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_document` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_event`
--

DROP TABLE IF EXISTS `order_event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_event` (
  `order_events_id` char(38) DEFAULT NULL,
  `event_id` char(38) DEFAULT NULL,
  KEY `FK74D92A693D2E628A` (`order_events_id`),
  KEY `FK74D92A69786431F` (`event_id`),
  CONSTRAINT `FK74D92A693D2E628A` FOREIGN KEY (`order_events_id`) REFERENCES `order` (`id`),
  CONSTRAINT `FK74D92A69786431F` FOREIGN KEY (`event_id`) REFERENCES `event` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_event`
--

LOCK TABLES `order_event` WRITE;
/*!40000 ALTER TABLE `order_event` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_event_log`
--

DROP TABLE IF EXISTS `order_event_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_event_log` (
  `order_id` char(38) NOT NULL,
  `event_log_id` char(38) NOT NULL,
  KEY `fk_order_event_log_order` (`order_id`),
  KEY `fk_order_event_log_event_log` (`event_log_id`),
  CONSTRAINT `fk_order_event_log_event_log` FOREIGN KEY (`event_log_id`) REFERENCES `event_log` (`id`),
  CONSTRAINT `fk_order_event_log_order` FOREIGN KEY (`order_id`) REFERENCES `order` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_event_log`
--

LOCK TABLES `order_event_log` WRITE;
/*!40000 ALTER TABLE `order_event_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_event_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_invoice`
--

DROP TABLE IF EXISTS `order_invoice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_invoice` (
  `invoice_item_id` char(38) NOT NULL,
  `order_item_id` char(38) DEFAULT NULL,
  KEY `FK6A1A433C3BE9D843` (`order_item_id`),
  KEY `FK6A1A433CB95ED8E0` (`invoice_item_id`),
  CONSTRAINT `FK6A1A433C3BE9D843` FOREIGN KEY (`order_item_id`) REFERENCES `order_item` (`id`),
  CONSTRAINT `FK6A1A433CB95ED8E0` FOREIGN KEY (`invoice_item_id`) REFERENCES `invoice_item` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_invoice`
--

LOCK TABLES `order_invoice` WRITE;
/*!40000 ALTER TABLE `order_invoice` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_invoice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_item`
--

DROP TABLE IF EXISTS `order_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_item` (
  `id` char(38) NOT NULL,
  `version` bigint(20) NOT NULL,
  `category_id` char(38) DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `inventory_item_id` char(38) DEFAULT NULL,
  `last_updated` datetime NOT NULL,
  `order_id` char(38) DEFAULT NULL,
  `product_id` char(38) DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `requested_by_id` char(38) DEFAULT NULL,
  `unit_price` decimal(19,4) DEFAULT NULL,
  `order_item_status_code` varchar(100) DEFAULT 'PENDING',
  `parent_order_item_id` char(38) DEFAULT NULL,
  `recipient_id` char(38) DEFAULT NULL,
  `destination_bin_location_id` char(38) DEFAULT NULL,
  `origin_bin_location_id` char(38) DEFAULT NULL,
  `currency_code` char(3) DEFAULT NULL,
  `product_supplier_id` char(38) DEFAULT NULL,
  `estimated_ready_date` datetime DEFAULT NULL,
  `estimated_ship_date` datetime DEFAULT NULL,
  `estimated_delivery_date` datetime DEFAULT NULL,
  `actual_ready_date` datetime DEFAULT NULL,
  `actual_ship_date` datetime DEFAULT NULL,
  `actual_delivery_date` datetime DEFAULT NULL,
  `product_package_id` char(38) DEFAULT NULL,
  `quantity_per_uom` decimal(19,2) DEFAULT NULL,
  `quantity_uom_id` char(38) DEFAULT NULL,
  `budget_code_id` char(38) DEFAULT NULL,
  `gl_account_id` char(38) DEFAULT NULL,
  `order_index` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK2D110D6418D76D84` (`origin_bin_location_id`),
  KEY `FK2D110D6429542386` (`product_supplier_id`),
  KEY `FK2D110D6429B2552E` (`product_package_id`),
  KEY `FK2D110D6444979D51` (`recipient_id`),
  KEY `FK2D110D6451A9416E` (`parent_order_item_id`),
  KEY `FK2D110D645ED93B03` (`quantity_uom_id`),
  KEY `FK2D110D64605326C` (`destination_bin_location_id`),
  KEY `FK2D110D64911E7578` (`requested_by_id`),
  KEY `FK2D110D64AA992CED` (`inventory_item_id`),
  KEY `FK2D110D64D08EDBE6` (`order_id`),
  KEY `FK2D110D64DED5FAE7` (`product_id`),
  KEY `FK2D110D64EF4C770D` (`category_id`),
  KEY `fk_order_item_budget_code` (`budget_code_id`),
  KEY `fk_order_item_gl_account` (`gl_account_id`),
  CONSTRAINT `FK2D110D6418D76D84` FOREIGN KEY (`origin_bin_location_id`) REFERENCES `location` (`id`),
  CONSTRAINT `FK2D110D6429542386` FOREIGN KEY (`product_supplier_id`) REFERENCES `product_supplier` (`id`),
  CONSTRAINT `FK2D110D6429B2552E` FOREIGN KEY (`product_package_id`) REFERENCES `product_package` (`id`),
  CONSTRAINT `FK2D110D6444979D51` FOREIGN KEY (`recipient_id`) REFERENCES `person` (`id`),
  CONSTRAINT `FK2D110D6451A9416E` FOREIGN KEY (`parent_order_item_id`) REFERENCES `order_item` (`id`),
  CONSTRAINT `FK2D110D645ED93B03` FOREIGN KEY (`quantity_uom_id`) REFERENCES `unit_of_measure` (`id`),
  CONSTRAINT `FK2D110D64605326C` FOREIGN KEY (`destination_bin_location_id`) REFERENCES `location` (`id`),
  CONSTRAINT `FK2D110D64911E7578` FOREIGN KEY (`requested_by_id`) REFERENCES `user` (`id`),
  CONSTRAINT `FK2D110D64AA992CED` FOREIGN KEY (`inventory_item_id`) REFERENCES `inventory_item` (`id`),
  CONSTRAINT `FK2D110D64D08EDBE6` FOREIGN KEY (`order_id`) REFERENCES `order` (`id`),
  CONSTRAINT `FK2D110D64DED5FAE7` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`),
  CONSTRAINT `FK2D110D64EF4C770D` FOREIGN KEY (`category_id`) REFERENCES `category` (`id`),
  CONSTRAINT `fk_order_item_budget_code` FOREIGN KEY (`budget_code_id`) REFERENCES `budget_code` (`id`),
  CONSTRAINT `fk_order_item_gl_account` FOREIGN KEY (`gl_account_id`) REFERENCES `gl_account` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_item`
--

LOCK TABLES `order_item` WRITE;
/*!40000 ALTER TABLE `order_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_item_comment`
--

DROP TABLE IF EXISTS `order_item_comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_item_comment` (
  `order_item_comments_id` char(38) DEFAULT NULL,
  `comment_id` char(38) DEFAULT NULL,
  KEY `FKB5A4FE84C4A49BBF` (`comment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_item_comment`
--

LOCK TABLES `order_item_comment` WRITE;
/*!40000 ALTER TABLE `order_item_comment` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_item_comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `order_item_details`
--

DROP TABLE IF EXISTS `order_item_details`;
/*!50001 DROP VIEW IF EXISTS `order_item_details`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `order_item_details` AS SELECT
 NULL AS `id`,
 NULL AS `order_item_id`,
 NULL AS `order_id`,
 NULL AS `order_number`,
 NULL AS `product_id`,
 NULL AS `quantity`,
 NULL AS `order_item_status`,
 NULL AS `quantity_uom_id`,
 NULL AS `quantity_per_uom`,
 NULL AS `unit_price` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `order_item_payment_status`
--

DROP TABLE IF EXISTS `order_item_payment_status`;
/*!50001 DROP VIEW IF EXISTS `order_item_payment_status`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `order_item_payment_status` AS SELECT
 NULL AS `order_id`,
 NULL AS `order_number`,
 NULL AS `order_item_id`,
 NULL AS `quantity_ordered`,
 NULL AS `quantity_invoiced` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `order_item_status`
--

DROP TABLE IF EXISTS `order_item_status`;
/*!50001 DROP VIEW IF EXISTS `order_item_status`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `order_item_status` AS SELECT
 NULL AS `order_id`,
 NULL AS `order_number`,
 NULL AS `quantity_ordered`,
 NULL AS `quantity_shipped`,
 NULL AS `order_item_id` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `order_item_summary`
--

DROP TABLE IF EXISTS `order_item_summary`;
/*!50001 DROP VIEW IF EXISTS `order_item_summary`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `order_item_summary` AS SELECT
 NULL AS `id`,
 NULL AS `order_id`,
 NULL AS `order_number`,
 NULL AS `product_id`,
 NULL AS `quantity`,
 NULL AS `order_item_status`,
 NULL AS `quantity_uom_id`,
 NULL AS `quantity_per_uom`,
 NULL AS `unit_price`,
 NULL AS `quantity_ordered`,
 NULL AS `quantity_shipped`,
 NULL AS `quantity_received`,
 NULL AS `quantity_canceled`,
 NULL AS `quantity_invoiced`,
 NULL AS `is_item_fully_ordered`,
 NULL AS `is_item_fully_shipped`,
 NULL AS `is_item_fully_received`,
 NULL AS `is_item_fully_invoiced`,
 NULL AS `derived_status` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `order_receipt_status`
--

DROP TABLE IF EXISTS `order_receipt_status`;
/*!50001 DROP VIEW IF EXISTS `order_receipt_status`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `order_receipt_status` AS SELECT
 NULL AS `order_id`,
 NULL AS `order_item_id`,
 NULL AS `order_number`,
 NULL AS `quantity_received`,
 NULL AS `quantity_canceled` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `order_shipment`
--

DROP TABLE IF EXISTS `order_shipment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_shipment` (
  `order_item_id` char(38) DEFAULT NULL,
  `shipment_item_id` char(38) DEFAULT NULL,
  KEY `FK9475736B3BE9D843` (`order_item_id`),
  KEY `FK9475736BB06EC4FB` (`shipment_item_id`),
  CONSTRAINT `FK9475736B3BE9D843` FOREIGN KEY (`order_item_id`) REFERENCES `order_item` (`id`),
  CONSTRAINT `FK9475736BB06EC4FB` FOREIGN KEY (`shipment_item_id`) REFERENCES `shipment_item` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_shipment`
--

LOCK TABLES `order_shipment` WRITE;
/*!40000 ALTER TABLE `order_shipment` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_shipment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `order_summary`
--

DROP TABLE IF EXISTS `order_summary`;
/*!50001 DROP VIEW IF EXISTS `order_summary`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `order_summary` AS SELECT
 NULL AS `id`,
 NULL AS `order_id`,
 NULL AS `quantity_ordered`,
 NULL AS `adjustments_count`,
 NULL AS `quantity_shipped`,
 NULL AS `quantity_received`,
 NULL AS `quantity_canceled`,
 NULL AS `quantity_invoiced`,
 NULL AS `adjustments_invoiced`,
 NULL AS `items_ordered`,
 NULL AS `items_shipped`,
 NULL AS `items_received`,
 NULL AS `items_invoiced`,
 NULL AS `order_status`,
 NULL AS `shipment_status`,
 NULL AS `receipt_status`,
 NULL AS `payment_status`,
 NULL AS `derived_status` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `order_summary_mv`
--

DROP TABLE IF EXISTS `order_summary_mv`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_summary_mv` (
  `id` char(38) NOT NULL,
  `order_id` char(38) NOT NULL,
  `quantity_ordered` decimal(65,0) DEFAULT NULL,
  `adjustments_count` decimal(42,0) DEFAULT NULL,
  `quantity_shipped` decimal(65,4) DEFAULT NULL,
  `quantity_received` decimal(65,4) DEFAULT NULL,
  `quantity_canceled` decimal(65,4) DEFAULT NULL,
  `quantity_invoiced` decimal(65,2) DEFAULT NULL,
  `adjustments_invoiced` decimal(54,0) DEFAULT NULL,
  `items_ordered` decimal(45,0) DEFAULT NULL,
  `items_shipped` decimal(45,0) DEFAULT NULL,
  `items_received` decimal(45,0) DEFAULT NULL,
  `items_invoiced` decimal(45,0) DEFAULT NULL,
  `order_status` varchar(255) DEFAULT NULL,
  `shipment_status` varchar(17) DEFAULT NULL,
  `receipt_status` varchar(18) DEFAULT NULL,
  `payment_status` varchar(18) DEFAULT NULL,
  `derived_status` varchar(255) DEFAULT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_summary_mv`
--

LOCK TABLES `order_summary_mv` WRITE;
/*!40000 ALTER TABLE `order_summary_mv` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_summary_mv` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_type`
--

DROP TABLE IF EXISTS `order_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_type` (
  `id` char(38) NOT NULL,
  `version` bigint(20) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `code` varchar(100) NOT NULL,
  `order_type_code` varchar(100) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `last_updated` datetime DEFAULT NULL,
  `created_by_id` char(38) DEFAULT NULL,
  `updated_by_id` char(38) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_order_type_created_by` (`created_by_id`),
  KEY `fk_order_type_updated_by` (`updated_by_id`),
  CONSTRAINT `fk_order_type_created_by` FOREIGN KEY (`created_by_id`) REFERENCES `user` (`id`),
  CONSTRAINT `fk_order_type_updated_by` FOREIGN KEY (`updated_by_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_type`
--

LOCK TABLES `order_type` WRITE;
/*!40000 ALTER TABLE `order_type` DISABLE KEYS */;
INSERT INTO `order_type` VALUES
('PRODUCTION_ORDER',0,'Production Order','','PRODUCTION_ORDER','PRODUCTION_ORDER','2023-08-14 15:04:38','2023-08-14 15:04:38',NULL,NULL),
('PURCHASE_ORDER',0,'Purchase Order','','PURCHASE_ORDER','PURCHASE_ORDER','2023-08-14 15:04:38','2023-08-14 15:04:38',NULL,NULL),
('PUTAWAY_ORDER',0,'Putaway Order','','PUTAWAY_ORDER','TRANSFER_ORDER','2023-08-14 15:04:38','2023-08-14 15:04:38',NULL,NULL),
('RETURN_ORDER',0,'Return Order','','RETURN_ORDER','TRANSFER_ORDER','2023-08-14 15:06:45','2023-08-14 15:06:45',NULL,NULL),
('SALES_ORDER',0,'Sales Order','','SALES_ORDER','SALES_ORDER','2023-08-14 15:04:38','2023-08-14 15:04:38',NULL,NULL),
('TRANSFER_ORDER',0,'Transfer Order','','TRANSFER_ORDER','TRANSFER_ORDER','2023-08-14 15:04:38','2023-08-14 15:04:38',NULL,NULL),
('WORK_ORDER',0,'Work Order','','WORK_ORDER','WORK_ORDER','2023-08-14 15:04:38','2023-08-14 15:04:38',NULL,NULL);
/*!40000 ALTER TABLE `order_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `organization_sequences`
--

DROP TABLE IF EXISTS `organization_sequences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `organization_sequences` (
  `sequences` varchar(255) DEFAULT NULL,
  `sequences_idx` varchar(255) DEFAULT NULL,
  `sequences_elt` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `organization_sequences`
--

LOCK TABLES `organization_sequences` WRITE;
/*!40000 ALTER TABLE `organization_sequences` DISABLE KEYS */;
/*!40000 ALTER TABLE `organization_sequences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `party`
--

DROP TABLE IF EXISTS `party`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `party` (
  `id` char(38) NOT NULL,
  `version` bigint(20) NOT NULL,
  `date_created` datetime NOT NULL,
  `last_updated` datetime NOT NULL,
  `party_type_id` char(38) NOT NULL,
  `class` varchar(255) NOT NULL,
  `code` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `default_location_id` char(38) DEFAULT NULL,
  `active` bit(1) DEFAULT b'1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_party_code` (`code`),
  KEY `FK6581AE69DFE4C4C` (`party_type_id`),
  KEY `FK6581AE6D1DFC6D7` (`default_location_id`),
  CONSTRAINT `FK6581AE69DFE4C4C` FOREIGN KEY (`party_type_id`) REFERENCES `party_type` (`id`),
  CONSTRAINT `FK6581AE6D1DFC6D7` FOREIGN KEY (`default_location_id`) REFERENCES `location` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `party`
--

LOCK TABLES `party` WRITE;
/*!40000 ALTER TABLE `party` DISABLE KEYS */;
INSERT INTO `party` VALUES
('1',0,'2020-12-26 00:00:00','2020-12-26 00:00:00','1','org.pih.warehouse.core.Organization','MO',NULL,'Main Organization',NULL,''),
('2',0,'2020-12-26 00:00:00','2020-12-26 00:00:00','1','org.pih.warehouse.core.Organization','SO',NULL,'Supplier Organization',NULL,'');
/*!40000 ALTER TABLE `party` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `party_role`
--

DROP TABLE IF EXISTS `party_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `party_role` (
  `id` char(38) NOT NULL,
  `version` bigint(20) NOT NULL,
  `end_date` datetime DEFAULT NULL,
  `party_id` char(38) NOT NULL,
  `role_type` varchar(255) NOT NULL,
  `start_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK1C92FE2F3E67CF9F` (`party_id`),
  CONSTRAINT `FK1C92FE2F3E67CF9F` FOREIGN KEY (`party_id`) REFERENCES `party` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `party_role`
--

LOCK TABLES `party_role` WRITE;
/*!40000 ALTER TABLE `party_role` DISABLE KEYS */;
INSERT INTO `party_role` VALUES
('1',0,NULL,'1','ROLE_ORGANIZATION',NULL),
('2',0,NULL,'2','ROLE_SUPPLIER',NULL);
/*!40000 ALTER TABLE `party_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `party_type`
--

DROP TABLE IF EXISTS `party_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `party_type` (
  `id` char(38) NOT NULL,
  `version` bigint(20) NOT NULL,
  `code` varchar(255) NOT NULL,
  `date_created` datetime NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `last_updated` datetime NOT NULL,
  `name` varchar(255) NOT NULL,
  `party_type_code` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `party_type_code_uniq_idx` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `party_type`
--

LOCK TABLES `party_type` WRITE;
/*!40000 ALTER TABLE `party_type` DISABLE KEYS */;
INSERT INTO `party_type` VALUES
('1',0,'ORG','2018-03-06 00:00:00','Organization','2018-03-06 00:00:00','Organization','ORGANIZATION'),
('2',0,'PERSON','2018-03-06 00:00:00','Person','2018-03-06 00:00:00','Person','PERSON');
/*!40000 ALTER TABLE `party_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_method_type`
--

DROP TABLE IF EXISTS `payment_method_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `payment_method_type` (
  `id` char(38) NOT NULL,
  `version` bigint(20) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `payment_method_type_code` varchar(255) NOT NULL,
  `active` bit(1) NOT NULL,
  `date_created` datetime NOT NULL,
  `last_updated` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_method_type`
--

LOCK TABLES `payment_method_type` WRITE;
/*!40000 ALTER TABLE `payment_method_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `payment_method_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_term`
--

DROP TABLE IF EXISTS `payment_term`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `payment_term` (
  `id` char(38) NOT NULL,
  `version` bigint(20) NOT NULL,
  `name` varchar(255) NOT NULL,
  `code` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `last_updated` datetime NOT NULL,
  `prepayment_percent` decimal(19,2) DEFAULT NULL,
  `days_to_payment` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_term`
--

LOCK TABLES `payment_term` WRITE;
/*!40000 ALTER TABLE `payment_term` DISABLE KEYS */;
INSERT INTO `payment_term` VALUES
('COD',0,'Cash On Delivery','COD',NULL,'2023-08-14 15:02:59','2023-08-14 15:02:59',NULL,NULL),
('NET30',0,'Net 30','NET30',NULL,'2023-08-14 15:02:59','2023-08-14 15:02:59',NULL,30),
('PIA',0,'Payment In Advance','PIA',NULL,'2023-08-14 15:02:59','2023-08-14 15:02:59',NULL,NULL),
('PP100',0,'Prepayment 100','PP100',NULL,'2023-08-14 15:02:59','2023-08-14 15:02:59',100.00,NULL),
('PP25',0,'Prepayment 25/Net 30','PP25',NULL,'2023-08-14 15:02:59','2023-08-14 15:02:59',25.00,30),
('PP50',0,'Prepayment 50/Net 30','PP50',NULL,'2023-08-14 15:02:59','2023-08-14 15:02:59',50.00,30),
('US',0,'Upon shipment','US',NULL,'2023-08-14 15:02:59','2023-08-14 15:02:59',NULL,30);
/*!40000 ALTER TABLE `payment_term` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `pending_cycle_count_request`
--

DROP TABLE IF EXISTS `pending_cycle_count_request`;
/*!50001 DROP VIEW IF EXISTS `pending_cycle_count_request`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `pending_cycle_count_request` AS SELECT
 NULL AS `id`,
 NULL AS `cycle_count_request_id`,
 NULL AS `facility_id`,
 NULL AS `product_id`,
 NULL AS `status`,
 NULL AS `request_type`,
 NULL AS `blind_count`,
 NULL AS `date_created`,
 NULL AS `last_updated`,
 NULL AS `created_by_id`,
 NULL AS `updated_by_id`,
 NULL AS `abc_class`,
 NULL AS `quantity_on_hand`,
 NULL AS `quantity_allocated`,
 NULL AS `negative_item_count`,
 NULL AS `internal_locations` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `person`
--

DROP TABLE IF EXISTS `person`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `person` (
  `id` char(38) NOT NULL,
  `version` bigint(20) NOT NULL,
  `date_created` datetime NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `last_updated` datetime NOT NULL,
  `phone_number` varchar(255) DEFAULT NULL,
  `active` bit(1) DEFAULT b'1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `person`
--

LOCK TABLES `person` WRITE;
/*!40000 ALTER TABLE `person` DISABLE KEYS */;
INSERT INTO `person` VALUES
('1',2,'2010-08-25 00:00:00','admin@admin.com','Miss','Administrator','2026-10-13 06:24:20',NULL,'');
/*!40000 ALTER TABLE `person` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `picklist`
--

DROP TABLE IF EXISTS `picklist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `picklist` (
  `id` char(38) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `picker_id` char(38) DEFAULT NULL,
  `date_picked` datetime DEFAULT NULL,
  `version` bigint(20) NOT NULL,
  `date_created` datetime NOT NULL,
  `last_updated` datetime NOT NULL,
  `created_by_id` char(38) DEFAULT NULL,
  `updated_by_id` char(38) DEFAULT NULL,
  `requisition_id` char(38) DEFAULT NULL,
  `order_id` char(38) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKD3F8383F217F5972` (`created_by_id`),
  KEY `FKD3F8383F426DD105` (`updated_by_id`),
  KEY `FKD3F8383F5DE9E374` (`requisition_id`),
  KEY `FKD3F8383FA3E976BC` (`picker_id`),
  KEY `fk_picklist_order` (`order_id`),
  CONSTRAINT `FKD3F8383F217F5972` FOREIGN KEY (`created_by_id`) REFERENCES `user` (`id`),
  CONSTRAINT `FKD3F8383F426DD105` FOREIGN KEY (`updated_by_id`) REFERENCES `user` (`id`),
  CONSTRAINT `FKD3F8383F5DE9E374` FOREIGN KEY (`requisition_id`) REFERENCES `requisition` (`id`),
  CONSTRAINT `FKD3F8383FA3E976BC` FOREIGN KEY (`picker_id`) REFERENCES `person` (`id`),
  CONSTRAINT `fk_picklist_order` FOREIGN KEY (`order_id`) REFERENCES `order` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `picklist`
--

LOCK TABLES `picklist` WRITE;
/*!40000 ALTER TABLE `picklist` DISABLE KEYS */;
/*!40000 ALTER TABLE `picklist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `picklist_item`
--

DROP TABLE IF EXISTS `picklist_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `picklist_item` (
  `id` char(38) NOT NULL,
  `quantity` int(11) DEFAULT NULL,
  `picklist_id` char(38) DEFAULT NULL,
  `inventory_item_id` char(38) DEFAULT NULL,
  `version` bigint(20) NOT NULL,
  `date_created` datetime NOT NULL,
  `last_updated` datetime NOT NULL,
  `created_by_id` char(38) DEFAULT NULL,
  `updated_by_id` char(38) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `reason_code` varchar(255) DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `requisition_item_id` char(38) DEFAULT NULL,
  `picklist_items_idx` int(11) DEFAULT NULL,
  `bin_location_id` char(38) DEFAULT NULL,
  `sort_order` int(11) DEFAULT NULL,
  `order_item_id` char(38) DEFAULT NULL,
  `quantity_picked` int(11) DEFAULT NULL,
  `date_picked` datetime DEFAULT NULL,
  `picked_by_id` char(38) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKE7584B1369DB749D` (`bin_location_id`),
  KEY `fk_picklist_item_order_item` (`order_item_id`),
  KEY `picklist_item_ibfk_1` (`requisition_item_id`),
  KEY `picklist_item_ibfk_2` (`picklist_id`),
  KEY `picklist_item_ibfk_3` (`created_by_id`),
  KEY `picklist_item_ibfk_4` (`updated_by_id`),
  KEY `picklist_item_ibfk_5` (`inventory_item_id`),
  KEY `fk_picklist_item_picked_by_id_person` (`picked_by_id`),
  CONSTRAINT `FKE7584B1369DB749D` FOREIGN KEY (`bin_location_id`) REFERENCES `location` (`id`),
  CONSTRAINT `fk_picklist_item_order_item` FOREIGN KEY (`order_item_id`) REFERENCES `order_item` (`id`),
  CONSTRAINT `fk_picklist_item_picked_by_id_person` FOREIGN KEY (`picked_by_id`) REFERENCES `person` (`id`),
  CONSTRAINT `picklist_item_ibfk_1` FOREIGN KEY (`requisition_item_id`) REFERENCES `requisition_item` (`id`),
  CONSTRAINT `picklist_item_ibfk_2` FOREIGN KEY (`picklist_id`) REFERENCES `picklist` (`id`),
  CONSTRAINT `picklist_item_ibfk_3` FOREIGN KEY (`created_by_id`) REFERENCES `user` (`id`),
  CONSTRAINT `picklist_item_ibfk_4` FOREIGN KEY (`updated_by_id`) REFERENCES `user` (`id`),
  CONSTRAINT `picklist_item_ibfk_5` FOREIGN KEY (`inventory_item_id`) REFERENCES `inventory_item` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `picklist_item`
--

LOCK TABLES `picklist_item` WRITE;
/*!40000 ALTER TABLE `picklist_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `picklist_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `preference_type`
--

DROP TABLE IF EXISTS `preference_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `preference_type` (
  `id` char(38) NOT NULL,
  `name` varchar(255) NOT NULL,
  `validation_code` varchar(100) DEFAULT 'DEFAULT',
  `date_created` datetime DEFAULT NULL,
  `last_updated` datetime DEFAULT NULL,
  `created_by_id` char(38) DEFAULT NULL,
  `updated_by_id` char(38) DEFAULT NULL,
  `version` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `fk_preference_type_created_by` (`created_by_id`),
  KEY `fk_preference_type_updated_by` (`updated_by_id`),
  CONSTRAINT `fk_preference_type_created_by` FOREIGN KEY (`created_by_id`) REFERENCES `user` (`id`),
  CONSTRAINT `fk_preference_type_updated_by` FOREIGN KEY (`updated_by_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `preference_type`
--

LOCK TABLES `preference_type` WRITE;
/*!40000 ALTER TABLE `preference_type` DISABLE KEYS */;
INSERT INTO `preference_type` VALUES
('APPROVED','Approved','DEFAULT','2023-08-14 14:59:20','2023-08-14 14:59:20',NULL,NULL,0),
('CONTRACT','Contract','PREFERRED','2023-08-14 14:59:20','2023-08-14 14:59:20',NULL,NULL,0),
('DO NOT ORDER','Do Not Order','BLOCK','2023-08-14 14:59:20','2023-08-14 14:59:20',NULL,NULL,0),
('NOT QUALIFIED','Not Qualified','HIDE','2023-08-14 14:59:20','2023-08-14 14:59:20',NULL,NULL,0),
('PREFERRED','Preferred','DEFAULT','2023-08-14 14:59:20','2023-08-14 14:59:20',NULL,NULL,0),
('QUALIFIED','Qualified','DEFAULT','2023-08-14 14:59:20','2023-08-14 14:59:20',NULL,NULL,0);
/*!40000 ALTER TABLE `preference_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `product` (
  `id` char(38) NOT NULL,
  `version` bigint(20) NOT NULL,
  `category_id` char(38) DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `description` mediumtext DEFAULT NULL,
  `last_updated` datetime NOT NULL,
  `name` varchar(255) NOT NULL,
  `product_code` varchar(255) DEFAULT NULL,
  `unit_of_measure_id` char(38) DEFAULT NULL,
  `cold_chain` bit(1) DEFAULT NULL,
  `manufacturer` varchar(255) DEFAULT NULL,
  `manufacturer_code` varchar(255) DEFAULT NULL,
  `ndc` varchar(255) DEFAULT NULL,
  `upc` varchar(255) DEFAULT NULL,
  `unit_of_measure` varchar(255) DEFAULT NULL,
  `created_by_id` char(38) DEFAULT NULL,
  `updated_by_id` char(38) DEFAULT NULL,
  `default_uom_id` char(38) DEFAULT NULL,
  `brand_name` varchar(255) DEFAULT NULL,
  `vendor` varchar(255) DEFAULT NULL,
  `vendor_code` varchar(255) DEFAULT NULL,
  `package_size` int(11) DEFAULT NULL,
  `model_number` varchar(255) DEFAULT NULL,
  `manufacturer_name` varchar(255) DEFAULT NULL,
  `vendor_name` varchar(255) DEFAULT NULL,
  `active` bit(1) DEFAULT NULL,
  `controlled_substance` bit(1) DEFAULT NULL,
  `essential` bit(1) DEFAULT NULL,
  `hazardous_material` bit(1) DEFAULT NULL,
  `lot_control` bit(1) DEFAULT NULL,
  `serialized` bit(1) DEFAULT NULL,
  `price_per_unit` decimal(19,4) DEFAULT NULL,
  `reconditioned` bit(1) DEFAULT NULL,
  `product_type_id` char(38) DEFAULT NULL,
  `abc_class` varchar(255) DEFAULT NULL,
  `cost_per_unit` decimal(19,4) DEFAULT NULL,
  `gl_account_id` char(38) DEFAULT NULL,
  `lot_and_expiry_control` bit(1) DEFAULT NULL,
  `product_family_id` char(38) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `product_code` (`product_code`),
  KEY `FKED8DCCEF217F5972` (`created_by_id`),
  KEY `FKED8DCCEF426DD105` (`updated_by_id`),
  KEY `FKED8DCCEFABD88AC6` (`product_type_id`),
  KEY `FKED8DCCEFEEB2908D` (`default_uom_id`),
  KEY `FKED8DCCEFEF4C770D` (`category_id`),
  KEY `fk_product_gl_account` (`gl_account_id`),
  KEY `fk_product_product_family` (`product_family_id`),
  CONSTRAINT `FKED8DCCEF217F5972` FOREIGN KEY (`created_by_id`) REFERENCES `user` (`id`),
  CONSTRAINT `FKED8DCCEF426DD105` FOREIGN KEY (`updated_by_id`) REFERENCES `user` (`id`),
  CONSTRAINT `FKED8DCCEFABD88AC6` FOREIGN KEY (`product_type_id`) REFERENCES `product_type` (`id`),
  CONSTRAINT `FKED8DCCEFEEB2908D` FOREIGN KEY (`default_uom_id`) REFERENCES `unit_of_measure` (`id`),
  CONSTRAINT `FKED8DCCEFEF4C770D` FOREIGN KEY (`category_id`) REFERENCES `category` (`id`),
  CONSTRAINT `fk_product_gl_account` FOREIGN KEY (`gl_account_id`) REFERENCES `gl_account` (`id`),
  CONSTRAINT `fk_product_product_family` FOREIGN KEY (`product_family_id`) REFERENCES `product_group` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product`
--

LOCK TABLES `product` WRITE;
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
INSERT INTO `product` VALUES
('seed-prd-01',0,'seed-cat-koper','2026-10-13 07:48:45',NULL,'2026-10-13 07:48:45','Koper bagasi 28\" mar 2025','KPR-B28-2503',NULL,'\0',NULL,NULL,NULL,NULL,'pcs','1','1',NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,'','\0','','\0','','\0',NULL,'\0','DEFAULT',NULL,NULL,NULL,'\0',NULL),
('seed-prd-02',0,'seed-cat-koper','2026-10-13 07:48:45',NULL,'2026-10-13 07:48:45','Koper cabin 16\" mar 2025','KPR-C16-2503',NULL,'\0',NULL,NULL,NULL,NULL,'pcs','1','1',NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,'','\0','','\0','','\0',NULL,'\0','DEFAULT',NULL,NULL,NULL,'\0',NULL),
('seed-prd-03',0,'seed-cat-koper','2026-10-13 07:48:45',NULL,'2026-10-13 07:48:45','Koper bagasi 26\" nov 2025','KPR-B26-2511',NULL,'\0',NULL,NULL,NULL,NULL,'pcs','1','1',NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,'','\0','','\0','','\0',NULL,'\0','DEFAULT',NULL,NULL,NULL,'\0',NULL),
('seed-prd-04',0,'seed-cat-koper','2026-10-13 07:48:45',NULL,'2026-10-13 07:48:45','Koper cabin 16\" nov 2025','KPR-C16-2511',NULL,'\0',NULL,NULL,NULL,NULL,'pcs','1','1',NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,'','\0','','\0','','\0',NULL,'\0','DEFAULT',NULL,NULL,NULL,'\0',NULL),
('seed-prd-05',0,'seed-cat-tas','2026-10-13 07:48:45',NULL,'2026-10-13 07:48:45','Tas paspor type C mar 2025','TAS-PSP-C-2503',NULL,'\0',NULL,NULL,NULL,NULL,'pcs','1','1',NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,'','\0','','\0','','\0',NULL,'\0','DEFAULT',NULL,NULL,NULL,'\0',NULL),
('seed-prd-06',0,'seed-cat-tas','2026-10-13 07:48:45',NULL,'2026-10-13 07:48:45','Tas paspor type B nov 2025','TAS-PSP-B-2511',NULL,'\0',NULL,NULL,NULL,NULL,'pcs','1','1',NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,'','\0','','\0','','\0',NULL,'\0','DEFAULT',NULL,NULL,NULL,'\0',NULL),
('seed-prd-07',0,'seed-cat-tas','2026-10-13 07:48:45',NULL,'2026-10-13 07:48:45','Tas sendal parasut','TAS-SDL-PRS',NULL,'\0',NULL,NULL,NULL,NULL,'pcs','1','1',NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,'','\0','','\0','','\0',NULL,'\0','DEFAULT',NULL,NULL,NULL,'\0',NULL),
('seed-prd-08',0,'seed-cat-tas','2026-10-13 07:48:45',NULL,'2026-10-13 07:48:45','Tas sendal torin','TAS-SDL-TRN',NULL,'\0',NULL,NULL,NULL,NULL,'pcs','1','1',NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,'','\0','','\0','','\0',NULL,'\0','DEFAULT',NULL,NULL,NULL,'\0',NULL),
('seed-prd-09',0,'seed-cat-buku','2026-10-13 07:48:45',NULL,'2026-10-13 07:48:45','Buku doa','BKU-DOA',NULL,'\0',NULL,NULL,NULL,NULL,'pcs','1','1',NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,'','\0','','\0','','\0',NULL,'\0','DEFAULT',NULL,NULL,NULL,'\0',NULL),
('seed-prd-10',0,'seed-cat-syal','2026-10-13 07:48:45',NULL,'2026-10-13 07:48:45','Syal 2 color','SYL-2C',NULL,'\0',NULL,NULL,NULL,NULL,'pcs','1','1',NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,'','\0','','\0','','\0',NULL,'\0','DEFAULT',NULL,NULL,NULL,'\0',NULL),
('seed-prd-11',0,'seed-cat-syal','2026-10-13 07:48:45',NULL,'2026-10-13 07:48:45','Syal 3 color typeface','SYL-3C-TF',NULL,'\0',NULL,NULL,NULL,NULL,'pcs','1','1',NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,'','\0','','\0','','\0',NULL,'\0','DEFAULT',NULL,NULL,NULL,'\0',NULL),
('seed-prd-12',0,'seed-cat-syal','2026-10-13 07:48:45',NULL,'2026-10-13 07:48:45','Syal 2 color dotted','SYL-2C-DOT',NULL,'\0',NULL,NULL,NULL,NULL,'pcs','1','1',NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,'','\0','','\0','','\0',NULL,'\0','DEFAULT',NULL,NULL,NULL,'\0',NULL),
('seed-prd-13',0,'seed-cat-syal','2026-10-13 07:48:45',NULL,'2026-10-13 07:48:45','Syal 3 color typeface + logo','SYL-3C-TFL',NULL,'\0',NULL,NULL,NULL,NULL,'pcs','1','1',NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,'','\0','','\0','','\0',NULL,'\0','DEFAULT',NULL,NULL,NULL,'\0',NULL),
('seed-prd-14',0,'seed-cat-batik','2026-10-13 07:48:45',NULL,'2026-10-13 07:48:45','Batik katun','BTK-KTN',NULL,'\0',NULL,NULL,NULL,NULL,'pcs','1','1',NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,'','\0','','\0','','\0',NULL,'\0','DEFAULT',NULL,NULL,NULL,'\0',NULL),
('seed-prd-15',0,'seed-cat-batik','2026-10-13 07:48:45',NULL,'2026-10-13 07:48:45','Batik printing 1 side spandex','BTK-PRT-SPX',NULL,'\0',NULL,NULL,NULL,NULL,'pcs','1','1',NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,'','\0','','\0','','\0',NULL,'\0','DEFAULT',NULL,NULL,NULL,'\0',NULL),
('seed-prd-16',0,'seed-cat-seragam','2026-10-13 07:48:45',NULL,'2026-10-13 07:48:45','Seragam okt 2026 P (XS-5XL)','SRG-2610-P',NULL,'\0',NULL,NULL,NULL,NULL,'pcs','1','1',NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,'','\0','','\0','','\0',NULL,'\0','DEFAULT',NULL,NULL,NULL,'\0',NULL),
('seed-prd-17',0,'seed-cat-seragam','2026-10-13 07:48:45',NULL,'2026-10-13 07:48:45','Seragam okt 2026 L (XS-5XL)','SRG-2610-L',NULL,'\0',NULL,NULL,NULL,NULL,'pcs','1','1',NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,'','\0','','\0','','\0',NULL,'\0','DEFAULT',NULL,NULL,NULL,'\0',NULL),
('seed-prd-18',0,'seed-cat-busana','2026-10-13 07:48:45',NULL,'2026-10-13 07:48:45','Mukena BLACK FULL','MKN-BLK',NULL,'\0',NULL,NULL,NULL,NULL,'pcs','1','1',NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,'','\0','','\0','','\0',NULL,'\0','DEFAULT',NULL,NULL,NULL,'\0',NULL),
('seed-prd-19',0,'seed-cat-busana','2026-10-13 07:48:45',NULL,'2026-10-13 07:48:45','Kerudung BLACK FULL','KRD-BLK',NULL,'\0',NULL,NULL,NULL,NULL,'pcs','1','1',NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,'','\0','','\0','','\0',NULL,'\0','DEFAULT',NULL,NULL,NULL,'\0',NULL),
('seed-prd-20',0,'seed-cat-ihrom','2026-10-13 07:48:45',NULL,'2026-10-13 07:48:45','Ihrom ALL SIZE REGULAR','IHR-REG',NULL,'\0',NULL,NULL,NULL,NULL,'pcs','1','1',NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,'','\0','','\0','','\0',NULL,'\0','DEFAULT',NULL,NULL,NULL,'\0',NULL),
('seed-prd-21',0,'seed-cat-ihrom','2026-10-13 07:48:45',NULL,'2026-10-13 07:48:45','Ihrom ALL SIZE PREMIUM','IHR-PRM',NULL,'\0',NULL,NULL,NULL,NULL,'pcs','1','1',NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,'','\0','','\0','','\0',NULL,'\0','DEFAULT',NULL,NULL,NULL,'\0',NULL),
('seed-prd-22',0,'seed-cat-ihrom','2026-10-13 07:48:45',NULL,'2026-10-13 07:48:45','Ihrom ALL SIZE PREMIUM DTF','IHR-PRM-DTF',NULL,'\0',NULL,NULL,NULL,NULL,'pcs','1','1',NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,'','\0','','\0','','\0',NULL,'\0','DEFAULT',NULL,NULL,NULL,'\0',NULL),
('seed-prd-23',0,'seed-cat-ihrom','2026-10-13 07:48:45',NULL,'2026-10-13 07:48:45','Sabuk ihrom','IHR-SBK',NULL,'\0',NULL,NULL,NULL,NULL,'pcs','1','1',NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,'','\0','','\0','','\0',NULL,'\0','DEFAULT',NULL,NULL,NULL,'\0',NULL);
/*!40000 ALTER TABLE `product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_association`
--

DROP TABLE IF EXISTS `product_association`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_association` (
  `id` char(38) NOT NULL,
  `code` varchar(100) NOT NULL,
  `product_id` char(38) NOT NULL,
  `associated_product_id` char(38) NOT NULL,
  `quantity` decimal(19,2) NOT NULL,
  `comments` varchar(255) DEFAULT NULL,
  `version` bigint(20) NOT NULL,
  `date_created` datetime NOT NULL,
  `last_updated` datetime NOT NULL,
  `mutual_association_id` char(38) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKED441931C8653BC0` (`associated_product_id`),
  KEY `FKED441931DED5FAE7` (`product_id`),
  KEY `fk_product_association_mutual_association` (`mutual_association_id`),
  CONSTRAINT `FKED441931C8653BC0` FOREIGN KEY (`associated_product_id`) REFERENCES `product` (`id`),
  CONSTRAINT `FKED441931DED5FAE7` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`),
  CONSTRAINT `fk_product_association_mutual_association` FOREIGN KEY (`mutual_association_id`) REFERENCES `product_association` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_association`
--

LOCK TABLES `product_association` WRITE;
/*!40000 ALTER TABLE `product_association` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_association` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_attribute`
--

DROP TABLE IF EXISTS `product_attribute`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_attribute` (
  `id` char(38) NOT NULL,
  `version` bigint(20) NOT NULL,
  `attribute_id` char(38) DEFAULT NULL,
  `product_id` char(38) DEFAULT NULL,
  `attributes_idx` int(11) DEFAULT NULL,
  `value` varchar(255) DEFAULT NULL,
  `unit_of_measure_id` char(38) DEFAULT NULL,
  `product_supplier_id` char(38) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK94A534C24DEBC91` (`unit_of_measure_id`),
  KEY `FK94A534C29542386` (`product_supplier_id`),
  KEY `FK94A534C47B0D087` (`attribute_id`),
  KEY `FK94A534CDED5FAE7` (`product_id`),
  CONSTRAINT `FK94A534C24DEBC91` FOREIGN KEY (`unit_of_measure_id`) REFERENCES `unit_of_measure` (`id`),
  CONSTRAINT `FK94A534C29542386` FOREIGN KEY (`product_supplier_id`) REFERENCES `product_supplier` (`id`),
  CONSTRAINT `FK94A534C47B0D087` FOREIGN KEY (`attribute_id`) REFERENCES `attribute` (`id`),
  CONSTRAINT `FK94A534CDED5FAE7` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_attribute`
--

LOCK TABLES `product_attribute` WRITE;
/*!40000 ALTER TABLE `product_attribute` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_attribute` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_availability`
--

DROP TABLE IF EXISTS `product_availability`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_availability` (
  `id` char(38) NOT NULL,
  `version` int(11) NOT NULL,
  `bin_location_id` char(38) DEFAULT NULL,
  `inventory_item_id` char(38) NOT NULL,
  `location_id` char(38) NOT NULL,
  `product_id` char(38) NOT NULL,
  `product_code` varchar(100) NOT NULL,
  `lot_number` varchar(100) NOT NULL DEFAULT 'DEFAULT',
  `bin_location_name` varchar(100) NOT NULL DEFAULT 'DEFAULT',
  `quantity_allocated` int(11) DEFAULT NULL,
  `quantity_on_hand` int(11) NOT NULL,
  `date_created` datetime NOT NULL,
  `last_updated` datetime NOT NULL,
  `quantity_on_hold` bigint(20) DEFAULT NULL,
  `quantity_available_to_promise` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `product_availability_uniq_idx` (`location_id`,`product_code`,`lot_number`,`bin_location_name`),
  KEY `FKD3FC6EAB69DB749D` (`bin_location_id`),
  KEY `FKD3FC6EABAA992CED` (`inventory_item_id`),
  KEY `product_availability_product_location_idx` (`product_id`,`location_id`),
  CONSTRAINT `FKD3FC6EAB69DB749D` FOREIGN KEY (`bin_location_id`) REFERENCES `location` (`id`),
  CONSTRAINT `FKD3FC6EAB8ABEBD5` FOREIGN KEY (`location_id`) REFERENCES `location` (`id`),
  CONSTRAINT `FKD3FC6EABAA992CED` FOREIGN KEY (`inventory_item_id`) REFERENCES `inventory_item` (`id`),
  CONSTRAINT `FKD3FC6EABDED5FAE7` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_availability`
--

LOCK TABLES `product_availability` WRITE;
/*!40000 ALTER TABLE `product_availability` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_availability` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_catalog`
--

DROP TABLE IF EXISTS `product_catalog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_catalog` (
  `id` char(38) NOT NULL,
  `version` bigint(20) NOT NULL,
  `active` bit(1) DEFAULT NULL,
  `code` varchar(255) NOT NULL,
  `date_created` datetime NOT NULL,
  `description` longtext DEFAULT NULL,
  `last_updated` datetime NOT NULL,
  `name` varchar(255) NOT NULL,
  `color` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code_idx` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_catalog`
--

LOCK TABLES `product_catalog` WRITE;
/*!40000 ALTER TABLE `product_catalog` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_catalog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_catalog_item`
--

DROP TABLE IF EXISTS `product_catalog_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_catalog_item` (
  `id` char(38) NOT NULL,
  `version` bigint(20) NOT NULL,
  `active` bit(1) NOT NULL,
  `date_created` datetime NOT NULL,
  `last_updated` datetime NOT NULL,
  `product_id` char(38) NOT NULL,
  `product_catalog_id` char(38) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK187E54C9DED5FAE7` (`product_id`),
  KEY `FK187E54C9FB5E604E` (`product_catalog_id`),
  CONSTRAINT `FK187E54C9DED5FAE7` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`),
  CONSTRAINT `FK187E54C9FB5E604E` FOREIGN KEY (`product_catalog_id`) REFERENCES `product_catalog` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_catalog_item`
--

LOCK TABLES `product_catalog_item` WRITE;
/*!40000 ALTER TABLE `product_catalog_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_catalog_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_category`
--

DROP TABLE IF EXISTS `product_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_category` (
  `product_id` char(38) DEFAULT NULL,
  `category_id` char(38) DEFAULT NULL,
  `categories_idx` int(11) DEFAULT NULL,
  KEY `FKA0303E4EDED5FAE7` (`product_id`),
  KEY `FKA0303E4EEF4C770D` (`category_id`),
  CONSTRAINT `FKA0303E4EEF4C770D` FOREIGN KEY (`category_id`) REFERENCES `category` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_category`
--

LOCK TABLES `product_category` WRITE;
/*!40000 ALTER TABLE `product_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `product_classification`
--

DROP TABLE IF EXISTS `product_classification`;
/*!50001 DROP VIEW IF EXISTS `product_classification`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `product_classification` AS SELECT
 NULL AS `inventory_id`,
 NULL AS `product_id`,
 NULL AS `abc_class` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `product_component`
--

DROP TABLE IF EXISTS `product_component`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_component` (
  `id` char(38) NOT NULL,
  `assembly_product_id` char(38) NOT NULL,
  `component_product_id` char(38) NOT NULL,
  `quantity` decimal(19,2) NOT NULL,
  `unit_of_measure_id` char(38) NOT NULL,
  `version` bigint(20) NOT NULL,
  `date_created` datetime NOT NULL,
  `last_updated` datetime NOT NULL,
  `product_components_idx` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKB511C5AD20E351EA` (`component_product_id`),
  KEY `FKB511C5AD24DEBC91` (`unit_of_measure_id`),
  KEY `FKB511C5ADFB4C199C` (`assembly_product_id`),
  CONSTRAINT `FKB511C5AD20E351EA` FOREIGN KEY (`component_product_id`) REFERENCES `product` (`id`),
  CONSTRAINT `FKB511C5AD24DEBC91` FOREIGN KEY (`unit_of_measure_id`) REFERENCES `unit_of_measure` (`id`),
  CONSTRAINT `FKB511C5ADFB4C199C` FOREIGN KEY (`assembly_product_id`) REFERENCES `product` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_component`
--

LOCK TABLES `product_component` WRITE;
/*!40000 ALTER TABLE `product_component` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_component` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `product_count_history`
--

DROP TABLE IF EXISTS `product_count_history`;
/*!50001 DROP VIEW IF EXISTS `product_count_history`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `product_count_history` AS SELECT
 NULL AS `inventory_id`,
 NULL AS `product_id`,
 NULL AS `date_counted` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `product_cycle_count_history`
--

DROP TABLE IF EXISTS `product_cycle_count_history`;
/*!50001 DROP VIEW IF EXISTS `product_cycle_count_history`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `product_cycle_count_history` AS SELECT
 NULL AS `inventory_id`,
 NULL AS `product_id`,
 NULL AS `date_counted` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `product_demand`
--

DROP TABLE IF EXISTS `product_demand`;
/*!50001 DROP VIEW IF EXISTS `product_demand`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `product_demand` AS SELECT
 NULL AS `request_id`,
 NULL AS `request_status`,
 NULL AS `request_number`,
 NULL AS `date_created`,
 NULL AS `date_requested`,
 NULL AS `date_issued`,
 NULL AS `origin_id`,
 NULL AS `origin_name`,
 NULL AS `destination_id`,
 NULL AS `destination_name`,
 NULL AS `request_item_id`,
 NULL AS `product_id`,
 NULL AS `product_code`,
 NULL AS `product_name`,
 NULL AS `quantity_requested`,
 NULL AS `quantity_canceled`,
 NULL AS `quantity_approved`,
 NULL AS `quantity_modified`,
 NULL AS `quantity_picked`,
 NULL AS `cancel_reason_code`,
 NULL AS `cancel_comments`,
 NULL AS `pick_reason_code`,
 NULL AS `request_item_status`,
 NULL AS `reason_code_classification`,
 NULL AS `picklist_reason_code`,
 NULL AS `reason_code`,
 NULL AS `request_item_change_status`,
 NULL AS `quantity_demand` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `product_demand_details`
--

DROP TABLE IF EXISTS `product_demand_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_demand_details` (
  `request_id` char(38) NOT NULL,
  `request_status` varchar(255) DEFAULT NULL,
  `request_number` varchar(255) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `date_requested` datetime NOT NULL,
  `date_issued` datetime,
  `origin_id` char(38) NOT NULL,
  `origin_name` varchar(255) NOT NULL,
  `destination_id` char(38) NOT NULL,
  `destination_name` varchar(255) NOT NULL,
  `request_item_id` char(38) NOT NULL,
  `product_id` char(38) NOT NULL,
  `product_code` varchar(255) DEFAULT NULL,
  `product_name` varchar(255) NOT NULL,
  `quantity_requested` int(11) NOT NULL,
  `quantity_canceled` int(11) NOT NULL,
  `quantity_approved` int(11) NOT NULL,
  `quantity_modified` decimal(32,0) NOT NULL,
  `quantity_picked` decimal(32,0) NOT NULL,
  `quantity_demand` decimal(32,0) DEFAULT NULL,
  `reason_code` varchar(255) DEFAULT NULL,
  `reason_code_classification` varchar(31) DEFAULT NULL,
  KEY `product_id` (`product_id`,`origin_id`,`destination_id`,`date_issued`,`date_requested`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_demand_details`
--

LOCK TABLES `product_demand_details` WRITE;
/*!40000 ALTER TABLE `product_demand_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_demand_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_demand_details_tmp`
--

DROP TABLE IF EXISTS `product_demand_details_tmp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_demand_details_tmp` (
  `request_id` char(38) NOT NULL,
  `request_status` varchar(255) DEFAULT NULL,
  `request_number` varchar(255) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `date_requested` datetime NOT NULL,
  `date_issued` datetime,
  `origin_id` char(38) NOT NULL,
  `origin_name` varchar(255) NOT NULL,
  `destination_id` char(38) NOT NULL,
  `destination_name` varchar(255) NOT NULL,
  `request_item_id` char(38) NOT NULL,
  `product_id` char(38) NOT NULL,
  `product_code` varchar(255) DEFAULT NULL,
  `product_name` varchar(255) NOT NULL,
  `quantity_requested` int(11) NOT NULL,
  `quantity_canceled` int(11) NOT NULL,
  `quantity_approved` int(11) NOT NULL,
  `quantity_modified` decimal(32,0) NOT NULL,
  `quantity_picked` decimal(32,0) NOT NULL,
  `quantity_demand` decimal(32,0) DEFAULT NULL,
  `reason_code` varchar(255) DEFAULT NULL,
  `reason_code_classification` varchar(31) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_demand_details_tmp`
--

LOCK TABLES `product_demand_details_tmp` WRITE;
/*!40000 ALTER TABLE `product_demand_details_tmp` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_demand_details_tmp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_dimension`
--

DROP TABLE IF EXISTS `product_dimension`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_dimension` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `version` bigint(20) NOT NULL,
  `abc_class` varchar(255) DEFAULT NULL,
  `active` bit(1) NOT NULL,
  `category_name` varchar(255) NOT NULL,
  `generic_product` varchar(255) DEFAULT NULL,
  `product_code` varchar(255) NOT NULL,
  `product_id` char(38) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `unit_cost` decimal(19,2) DEFAULT NULL,
  `unit_price` decimal(19,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKC73E1616DED5FAE7` (`product_id`),
  CONSTRAINT `FKC73E1616DED5FAE7` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_dimension`
--

LOCK TABLES `product_dimension` WRITE;
/*!40000 ALTER TABLE `product_dimension` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_dimension` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_document`
--

DROP TABLE IF EXISTS `product_document`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_document` (
  `product_id` char(38) DEFAULT NULL,
  `document_id` char(38) DEFAULT NULL,
  KEY `FKD08A526BC800AA15` (`document_id`),
  KEY `FKD08A526BDED5FAE7` (`product_id`),
  CONSTRAINT `FKD08A526BC800AA15` FOREIGN KEY (`document_id`) REFERENCES `document` (`id`),
  CONSTRAINT `FKD08A526BDED5FAE7` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_document`
--

LOCK TABLES `product_document` WRITE;
/*!40000 ALTER TABLE `product_document` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_document` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `product_expiry_summary`
--

DROP TABLE IF EXISTS `product_expiry_summary`;
/*!50001 DROP VIEW IF EXISTS `product_expiry_summary`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `product_expiry_summary` AS SELECT
 NULL AS `product_id`,
 NULL AS `location_id`,
 NULL AS `expiration_date`,
 NULL AS `quantity_on_hand`,
 NULL AS `average_daily_demand` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `product_group`
--

DROP TABLE IF EXISTS `product_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_group` (
  `id` char(38) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `version` bigint(20) NOT NULL,
  `date_created` datetime NOT NULL,
  `last_updated` datetime NOT NULL,
  `category_id` char(38) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK51F3772FEF4C770D` (`category_id`),
  CONSTRAINT `FK51F3772FEF4C770D` FOREIGN KEY (`category_id`) REFERENCES `category` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_group`
--

LOCK TABLES `product_group` WRITE;
/*!40000 ALTER TABLE `product_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_group_product`
--

DROP TABLE IF EXISTS `product_group_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_group_product` (
  `product_group_id` char(38) DEFAULT NULL,
  `product_id` char(38) DEFAULT NULL,
  `products_idx` int(11) DEFAULT NULL,
  KEY `FK313A4BDF14F7BB8E` (`product_group_id`),
  KEY `FK313A4BDFDED5FAE7` (`product_id`),
  CONSTRAINT `FK313A4BDF14F7BB8E` FOREIGN KEY (`product_group_id`) REFERENCES `product_group` (`id`),
  CONSTRAINT `FK313A4BDFDED5FAE7` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_group_product`
--

LOCK TABLES `product_group_product` WRITE;
/*!40000 ALTER TABLE `product_group_product` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_group_product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_inventory_candidate`
--

DROP TABLE IF EXISTS `product_inventory_candidate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_inventory_candidate` (
  `transaction_id` char(38) DEFAULT NULL,
  `product_id` char(38) DEFAULT NULL,
  `transaction_date` datetime NOT NULL,
  `inventory_id` char(38) DEFAULT NULL,
  `facility_id` char(38) NOT NULL,
  KEY `idx_inventory_product_date` (`inventory_id`,`product_id`,`transaction_date`),
  KEY `idx_transaction_id` (`transaction_id`),
  KEY `idx_product_inventory_base` (`product_id`,`inventory_id`,`transaction_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_inventory_candidate`
--

LOCK TABLES `product_inventory_candidate` WRITE;
/*!40000 ALTER TABLE `product_inventory_candidate` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_inventory_candidate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `product_inventory_compare_view`
--

DROP TABLE IF EXISTS `product_inventory_compare_view`;
/*!50001 DROP VIEW IF EXISTS `product_inventory_compare_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `product_inventory_compare_view` AS SELECT
 NULL AS `product_id`,
 NULL AS `product_code`,
 NULL AS `product_name`,
 NULL AS `location_id`,
 NULL AS `location_name`,
 NULL AS `status`,
 NULL AS `min_quantity`,
 NULL AS `reorder_quantity`,
 NULL AS `max_quantity`,
 NULL AS `previous_quantity`,
 NULL AS `current_quantity` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `product_inventory_expiry_view`
--

DROP TABLE IF EXISTS `product_inventory_expiry_view`;
/*!50001 DROP VIEW IF EXISTS `product_inventory_expiry_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `product_inventory_expiry_view` AS SELECT
 NULL AS `location_id`,
 NULL AS `location_name`,
 NULL AS `bin_id`,
 NULL AS `bin_name`,
 NULL AS `product_id`,
 NULL AS `product_code`,
 NULL AS `product_name`,
 NULL AS `inventory_item_id`,
 NULL AS `lot_number`,
 NULL AS `expiration_date`,
 NULL AS `days_until_expiry`,
 NULL AS `quantity_on_hand` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `product_inventory_extended_view`
--

DROP TABLE IF EXISTS `product_inventory_extended_view`;
/*!50001 DROP VIEW IF EXISTS `product_inventory_extended_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `product_inventory_extended_view` AS SELECT
 NULL AS `product_id`,
 NULL AS `location_id`,
 NULL AS `date`,
 NULL AS `previous_quantity`,
 NULL AS `current_quantity` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `product_inventory_pivot_view`
--

DROP TABLE IF EXISTS `product_inventory_pivot_view`;
/*!50001 DROP VIEW IF EXISTS `product_inventory_pivot_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `product_inventory_pivot_view` AS SELECT
 NULL AS `product_id`,
 NULL AS `location_id`,
 NULL AS `previous_quantity`,
 NULL AS `current_quantity` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `product_inventory_snapshot_view`
--

DROP TABLE IF EXISTS `product_inventory_snapshot_view`;
/*!50001 DROP VIEW IF EXISTS `product_inventory_snapshot_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `product_inventory_snapshot_view` AS SELECT
 NULL AS `product_id`,
 NULL AS `location_id`,
 NULL AS `date`,
 NULL AS `quantity_on_hand` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `product_inventory_summary`
--

DROP TABLE IF EXISTS `product_inventory_summary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_inventory_summary` (
  `product_id` char(38) DEFAULT NULL,
  `product_code` varchar(255) DEFAULT NULL,
  `facility_id` char(38) NOT NULL,
  `transaction_id` char(38) NOT NULL,
  `baseline_transaction_date` datetime NOT NULL,
  `quantity_balance` decimal(32,0) DEFAULT NULL,
  KEY `idx_product_code_facility` (`product_code`,`facility_id`,`baseline_transaction_date`),
  KEY `idx_product_id_facility` (`product_id`,`facility_id`,`baseline_transaction_date`),
  KEY `idx_product_inventory_summary_lookup` (`product_code`,`facility_id`,`baseline_transaction_date` DESC)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_inventory_summary`
--

LOCK TABLES `product_inventory_summary` WRITE;
/*!40000 ALTER TABLE `product_inventory_summary` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_inventory_summary` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_merge_logger`
--

DROP TABLE IF EXISTS `product_merge_logger`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_merge_logger` (
  `id` char(38) NOT NULL,
  `primary_product_id` char(38) NOT NULL,
  `obsolete_product_id` char(38) NOT NULL,
  `related_object_id` char(38) NOT NULL,
  `related_object_class_name` varchar(255) NOT NULL,
  `date_merged` datetime NOT NULL,
  `date_reverted` datetime DEFAULT NULL,
  `comments` varchar(255) DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `last_updated` datetime NOT NULL,
  `created_by_id` char(38) NOT NULL,
  `updated_by_id` char(38) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_product_merge_logger_created_by` (`created_by_id`),
  KEY `fk_product_merge_logger_obsolete_product` (`obsolete_product_id`),
  KEY `fk_product_merge_logger_primary_product` (`primary_product_id`),
  KEY `fk_product_merge_logger_updated_by` (`updated_by_id`),
  CONSTRAINT `fk_product_merge_logger_created_by` FOREIGN KEY (`created_by_id`) REFERENCES `user` (`id`),
  CONSTRAINT `fk_product_merge_logger_obsolete_product` FOREIGN KEY (`obsolete_product_id`) REFERENCES `product` (`id`),
  CONSTRAINT `fk_product_merge_logger_primary_product` FOREIGN KEY (`primary_product_id`) REFERENCES `product` (`id`),
  CONSTRAINT `fk_product_merge_logger_updated_by` FOREIGN KEY (`updated_by_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_merge_logger`
--

LOCK TABLES `product_merge_logger` WRITE;
/*!40000 ALTER TABLE `product_merge_logger` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_merge_logger` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_package`
--

DROP TABLE IF EXISTS `product_package`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_package` (
  `id` char(38) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `gtin` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `uom_id` char(38) DEFAULT NULL,
  `product_id` char(38) DEFAULT NULL,
  `version` bigint(20) NOT NULL,
  `date_created` datetime NOT NULL,
  `last_updated` datetime NOT NULL,
  `created_by_id` char(38) DEFAULT NULL,
  `updated_by_id` char(38) DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `product_supplier_id` char(38) DEFAULT NULL,
  `product_price_id` char(38) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `product_package_uniq_idx` (`product_id`,`product_supplier_id`,`uom_id`,`quantity`),
  KEY `FK615A48F6217F5972` (`created_by_id`),
  KEY `FK615A48F629542386` (`product_supplier_id`),
  KEY `FK615A48F63906C4CF` (`uom_id`),
  KEY `FK615A48F6426DD105` (`updated_by_id`),
  KEY `fk_product_package_product_price` (`product_price_id`),
  CONSTRAINT `FK615A48F6217F5972` FOREIGN KEY (`created_by_id`) REFERENCES `user` (`id`),
  CONSTRAINT `FK615A48F629542386` FOREIGN KEY (`product_supplier_id`) REFERENCES `product_supplier` (`id`),
  CONSTRAINT `FK615A48F63906C4CF` FOREIGN KEY (`uom_id`) REFERENCES `unit_of_measure` (`id`),
  CONSTRAINT `FK615A48F6426DD105` FOREIGN KEY (`updated_by_id`) REFERENCES `user` (`id`),
  CONSTRAINT `FK615A48F6DED5FAE7` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`),
  CONSTRAINT `fk_product_package_product_price` FOREIGN KEY (`product_price_id`) REFERENCES `product_price` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_package`
--

LOCK TABLES `product_package` WRITE;
/*!40000 ALTER TABLE `product_package` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_package` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `product_physical_count_history`
--

DROP TABLE IF EXISTS `product_physical_count_history`;
/*!50001 DROP VIEW IF EXISTS `product_physical_count_history`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `product_physical_count_history` AS SELECT
 NULL AS `inventory_id`,
 NULL AS `product_id`,
 NULL AS `date_counted` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `product_price`
--

DROP TABLE IF EXISTS `product_price`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_price` (
  `id` char(38) NOT NULL,
  `version` bigint(20) NOT NULL,
  `type` varchar(255) NOT NULL,
  `price` decimal(19,4) NOT NULL,
  `currency_id` char(38) DEFAULT NULL,
  `from_date` datetime DEFAULT NULL,
  `to_date` datetime DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `last_updated` datetime DEFAULT NULL,
  `created_by_id` char(38) DEFAULT NULL,
  `updated_by_id` char(38) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_product_price_created_by` (`created_by_id`),
  KEY `fk_product_price_unit_of_measure` (`currency_id`),
  KEY `fk_product_price_updated_by` (`updated_by_id`),
  CONSTRAINT `fk_product_price_created_by` FOREIGN KEY (`created_by_id`) REFERENCES `user` (`id`),
  CONSTRAINT `fk_product_price_unit_of_measure` FOREIGN KEY (`currency_id`) REFERENCES `unit_of_measure` (`id`),
  CONSTRAINT `fk_product_price_updated_by` FOREIGN KEY (`updated_by_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_price`
--

LOCK TABLES `product_price` WRITE;
/*!40000 ALTER TABLE `product_price` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_price` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `product_receipt_history`
--

DROP TABLE IF EXISTS `product_receipt_history`;
/*!50001 DROP VIEW IF EXISTS `product_receipt_history`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `product_receipt_history` AS SELECT
 NULL AS `facility_id`,
 NULL AS `product_id`,
 NULL AS `inventory_item_id`,
 NULL AS `date_received` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `product_snapshot`
--

DROP TABLE IF EXISTS `product_snapshot`;
/*!50001 DROP VIEW IF EXISTS `product_snapshot`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `product_snapshot` AS SELECT
 NULL AS `location_id`,
 NULL AS `product_id`,
 NULL AS `quantity_on_hand` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `product_stocklist`
--

DROP TABLE IF EXISTS `product_stocklist`;
/*!50001 DROP VIEW IF EXISTS `product_stocklist`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `product_stocklist` AS SELECT
 NULL AS `origin_id`,
 NULL AS `product_id`,
 NULL AS `quantity_demand` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `product_stockout`
--

DROP TABLE IF EXISTS `product_stockout`;
/*!50001 DROP VIEW IF EXISTS `product_stockout`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `product_stockout` AS SELECT
 NULL AS `product_id`,
 NULL AS `location_id`,
 NULL AS `stockout_status` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `product_stockout_status`
--

DROP TABLE IF EXISTS `product_stockout_status`;
/*!50001 DROP VIEW IF EXISTS `product_stockout_status`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `product_stockout_status` AS SELECT
 NULL AS `product_id`,
 NULL AS `location_id`,
 NULL AS `stockout_status` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `product_substitution_status`
--

DROP TABLE IF EXISTS `product_substitution_status`;
/*!50001 DROP VIEW IF EXISTS `product_substitution_status`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `product_substitution_status` AS SELECT
 NULL AS `product_id`,
 NULL AS `location_id`,
 NULL AS `substitution_status` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `product_summary`
--

DROP TABLE IF EXISTS `product_summary`;
/*!50001 DROP VIEW IF EXISTS `product_summary`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `product_summary` AS SELECT
 NULL AS `product_id`,
 NULL AS `location_id`,
 NULL AS `quantity_on_hand`,
 NULL AS `quantity_on_order_not_shipped`,
 NULL AS `quantity_on_order_not_received`,
 NULL AS `quantity_on_order` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `product_supplier`
--

DROP TABLE IF EXISTS `product_supplier`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_supplier` (
  `id` char(38) NOT NULL,
  `version` bigint(20) NOT NULL,
  `brand_name` varchar(255) DEFAULT NULL,
  `code` varchar(255) DEFAULT NULL,
  `comments` varchar(255) DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `description` longtext DEFAULT NULL,
  `last_updated` datetime NOT NULL,
  `manufacturer_id` char(38) DEFAULT NULL,
  `manufacturer_code` varchar(255) DEFAULT NULL,
  `manufacturer_name` varchar(255) DEFAULT NULL,
  `min_order_quantity` decimal(19,2) DEFAULT NULL,
  `model_number` varchar(255) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `ndc` varchar(255) DEFAULT NULL,
  `product_id` char(38) NOT NULL,
  `product_code` varchar(255) DEFAULT NULL,
  `rating_type_code` varchar(255) DEFAULT NULL,
  `standard_lead_time_days` decimal(19,2) DEFAULT NULL,
  `supplier_id` char(38) DEFAULT NULL,
  `supplier_code` varchar(255) DEFAULT NULL,
  `supplier_name` varchar(255) DEFAULT NULL,
  `unit_of_measure_id` char(38) DEFAULT NULL,
  `unit_price` decimal(19,4) DEFAULT NULL,
  `upc` varchar(255) DEFAULT NULL,
  `unit_cost` decimal(19,4) DEFAULT NULL,
  `contract_price_id` char(38) DEFAULT NULL,
  `active` bit(1) DEFAULT b'1',
  `default_product_package_id` char(38) DEFAULT NULL,
  `tiered_pricing` bit(1) NOT NULL,
  `created_by_id` char(38) DEFAULT NULL,
  `updated_by_id` char(38) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK3A097B1C24DEBC91` (`unit_of_measure_id`),
  KEY `FK3A097B1C2A475A37` (`manufacturer_id`),
  KEY `FK3A097B1CDED5FAE7` (`product_id`),
  KEY `FK3A097B1CF42F7E5C` (`supplier_id`),
  KEY `fk_product_supplier_product_price` (`contract_price_id`),
  KEY `fk_product_supplier_product_package` (`default_product_package_id`),
  KEY `fk_product_supplier_created_by` (`created_by_id`),
  KEY `fk_product_supplier_updated_by` (`updated_by_id`),
  CONSTRAINT `FK3A097B1C24DEBC91` FOREIGN KEY (`unit_of_measure_id`) REFERENCES `unit_of_measure` (`id`),
  CONSTRAINT `FK3A097B1C2A475A37` FOREIGN KEY (`manufacturer_id`) REFERENCES `party` (`id`),
  CONSTRAINT `FK3A097B1CDED5FAE7` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`),
  CONSTRAINT `FK3A097B1CF42F7E5C` FOREIGN KEY (`supplier_id`) REFERENCES `party` (`id`),
  CONSTRAINT `fk_product_supplier_created_by` FOREIGN KEY (`created_by_id`) REFERENCES `user` (`id`),
  CONSTRAINT `fk_product_supplier_product_package` FOREIGN KEY (`default_product_package_id`) REFERENCES `product_package` (`id`),
  CONSTRAINT `fk_product_supplier_product_price` FOREIGN KEY (`contract_price_id`) REFERENCES `product_price` (`id`),
  CONSTRAINT `fk_product_supplier_updated_by` FOREIGN KEY (`updated_by_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_supplier`
--

LOCK TABLES `product_supplier` WRITE;
/*!40000 ALTER TABLE `product_supplier` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_supplier` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `product_supplier_clean`
--

DROP TABLE IF EXISTS `product_supplier_clean`;
/*!50001 DROP VIEW IF EXISTS `product_supplier_clean`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `product_supplier_clean` AS SELECT
 NULL AS `id`,
 NULL AS `code`,
 NULL AS `name`,
 NULL AS `product_id`,
 NULL AS `supplier_id`,
 NULL AS `manufacturer_id`,
 NULL AS `supplier_code`,
 NULL AS `manufacturer_code` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `product_supplier_preference`
--

DROP TABLE IF EXISTS `product_supplier_preference`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_supplier_preference` (
  `id` char(38) NOT NULL,
  `product_supplier_id` char(38) DEFAULT NULL,
  `destination_party_id` char(38) DEFAULT NULL,
  `preference_type_id` char(38) DEFAULT NULL,
  `comments` varchar(255) DEFAULT NULL,
  `validity_start_date` datetime DEFAULT NULL,
  `validity_end_date` datetime DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `last_updated` datetime DEFAULT NULL,
  `created_by_id` char(38) DEFAULT NULL,
  `updated_by_id` char(38) DEFAULT NULL,
  `version` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_product_supplier_preference_created_by` (`created_by_id`),
  KEY `fk_product_supplier_preference_destination_party` (`destination_party_id`),
  KEY `fk_product_supplier_preference_preference_type` (`preference_type_id`),
  KEY `fk_product_supplier_preference_product_supplier` (`product_supplier_id`),
  KEY `fk_product_supplier_preference_updated_by` (`updated_by_id`),
  CONSTRAINT `fk_product_supplier_preference_created_by` FOREIGN KEY (`created_by_id`) REFERENCES `user` (`id`),
  CONSTRAINT `fk_product_supplier_preference_destination_party` FOREIGN KEY (`destination_party_id`) REFERENCES `party` (`id`),
  CONSTRAINT `fk_product_supplier_preference_preference_type` FOREIGN KEY (`preference_type_id`) REFERENCES `preference_type` (`id`),
  CONSTRAINT `fk_product_supplier_preference_product_supplier` FOREIGN KEY (`product_supplier_id`) REFERENCES `product_supplier` (`id`),
  CONSTRAINT `fk_product_supplier_preference_updated_by` FOREIGN KEY (`updated_by_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_supplier_preference`
--

LOCK TABLES `product_supplier_preference` WRITE;
/*!40000 ALTER TABLE `product_supplier_preference` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_supplier_preference` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_tag`
--

DROP TABLE IF EXISTS `product_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_tag` (
  `product_id` char(38) NOT NULL,
  `tag_id` char(38) DEFAULT NULL,
  KEY `FKA71CAC4A9740C85F` (`tag_id`),
  KEY `FKA71CAC4ADED5FAE7` (`product_id`),
  CONSTRAINT `FKA71CAC4A9740C85F` FOREIGN KEY (`tag_id`) REFERENCES `tag` (`id`),
  CONSTRAINT `FKA71CAC4ADED5FAE7` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_tag`
--

LOCK TABLES `product_tag` WRITE;
/*!40000 ALTER TABLE `product_tag` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_tag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_type`
--

DROP TABLE IF EXISTS `product_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_type` (
  `id` char(38) NOT NULL,
  `version` bigint(20) NOT NULL,
  `date_created` datetime NOT NULL,
  `last_updated` datetime NOT NULL,
  `name` varchar(255) NOT NULL,
  `product_type_code` varchar(255) NOT NULL,
  `product_identifier_format` varchar(255) DEFAULT NULL,
  `code` varchar(255) DEFAULT NULL,
  `sequence_number` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_type`
--

LOCK TABLES `product_type` WRITE;
/*!40000 ALTER TABLE `product_type` DISABLE KEYS */;
INSERT INTO `product_type` VALUES
('DEFAULT',0,'2023-08-14 15:08:23','2023-08-14 15:08:23','Default','GOOD','','',0);
/*!40000 ALTER TABLE `product_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_type_displayed_fields`
--

DROP TABLE IF EXISTS `product_type_displayed_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_type_displayed_fields` (
  `product_type_id` char(38) DEFAULT NULL,
  `product_field` varchar(255) DEFAULT NULL,
  KEY `fk_product_type_displayed_fields_product_type` (`product_type_id`),
  CONSTRAINT `fk_product_type_displayed_fields_product_type` FOREIGN KEY (`product_type_id`) REFERENCES `product_type` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_type_displayed_fields`
--

LOCK TABLES `product_type_displayed_fields` WRITE;
/*!40000 ALTER TABLE `product_type_displayed_fields` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_type_displayed_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_type_required_fields`
--

DROP TABLE IF EXISTS `product_type_required_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_type_required_fields` (
  `product_type_id` char(38) DEFAULT NULL,
  `product_field` varchar(255) DEFAULT NULL,
  KEY `fk_product_type_required_fields_product_type` (`product_type_id`),
  CONSTRAINT `fk_product_type_required_fields_product_type` FOREIGN KEY (`product_type_id`) REFERENCES `product_type` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_type_required_fields`
--

LOCK TABLES `product_type_required_fields` WRITE;
/*!40000 ALTER TABLE `product_type_required_fields` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_type_required_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_type_supported_activities`
--

DROP TABLE IF EXISTS `product_type_supported_activities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_type_supported_activities` (
  `product_type_id` char(38) DEFAULT NULL,
  `product_activity_code` varchar(255) DEFAULT NULL,
  KEY `fk_product_type_supported_activities_product_type` (`product_type_id`),
  CONSTRAINT `fk_product_type_supported_activities_product_type` FOREIGN KEY (`product_type_id`) REFERENCES `product_type` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_type_supported_activities`
--

LOCK TABLES `product_type_supported_activities` WRITE;
/*!40000 ALTER TABLE `product_type_supported_activities` DISABLE KEYS */;
INSERT INTO `product_type_supported_activities` VALUES
('DEFAULT','SEARCHABLE_NO_STOCK');
/*!40000 ALTER TABLE `product_type_supported_activities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `receipt`
--

DROP TABLE IF EXISTS `receipt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `receipt` (
  `id` char(38) NOT NULL,
  `version` bigint(20) NOT NULL,
  `actual_delivery_date` datetime DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `expected_delivery_date` datetime DEFAULT NULL,
  `last_updated` datetime NOT NULL,
  `recipient_id` char(38) DEFAULT NULL,
  `shipment_id` char(38) DEFAULT NULL,
  `receipt_number` varchar(255) DEFAULT NULL,
  `receipt_status_code` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK408272383B5F6286` (`shipment_id`),
  KEY `FK4082723844979D51` (`recipient_id`),
  CONSTRAINT `FK408272383B5F6286` FOREIGN KEY (`shipment_id`) REFERENCES `shipment` (`id`),
  CONSTRAINT `FK4082723844979D51` FOREIGN KEY (`recipient_id`) REFERENCES `person` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `receipt`
--

LOCK TABLES `receipt` WRITE;
/*!40000 ALTER TABLE `receipt` DISABLE KEYS */;
/*!40000 ALTER TABLE `receipt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `receipt_item`
--

DROP TABLE IF EXISTS `receipt_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `receipt_item` (
  `id` char(38) NOT NULL,
  `version` bigint(20) NOT NULL,
  `comment_id` char(38) DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `expiration_date` datetime DEFAULT NULL,
  `last_updated` datetime NOT NULL,
  `lot_number` varchar(255) DEFAULT NULL,
  `product_id` char(38) DEFAULT NULL,
  `quantity_shipped` int(11) DEFAULT NULL,
  `quantity_received` int(11) DEFAULT NULL,
  `receipt_id` char(38) DEFAULT NULL,
  `recipient_id` char(38) DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `shipment_item_id` char(38) DEFAULT NULL,
  `inventory_item_id` char(38) DEFAULT NULL,
  `bin_location_id` char(38) DEFAULT NULL,
  `quantity_canceled` int(11) DEFAULT NULL,
  `is_split_item` bit(1) DEFAULT NULL,
  `sort_order` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKAE3064BA44979D51` (`recipient_id`),
  KEY `FKAE3064BA69DB749D` (`bin_location_id`),
  KEY `FKAE3064BAAA992CED` (`inventory_item_id`),
  KEY `FKAE3064BAB06EC4FB` (`shipment_item_id`),
  KEY `FKAE3064BADED5FAE7` (`product_id`),
  KEY `FKAE3064BAF7076438` (`receipt_id`),
  CONSTRAINT `FKAE3064BA44979D51` FOREIGN KEY (`recipient_id`) REFERENCES `person` (`id`),
  CONSTRAINT `FKAE3064BA69DB749D` FOREIGN KEY (`bin_location_id`) REFERENCES `location` (`id`),
  CONSTRAINT `FKAE3064BAAA992CED` FOREIGN KEY (`inventory_item_id`) REFERENCES `inventory_item` (`id`),
  CONSTRAINT `FKAE3064BAB06EC4FB` FOREIGN KEY (`shipment_item_id`) REFERENCES `shipment_item` (`id`),
  CONSTRAINT `FKAE3064BADED5FAE7` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`),
  CONSTRAINT `FKAE3064BAF7076438` FOREIGN KEY (`receipt_id`) REFERENCES `receipt` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `receipt_item`
--

LOCK TABLES `receipt_item` WRITE;
/*!40000 ALTER TABLE `receipt_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `receipt_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reference_number`
--

DROP TABLE IF EXISTS `reference_number`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `reference_number` (
  `id` char(38) NOT NULL,
  `version` bigint(20) NOT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `reference_number_type_id` char(38) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKD790DEBD154F600` (`reference_number_type_id`),
  CONSTRAINT `FKD790DEBD154F600` FOREIGN KEY (`reference_number_type_id`) REFERENCES `reference_number_type` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reference_number`
--

LOCK TABLES `reference_number` WRITE;
/*!40000 ALTER TABLE `reference_number` DISABLE KEYS */;
/*!40000 ALTER TABLE `reference_number` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reference_number_type`
--

DROP TABLE IF EXISTS `reference_number_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `reference_number_type` (
  `id` char(38) NOT NULL,
  `version` bigint(20) NOT NULL,
  `date_created` datetime NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `last_updated` datetime NOT NULL,
  `name` varchar(255) NOT NULL,
  `sort_order` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reference_number_type`
--

LOCK TABLES `reference_number_type` WRITE;
/*!40000 ALTER TABLE `reference_number_type` DISABLE KEYS */;
INSERT INTO `reference_number_type` VALUES
('1',0,'2010-08-25 00:00:00','Purchase Order Number','2010-08-25 00:00:00','Purchase Order Number',0),
('10',0,'2018-09-10 00:00:00','Tracking Number','2018-09-10 00:00:00','Tracking Number',0),
('2',0,'2010-08-25 00:00:00','Customer name','2010-08-25 00:00:00','Customer name',0),
('3',0,'2010-08-25 00:00:00','Internal Identifier','2010-08-25 00:00:00','Internal Identifier',0),
('4',0,'2010-08-25 00:00:00','Bill of Lading Number','2010-08-25 00:00:00','Bill of Lading Number',0),
('5',0,'2011-03-01 00:00:00','Air Waybill Number','2011-03-01 00:00:00','Air Waybill Number',0),
('6',0,'2011-03-01 00:00:00','Container Number','2011-03-01 00:00:00','Container Number',0),
('7',0,'2011-03-01 00:00:00','Seal Number','2011-03-01 00:00:00','Seal Number',0),
('8',0,'2011-03-01 00:00:00','Flight Number','2011-03-01 00:00:00','Flight Number',0),
('9',0,'2012-01-26 00:00:00','License Plate Number','2012-01-26 00:00:00','License Plate Number',0),
('VENDOR_INVOICE_NUMBER',0,'2021-03-16 00:00:00','Invoice reference number generated by vendor','2021-03-16 00:00:00','Vendor Invoice Number',0);
/*!40000 ALTER TABLE `reference_number_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `requirement`
--

DROP TABLE IF EXISTS `requirement`;
/*!50001 DROP VIEW IF EXISTS `requirement`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `requirement` AS SELECT
 NULL AS `id`,
 NULL AS `product_id`,
 NULL AS `location_id`,
 NULL AS `bin_location_id`,
 NULL AS `quantity_in_bin`,
 NULL AS `min_quantity`,
 NULL AS `max_quantity`,
 NULL AS `reorder_quantity`,
 NULL AS `total_quantity_available_to_promise`,
 NULL AS `quantity_available`,
 NULL AS `status` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `requisition`
--

DROP TABLE IF EXISTS `requisition`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `requisition` (
  `id` char(38) NOT NULL,
  `version` bigint(20) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `date_requested` datetime NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `destination_id` char(38) DEFAULT NULL,
  `last_updated` datetime DEFAULT NULL,
  `origin_id` char(38) DEFAULT NULL,
  `recipient_id` char(38) DEFAULT NULL,
  `request_number` varchar(255) DEFAULT NULL,
  `requested_by_id` char(38) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `fulfillment_id` char(38) DEFAULT NULL,
  `created_by_id` char(38) DEFAULT NULL,
  `updated_by_id` char(38) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date_valid_from` datetime DEFAULT NULL,
  `date_valid_to` datetime DEFAULT NULL,
  `recipient_program` varchar(255) DEFAULT NULL,
  `requested_delivery_date` datetime NOT NULL,
  `type` varchar(255) DEFAULT NULL,
  `commodity_class` varchar(255) DEFAULT NULL,
  `is_template` tinyint(3) DEFAULT NULL,
  `is_published` tinyint(3) DEFAULT NULL,
  `date_published` datetime DEFAULT NULL,
  `verified_by_id` char(38) DEFAULT NULL,
  `date_verified` datetime DEFAULT NULL,
  `reviewed_by_id` char(38) DEFAULT NULL,
  `date_reviewed` datetime DEFAULT NULL,
  `delivered_by_id` char(38) DEFAULT NULL,
  `date_delivered` datetime DEFAULT NULL,
  `received_by_id` char(38) DEFAULT NULL,
  `date_received` datetime DEFAULT NULL,
  `checked_by_id` char(38) DEFAULT NULL,
  `date_checked` datetime DEFAULT NULL,
  `issued_by_id` char(38) DEFAULT NULL,
  `date_issued` datetime DEFAULT NULL,
  `requisition_template_id` char(38) DEFAULT NULL,
  `replenishment_period` int(11) DEFAULT NULL,
  `sort_by_code` varchar(255) DEFAULT NULL,
  `source_type` varchar(255) DEFAULT NULL,
  `replenishment_type_code` varchar(255) DEFAULT NULL,
  `approved_by_id` char(38) DEFAULT NULL,
  `date_approved` datetime DEFAULT NULL,
  `date_rejected` datetime DEFAULT NULL,
  `approval_required` bit(1) DEFAULT NULL,
  `rejected_by_id` char(38) DEFAULT NULL,
  `date_delivery_requested` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK1799509C20E33E1C` (`verified_by_id`),
  KEY `FK1799509C217F5972` (`created_by_id`),
  KEY `FK1799509C2BDD17B3` (`requisition_template_id`),
  KEY `FK1799509C36C69275` (`received_by_id`),
  KEY `FK1799509C426DD105` (`updated_by_id`),
  KEY `FK1799509C4CF042D8` (`delivered_by_id`),
  KEY `FK1799509CD196DBBF` (`issued_by_id`),
  KEY `FK1799509CD2CB8BBB` (`checked_by_id`),
  KEY `FK1799509CDFA74E0B` (`reviewed_by_id`),
  KEY `FK414EF28F1E2B3CDC` (`destination_id`),
  KEY `FK414EF28F44979D51` (`recipient_id`),
  KEY `FK414EF28F94567276` (`fulfillment_id`),
  KEY `FK414EF28FDBDEDAC4` (`origin_id`),
  KEY `FK414EF28FDD302242` (`requested_by_id`),
  KEY `fk_requisition_approved_by` (`approved_by_id`),
  KEY `fk_requisition_rejected_by` (`rejected_by_id`),
  CONSTRAINT `FK1799509C20E33E1C` FOREIGN KEY (`verified_by_id`) REFERENCES `person` (`id`),
  CONSTRAINT `FK1799509C217F5972` FOREIGN KEY (`created_by_id`) REFERENCES `user` (`id`),
  CONSTRAINT `FK1799509C2BDD17B3` FOREIGN KEY (`requisition_template_id`) REFERENCES `requisition` (`id`),
  CONSTRAINT `FK1799509C36C69275` FOREIGN KEY (`received_by_id`) REFERENCES `person` (`id`),
  CONSTRAINT `FK1799509C426DD105` FOREIGN KEY (`updated_by_id`) REFERENCES `user` (`id`),
  CONSTRAINT `FK1799509C4CF042D8` FOREIGN KEY (`delivered_by_id`) REFERENCES `person` (`id`),
  CONSTRAINT `FK1799509CD196DBBF` FOREIGN KEY (`issued_by_id`) REFERENCES `person` (`id`),
  CONSTRAINT `FK1799509CD2CB8BBB` FOREIGN KEY (`checked_by_id`) REFERENCES `person` (`id`),
  CONSTRAINT `FK1799509CDFA74E0B` FOREIGN KEY (`reviewed_by_id`) REFERENCES `person` (`id`),
  CONSTRAINT `FK414EF28F1E2B3CDC` FOREIGN KEY (`destination_id`) REFERENCES `location` (`id`),
  CONSTRAINT `FK414EF28F44979D51` FOREIGN KEY (`recipient_id`) REFERENCES `person` (`id`),
  CONSTRAINT `FK414EF28F94567276` FOREIGN KEY (`fulfillment_id`) REFERENCES `fulfillment` (`id`),
  CONSTRAINT `FK414EF28FDBDEDAC4` FOREIGN KEY (`origin_id`) REFERENCES `location` (`id`),
  CONSTRAINT `FK414EF28FDD302242` FOREIGN KEY (`requested_by_id`) REFERENCES `person` (`id`),
  CONSTRAINT `fk_requisition_approved_by` FOREIGN KEY (`approved_by_id`) REFERENCES `person` (`id`),
  CONSTRAINT `fk_requisition_rejected_by` FOREIGN KEY (`rejected_by_id`) REFERENCES `person` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `requisition`
--

LOCK TABLES `requisition` WRITE;
/*!40000 ALTER TABLE `requisition` DISABLE KEYS */;
/*!40000 ALTER TABLE `requisition` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `requisition_approvers`
--

DROP TABLE IF EXISTS `requisition_approvers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `requisition_approvers` (
  `requisition_id` char(38) DEFAULT NULL,
  `person_id` char(38) DEFAULT NULL,
  KEY `fk_requisition_approvers_person` (`person_id`),
  KEY `fk_requisition_approvers_requisition` (`requisition_id`),
  CONSTRAINT `fk_requisition_approvers_person` FOREIGN KEY (`person_id`) REFERENCES `person` (`id`),
  CONSTRAINT `fk_requisition_approvers_requisition` FOREIGN KEY (`requisition_id`) REFERENCES `requisition` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `requisition_approvers`
--

LOCK TABLES `requisition_approvers` WRITE;
/*!40000 ALTER TABLE `requisition_approvers` DISABLE KEYS */;
/*!40000 ALTER TABLE `requisition_approvers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `requisition_comment`
--

DROP TABLE IF EXISTS `requisition_comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `requisition_comment` (
  `requisition_id` char(38) DEFAULT NULL,
  `comment_id` char(38) DEFAULT NULL,
  KEY `fk_requisition_comment_comment` (`comment_id`),
  KEY `fk_requisition_comment_requisition` (`requisition_id`),
  CONSTRAINT `fk_requisition_comment_comment` FOREIGN KEY (`comment_id`) REFERENCES `comment` (`id`),
  CONSTRAINT `fk_requisition_comment_requisition` FOREIGN KEY (`requisition_id`) REFERENCES `requisition` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `requisition_comment`
--

LOCK TABLES `requisition_comment` WRITE;
/*!40000 ALTER TABLE `requisition_comment` DISABLE KEYS */;
/*!40000 ALTER TABLE `requisition_comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `requisition_event`
--

DROP TABLE IF EXISTS `requisition_event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `requisition_event` (
  `requisition_id` char(38) DEFAULT NULL,
  `event_id` char(38) DEFAULT NULL,
  KEY `fk_requisition_event_event` (`event_id`),
  KEY `fk_requisition_event_requisition` (`requisition_id`),
  CONSTRAINT `fk_requisition_event_event` FOREIGN KEY (`event_id`) REFERENCES `event` (`id`),
  CONSTRAINT `fk_requisition_event_requisition` FOREIGN KEY (`requisition_id`) REFERENCES `requisition` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `requisition_event`
--

LOCK TABLES `requisition_event` WRITE;
/*!40000 ALTER TABLE `requisition_event` DISABLE KEYS */;
/*!40000 ALTER TABLE `requisition_event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `requisition_item`
--

DROP TABLE IF EXISTS `requisition_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `requisition_item` (
  `id` char(38) NOT NULL,
  `version` bigint(20) NOT NULL,
  `category_id` char(38) DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `inventory_item_id` char(38) DEFAULT NULL,
  `last_updated` datetime NOT NULL,
  `product_id` char(38) NOT NULL,
  `quantity` int(11) NOT NULL,
  `requisition_id` char(38) DEFAULT NULL,
  `requested_by_id` char(38) DEFAULT NULL,
  `unit_price` float DEFAULT NULL,
  `product_group_id` char(38) DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `recipient_id` char(38) DEFAULT NULL,
  `substitutable` bit(1) NOT NULL,
  `order_index` int(11) DEFAULT NULL,
  `requisition_items_idx` int(11) DEFAULT NULL,
  `quantity_canceled` int(11) DEFAULT NULL,
  `cancel_reason_code` varchar(255) DEFAULT NULL,
  `cancel_comments` varchar(255) DEFAULT NULL,
  `parent_requisition_item_id` char(38) DEFAULT NULL,
  `product_package_id` char(38) DEFAULT NULL,
  `requisition_item_type` varchar(255) DEFAULT NULL,
  `quantity_approved` int(11) DEFAULT NULL,
  `created_by_id` char(38) DEFAULT NULL,
  `updated_by_id` char(38) DEFAULT NULL,
  `substitution_item_id` char(38) DEFAULT NULL,
  `modification_item_id` char(38) DEFAULT NULL,
  `pallet_name` varchar(255) DEFAULT NULL,
  `box_name` varchar(255) DEFAULT NULL,
  `lot_number` varchar(255) DEFAULT NULL,
  `expiration_date` datetime DEFAULT NULL,
  `pick_reason_code` varchar(255) DEFAULT NULL,
  `quantity_counted` int(11) DEFAULT NULL,
  `auto_allocated` bit(1) DEFAULT b'1',
  PRIMARY KEY (`id`),
  KEY `FK4DA982C35DE21C87` (`requisition_id`),
  KEY `FK4DA982C3AA992CED` (`inventory_item_id`),
  KEY `FK4DA982C3DED5FAE7` (`product_id`),
  KEY `FK4DA982C3EF4C770D` (`category_id`),
  KEY `FK5358E4D614F7BB8E` (`product_group_id`),
  KEY `FK5358E4D61594028E` (`substitution_item_id`),
  KEY `FK5358E4D6217F5972` (`created_by_id`),
  KEY `FK5358E4D629B2552E` (`product_package_id`),
  KEY `FK5358E4D6405AC22D` (`modification_item_id`),
  KEY `FK5358E4D6426DD105` (`updated_by_id`),
  KEY `FK5358E4D644979D51` (`recipient_id`),
  KEY `FK5358E4D6DD302242` (`requested_by_id`),
  KEY `FK5358E4D6F84BDE18` (`parent_requisition_item_id`),
  CONSTRAINT `FK4DA982C35DE21C87` FOREIGN KEY (`requisition_id`) REFERENCES `requisition` (`id`),
  CONSTRAINT `FK4DA982C3911E7578` FOREIGN KEY (`requested_by_id`) REFERENCES `user` (`id`),
  CONSTRAINT `FK4DA982C3AA992CED` FOREIGN KEY (`inventory_item_id`) REFERENCES `inventory_item` (`id`),
  CONSTRAINT `FK4DA982C3DED5FAE7` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`),
  CONSTRAINT `FK4DA982C3EF4C770D` FOREIGN KEY (`category_id`) REFERENCES `category` (`id`),
  CONSTRAINT `FK5358E4D614F7BB8E` FOREIGN KEY (`product_group_id`) REFERENCES `product_group` (`id`),
  CONSTRAINT `FK5358E4D61594028E` FOREIGN KEY (`substitution_item_id`) REFERENCES `requisition_item` (`id`),
  CONSTRAINT `FK5358E4D6217F5972` FOREIGN KEY (`created_by_id`) REFERENCES `user` (`id`),
  CONSTRAINT `FK5358E4D629B2552E` FOREIGN KEY (`product_package_id`) REFERENCES `product_package` (`id`),
  CONSTRAINT `FK5358E4D6405AC22D` FOREIGN KEY (`modification_item_id`) REFERENCES `requisition_item` (`id`),
  CONSTRAINT `FK5358E4D6426DD105` FOREIGN KEY (`updated_by_id`) REFERENCES `user` (`id`),
  CONSTRAINT `FK5358E4D644979D51` FOREIGN KEY (`recipient_id`) REFERENCES `person` (`id`),
  CONSTRAINT `FK5358E4D6DD302242` FOREIGN KEY (`requested_by_id`) REFERENCES `person` (`id`),
  CONSTRAINT `FK5358E4D6F84BDE18` FOREIGN KEY (`parent_requisition_item_id`) REFERENCES `requisition_item` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `requisition_item`
--

LOCK TABLES `requisition_item` WRITE;
/*!40000 ALTER TABLE `requisition_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `requisition_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role`
--

DROP TABLE IF EXISTS `role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `role` (
  `id` char(38) NOT NULL,
  `version` bigint(20) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `role_type` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role`
--

LOCK TABLES `role` WRITE;
/*!40000 ALTER TABLE `role` DISABLE KEYS */;
INSERT INTO `role` VALUES
('1',0,NULL,'ROLE_ADMIN','Admin'),
('2',0,NULL,'ROLE_MANAGER','Manager'),
('3',0,NULL,'ROLE_BROWSER','Browser'),
('4',0,NULL,'ROLE_ASSISTANT','Assistant'),
('5',0,NULL,'ROLE_SUPERUSER','Superuser'),
('ff80818162d9f9cc0162d9fbbeb40001',0,'Role that represents users who should receive notifications about users.','ROLE_USER_NOTIFICATION','User Notifications'),
('ff80818162d9f9cc0162d9fbf09e0002',0,'Role that represents users who should receive notifications about products.','ROLE_PRODUCT_NOTIFICATION','Product Notifications'),
('ff80818162d9f9cc0162d9fc1c220003',0,'Role that represents users who should receive notifications about shipments.','ROLE_SHIPMENT_NOTIFICATION','All Shipment Notifications'),
('ff80818162d9f9cc0162d9fc48990004',0,'Role that represents users who should receive notifications about errors.','ROLE_ERROR_NOTIFICATION','Error Notification'),
('ff80818162d9f9cc0162d9fc74fa0005',0,'Role that represents users who should receive notifications about feedback.','ROLE_FEEDBACK_NOTIFICATION','Feedback Notifications'),
('ff80818162debf330162dec0548e0001',0,'Role that represents users who should receive notifications about orders.','ROLE_ORDER_NOTIFICATION','Order Notifications'),
('ff808181681c757c01681c89c4960001',0,'Allow user to view and modify financial information','ROLE_FINANCE','Finance'),
('ff808181681c757c01681c89c4960002',0,'Allow user to view and modify invoice information','ROLE_INVOICE','Invoice'),
('ff8081816cdefc9d016cdf09a9ee0001',0,'Role that represents users who should receive notifications about orders.','ROLE_ITEM_ALL_NOTIFICATION','All Stock Notifications'),
('ff8081816cfeeaf0016cff174ca70001',0,'Role that represents users who should receive notifications about expiring/expired items.','ROLE_ITEM_EXPIRY_NOTIFICATION','Expiry Notifications'),
('ff8081816cfeeaf0016cff18057e0002',0,'Role that represents users who should receive notifications about overstocked items.','ROLE_ITEM_OVERSTOCK_NOTIFICATION','Overstock Notifications'),
('ff8081816cfeeaf0016cff1834080003',0,'Role that represents users who should receive notifications about reorder items.','ROLE_ITEM_REORDER_NOTIFICATION','Reorder Notifications'),
('ff8081816cfeeaf0016cff18617d0004',0,'Role that represents users who should receive notifications about low stock items.','ROLE_ITEM_LOW_STOCK_NOTIFICATION','Low Stock Notifications'),
('ff8081816cfeeaf0016cff1b6e780005',0,'Role that represents users who should receive notifications about stockouts.','ROLE_ITEM_OUT_OF_STOCK_NOTIFICATION','Out of Stock Notifications'),
('ROLE_PRODUCT_MANAGER',0,'Role that represents users who have the permission to manage products','ROLE_PRODUCT_MANAGER','Product Manager'),
('ROLE_PURCHASE_APPROVER',0,NULL,'ROLE_PURCHASE_APPROVER','Purchase approver'),
('ROLE_REQUISITION_APPROVER',0,NULL,'ROLE_REQUISITION_APPROVER','Request approver');
/*!40000 ALTER TABLE `role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shipment`
--

DROP TABLE IF EXISTS `shipment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `shipment` (
  `id` char(38) NOT NULL,
  `version` bigint(20) NOT NULL,
  `carrier_id` char(38) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `destination_id` char(38) DEFAULT NULL,
  `donor_id` char(38) DEFAULT NULL,
  `expected_delivery_date` datetime DEFAULT NULL,
  `expected_shipping_date` datetime DEFAULT NULL,
  `last_updated` datetime DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `origin_id` char(38) DEFAULT NULL,
  `recipient_id` char(38) DEFAULT NULL,
  `shipment_method_id` char(38) DEFAULT NULL,
  `shipment_number` varchar(255) DEFAULT NULL,
  `shipment_type_id` char(38) DEFAULT NULL,
  `total_value` float(12,2) DEFAULT NULL,
  `additional_information` longtext DEFAULT NULL,
  `stated_value` float(12,2) DEFAULT NULL,
  `weight` float DEFAULT NULL,
  `weight_units` varchar(255) DEFAULT NULL,
  `current_status` varchar(255) DEFAULT NULL,
  `current_event_id` char(38) DEFAULT NULL,
  `created_by_id` char(38) DEFAULT NULL,
  `updated_by_id` char(38) DEFAULT NULL,
  `requisition_id` char(38) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `driver_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKE139719A1E2B3CDC` (`destination_id`),
  KEY `FKE139719A217F5972` (`created_by_id`),
  KEY `FKE139719A294C1012` (`carrier_id`),
  KEY `FKE139719A426DD105` (`updated_by_id`),
  KEY `FKE139719A44979D51` (`recipient_id`),
  KEY `FKE139719A49AB6B52` (`donor_id`),
  KEY `FKE139719A5DE9E374` (`requisition_id`),
  KEY `FKE139719AA28CC5FB` (`shipment_method_id`),
  KEY `FKE139719AD95ACF25` (`current_event_id`),
  KEY `FKE139719ADBDEDAC4` (`origin_id`),
  KEY `FKE139719AFF77FF9B` (`shipment_type_id`),
  CONSTRAINT `FKE139719A1E2B3CDC` FOREIGN KEY (`destination_id`) REFERENCES `location` (`id`),
  CONSTRAINT `FKE139719A217F5972` FOREIGN KEY (`created_by_id`) REFERENCES `user` (`id`),
  CONSTRAINT `FKE139719A294C1012` FOREIGN KEY (`carrier_id`) REFERENCES `person` (`id`),
  CONSTRAINT `FKE139719A426DD105` FOREIGN KEY (`updated_by_id`) REFERENCES `user` (`id`),
  CONSTRAINT `FKE139719A44979D51` FOREIGN KEY (`recipient_id`) REFERENCES `person` (`id`),
  CONSTRAINT `FKE139719A49AB6B52` FOREIGN KEY (`donor_id`) REFERENCES `donor` (`id`),
  CONSTRAINT `FKE139719A5DE9E374` FOREIGN KEY (`requisition_id`) REFERENCES `requisition` (`id`),
  CONSTRAINT `FKE139719AA28CC5FB` FOREIGN KEY (`shipment_method_id`) REFERENCES `shipment_method` (`id`),
  CONSTRAINT `FKE139719AD95ACF25` FOREIGN KEY (`current_event_id`) REFERENCES `event` (`id`),
  CONSTRAINT `FKE139719ADBDEDAC4` FOREIGN KEY (`origin_id`) REFERENCES `location` (`id`),
  CONSTRAINT `FKE139719AFF77FF9B` FOREIGN KEY (`shipment_type_id`) REFERENCES `shipment_type` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shipment`
--

LOCK TABLES `shipment` WRITE;
/*!40000 ALTER TABLE `shipment` DISABLE KEYS */;
/*!40000 ALTER TABLE `shipment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shipment_comment`
--

DROP TABLE IF EXISTS `shipment_comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `shipment_comment` (
  `shipment_comments_id` char(38) DEFAULT NULL,
  `comment_id` char(38) DEFAULT NULL,
  `comments_idx` int(11) DEFAULT NULL,
  KEY `FKC398CCBAC4A49BBF` (`comment_id`),
  CONSTRAINT `FKC398CCBAC4A49BBF` FOREIGN KEY (`comment_id`) REFERENCES `comment` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shipment_comment`
--

LOCK TABLES `shipment_comment` WRITE;
/*!40000 ALTER TABLE `shipment_comment` DISABLE KEYS */;
/*!40000 ALTER TABLE `shipment_comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shipment_document`
--

DROP TABLE IF EXISTS `shipment_document`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `shipment_document` (
  `shipment_documents_id` char(38) DEFAULT NULL,
  `document_id` char(38) DEFAULT NULL,
  `documents_idx` int(11) DEFAULT NULL,
  KEY `FK6C5BE20C800AA15` (`document_id`),
  CONSTRAINT `FK6C5BE20C800AA15` FOREIGN KEY (`document_id`) REFERENCES `document` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shipment_document`
--

LOCK TABLES `shipment_document` WRITE;
/*!40000 ALTER TABLE `shipment_document` DISABLE KEYS */;
/*!40000 ALTER TABLE `shipment_document` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shipment_event`
--

DROP TABLE IF EXISTS `shipment_event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `shipment_event` (
  `shipment_events_id` char(38) DEFAULT NULL,
  `event_id` char(38) DEFAULT NULL,
  KEY `FK6D032BB53B350242` (`shipment_events_id`),
  KEY `FK6D032BB5786431F` (`event_id`),
  CONSTRAINT `FK6D032BB53B350242` FOREIGN KEY (`shipment_events_id`) REFERENCES `shipment` (`id`),
  CONSTRAINT `FK6D032BB5786431F` FOREIGN KEY (`event_id`) REFERENCES `event` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shipment_event`
--

LOCK TABLES `shipment_event` WRITE;
/*!40000 ALTER TABLE `shipment_event` DISABLE KEYS */;
/*!40000 ALTER TABLE `shipment_event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shipment_event_log`
--

DROP TABLE IF EXISTS `shipment_event_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `shipment_event_log` (
  `shipment_id` char(38) NOT NULL,
  `event_log_id` char(38) NOT NULL,
  KEY `fk_shipment_event_log_shipment` (`shipment_id`),
  KEY `fk_shipment_event_log_event_log` (`event_log_id`),
  CONSTRAINT `fk_shipment_event_log_event_log` FOREIGN KEY (`event_log_id`) REFERENCES `event_log` (`id`),
  CONSTRAINT `fk_shipment_event_log_shipment` FOREIGN KEY (`shipment_id`) REFERENCES `shipment` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shipment_event_log`
--

LOCK TABLES `shipment_event_log` WRITE;
/*!40000 ALTER TABLE `shipment_event_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `shipment_event_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shipment_invoice`
--

DROP TABLE IF EXISTS `shipment_invoice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `shipment_invoice` (
  `invoice_item_id` char(38) DEFAULT NULL,
  `shipment_item_id` char(38) DEFAULT NULL,
  KEY `shipment_invoice_ibfk_1` (`shipment_item_id`),
  KEY `shipment_invoice_ibfk_2` (`invoice_item_id`),
  CONSTRAINT `shipment_invoice_ibfk_1` FOREIGN KEY (`shipment_item_id`) REFERENCES `shipment_item` (`id`),
  CONSTRAINT `shipment_invoice_ibfk_2` FOREIGN KEY (`invoice_item_id`) REFERENCES `invoice_item` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shipment_invoice`
--

LOCK TABLES `shipment_invoice` WRITE;
/*!40000 ALTER TABLE `shipment_invoice` DISABLE KEYS */;
/*!40000 ALTER TABLE `shipment_invoice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shipment_item`
--

DROP TABLE IF EXISTS `shipment_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `shipment_item` (
  `id` char(38) NOT NULL,
  `version` bigint(20) NOT NULL,
  `container_id` char(38) DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `donor_id` char(38) DEFAULT NULL,
  `last_updated` datetime NOT NULL,
  `lot_number` varchar(255) DEFAULT NULL,
  `product_id` char(38) DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `recipient_id` char(38) DEFAULT NULL,
  `shipment_items_idx` int(11) DEFAULT NULL,
  `shipment_id` char(38) DEFAULT NULL,
  `expiration_date` datetime DEFAULT NULL,
  `inventory_item_id` char(38) DEFAULT NULL,
  `bin_location_id` char(38) DEFAULT NULL,
  `requisition_item_id` char(38) DEFAULT NULL,
  `sort_order` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKDA3BB2981CD3412D` (`requisition_item_id`),
  KEY `FKDA3BB2983B5F6286` (`shipment_id`),
  KEY `FKDA3BB29844979D51` (`recipient_id`),
  KEY `FKDA3BB29849AB6B52` (`donor_id`),
  KEY `FKDA3BB29869DB749D` (`bin_location_id`),
  KEY `FKDA3BB2987400E88E` (`container_id`),
  KEY `FKDA3BB298AA992CED` (`inventory_item_id`),
  KEY `FKDA3BB298DED5FAE7` (`product_id`),
  CONSTRAINT `FKDA3BB2981CD3412D` FOREIGN KEY (`requisition_item_id`) REFERENCES `requisition_item` (`id`),
  CONSTRAINT `FKDA3BB2983B5F6286` FOREIGN KEY (`shipment_id`) REFERENCES `shipment` (`id`),
  CONSTRAINT `FKDA3BB29844979D51` FOREIGN KEY (`recipient_id`) REFERENCES `person` (`id`),
  CONSTRAINT `FKDA3BB29849AB6B52` FOREIGN KEY (`donor_id`) REFERENCES `donor` (`id`),
  CONSTRAINT `FKDA3BB29869DB749D` FOREIGN KEY (`bin_location_id`) REFERENCES `location` (`id`),
  CONSTRAINT `FKDA3BB2987400E88E` FOREIGN KEY (`container_id`) REFERENCES `container` (`id`),
  CONSTRAINT `FKDA3BB298AA992CED` FOREIGN KEY (`inventory_item_id`) REFERENCES `inventory_item` (`id`),
  CONSTRAINT `FKDA3BB298DED5FAE7` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shipment_item`
--

LOCK TABLES `shipment_item` WRITE;
/*!40000 ALTER TABLE `shipment_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `shipment_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shipment_method`
--

DROP TABLE IF EXISTS `shipment_method`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `shipment_method` (
  `id` char(38) NOT NULL,
  `version` bigint(20) NOT NULL,
  `date_created` datetime NOT NULL,
  `last_updated` datetime NOT NULL,
  `shipper_service_id` char(38) DEFAULT NULL,
  `tracking_number` varchar(255) DEFAULT NULL,
  `shipper_id` char(38) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK40203B26296B2CA3` (`shipper_service_id`),
  KEY `FK40203B263896C98E` (`shipper_id`),
  CONSTRAINT `FK40203B26296B2CA3` FOREIGN KEY (`shipper_service_id`) REFERENCES `shipper_service` (`id`),
  CONSTRAINT `FK40203B263896C98E` FOREIGN KEY (`shipper_id`) REFERENCES `shipper` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shipment_method`
--

LOCK TABLES `shipment_method` WRITE;
/*!40000 ALTER TABLE `shipment_method` DISABLE KEYS */;
/*!40000 ALTER TABLE `shipment_method` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shipment_reference_number`
--

DROP TABLE IF EXISTS `shipment_reference_number`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `shipment_reference_number` (
  `shipment_reference_numbers_id` char(38) DEFAULT NULL,
  `reference_number_id` char(38) DEFAULT NULL,
  `reference_numbers_idx` int(11) DEFAULT NULL,
  KEY `FK312F6C292388BC5` (`reference_number_id`),
  KEY `fk_shipment_reference_number_shipment` (`shipment_reference_numbers_id`),
  CONSTRAINT `FK312F6C292388BC5` FOREIGN KEY (`reference_number_id`) REFERENCES `reference_number` (`id`),
  CONSTRAINT `fk_shipment_reference_number_shipment` FOREIGN KEY (`shipment_reference_numbers_id`) REFERENCES `shipment` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shipment_reference_number`
--

LOCK TABLES `shipment_reference_number` WRITE;
/*!40000 ALTER TABLE `shipment_reference_number` DISABLE KEYS */;
/*!40000 ALTER TABLE `shipment_reference_number` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shipment_type`
--

DROP TABLE IF EXISTS `shipment_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `shipment_type` (
  `id` char(38) NOT NULL,
  `version` bigint(20) NOT NULL,
  `date_created` datetime NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `last_updated` datetime NOT NULL,
  `name` varchar(255) NOT NULL,
  `sort_order` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shipment_type`
--

LOCK TABLES `shipment_type` WRITE;
/*!40000 ALTER TABLE `shipment_type` DISABLE KEYS */;
INSERT INTO `shipment_type` VALUES
('1',1,'2010-08-25 00:00:00',NULL,'2010-08-25 00:00:00','Air',1),
('2',1,'2010-08-25 00:00:00',NULL,'2010-08-25 00:00:00','Sea',2),
('3',0,'2011-08-22 00:00:00','','2011-08-22 00:00:00','Land',3),
('4',1,'2010-08-25 00:00:00',NULL,'2010-08-25 00:00:00','Suitcase',4),
('5',1,'2018-08-28 00:00:00',NULL,'2018-08-28 00:00:00','Default',5);
/*!40000 ALTER TABLE `shipment_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shipment_workflow`
--

DROP TABLE IF EXISTS `shipment_workflow`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `shipment_workflow` (
  `id` char(38) NOT NULL,
  `version` bigint(20) NOT NULL,
  `date_created` datetime NOT NULL,
  `last_updated` datetime NOT NULL,
  `name` varchar(255) NOT NULL,
  `shipment_type_id` char(38) DEFAULT NULL,
  `excluded_fields` varchar(255) DEFAULT NULL,
  `document_template` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKD584C4C4FF77FF9B` (`shipment_type_id`),
  CONSTRAINT `FKD584C4C4FF77FF9B` FOREIGN KEY (`shipment_type_id`) REFERENCES `shipment_type` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shipment_workflow`
--

LOCK TABLES `shipment_workflow` WRITE;
/*!40000 ALTER TABLE `shipment_workflow` DISABLE KEYS */;
INSERT INTO `shipment_workflow` VALUES
('1',0,'2011-02-28 00:00:00','2011-02-28 00:00:00','Air shipment workflow','1','carrier,recipient',NULL),
('2',0,'2011-02-28 00:00:00','2011-02-28 00:00:00','Sea shipment workflow','2','carrier,recipient',NULL),
('3',0,'2011-02-28 00:00:00','2011-02-28 00:00:00','Suitcase shipment workflow','4','shipmentMethod.shipper','suitcaseLetter'),
('4',0,'2012-01-26 00:00:00','2012-01-26 00:00:00','Land shipment workflow','3',NULL,NULL),
('5',0,'2018-08-28 00:00:00','2018-08-28 00:00:00','Stock movement shipment workflow','5',NULL,NULL);
/*!40000 ALTER TABLE `shipment_workflow` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shipment_workflow_container_type`
--

DROP TABLE IF EXISTS `shipment_workflow_container_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `shipment_workflow_container_type` (
  `shipment_workflow_container_types_id` char(38) DEFAULT NULL,
  `container_type_id` char(38) DEFAULT NULL,
  `container_types_idx` int(11) DEFAULT NULL,
  KEY `FKDEF5AD1317A6E251` (`container_type_id`),
  CONSTRAINT `FKDEF5AD1317A6E251` FOREIGN KEY (`container_type_id`) REFERENCES `container_type` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shipment_workflow_container_type`
--

LOCK TABLES `shipment_workflow_container_type` WRITE;
/*!40000 ALTER TABLE `shipment_workflow_container_type` DISABLE KEYS */;
INSERT INTO `shipment_workflow_container_type` VALUES
('1','2',0),
('1','8',1),
('2','2',0),
('2','8',1),
('3','3',0);
/*!40000 ALTER TABLE `shipment_workflow_container_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shipment_workflow_document`
--

DROP TABLE IF EXISTS `shipment_workflow_document`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `shipment_workflow_document` (
  `shipment_workflow_id` char(38) NOT NULL,
  `document_id` char(38) DEFAULT NULL,
  KEY `FK9A945A36C800AA15` (`document_id`),
  KEY `FK9A945A36EC587CFB` (`shipment_workflow_id`),
  CONSTRAINT `FK9A945A36C800AA15` FOREIGN KEY (`document_id`) REFERENCES `document` (`id`),
  CONSTRAINT `FK9A945A36EC587CFB` FOREIGN KEY (`shipment_workflow_id`) REFERENCES `shipment_workflow` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shipment_workflow_document`
--

LOCK TABLES `shipment_workflow_document` WRITE;
/*!40000 ALTER TABLE `shipment_workflow_document` DISABLE KEYS */;
/*!40000 ALTER TABLE `shipment_workflow_document` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shipment_workflow_document_template`
--

DROP TABLE IF EXISTS `shipment_workflow_document_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `shipment_workflow_document_template` (
  `shipment_workflow_id` char(38) DEFAULT NULL,
  `document_id` char(38) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shipment_workflow_document_template`
--

LOCK TABLES `shipment_workflow_document_template` WRITE;
/*!40000 ALTER TABLE `shipment_workflow_document_template` DISABLE KEYS */;
/*!40000 ALTER TABLE `shipment_workflow_document_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shipment_workflow_reference_number_type`
--

DROP TABLE IF EXISTS `shipment_workflow_reference_number_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `shipment_workflow_reference_number_type` (
  `shipment_workflow_reference_number_types_id` char(38) DEFAULT NULL,
  `reference_number_type_id` char(38) DEFAULT NULL,
  `reference_number_types_idx` int(11) DEFAULT NULL,
  KEY `FK4BB27241154F600` (`reference_number_type_id`),
  CONSTRAINT `FK4BB27241154F600` FOREIGN KEY (`reference_number_type_id`) REFERENCES `reference_number_type` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shipment_workflow_reference_number_type`
--

LOCK TABLES `shipment_workflow_reference_number_type` WRITE;
/*!40000 ALTER TABLE `shipment_workflow_reference_number_type` DISABLE KEYS */;
INSERT INTO `shipment_workflow_reference_number_type` VALUES
('1','5',0),
('1','6',1),
('1','7',2),
('2','4',0),
('2','6',1),
('2','7',2),
('3','8',0),
('4','9',0);
/*!40000 ALTER TABLE `shipment_workflow_reference_number_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shipper`
--

DROP TABLE IF EXISTS `shipper`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `shipper` (
  `id` char(38) NOT NULL,
  `version` bigint(20) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `last_updated` datetime DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `parameter_name` varchar(255) DEFAULT NULL,
  `tracking_format` varchar(255) DEFAULT NULL,
  `tracking_url` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shipper`
--

LOCK TABLES `shipper` WRITE;
/*!40000 ALTER TABLE `shipper` DISABLE KEYS */;
INSERT INTO `shipper` VALUES
('1',1,'2010-08-25 00:00:00',NULL,'2010-08-25 00:00:00','FedEx',NULL,'999999999999','http://www.fedex.com/Tracking?ascend_header=1&amp;clienttype=dotcom&amp;cntry_code=us&amp;language=english&amp;tracknumbers=%s'),
('2',1,'2010-08-25 00:00:00',NULL,'2010-08-25 00:00:00','UPS',NULL,'1Z9999W99999999999','http://wwwapps.ups.com/WebTracking/processInputRequest?sort_by=status&amp;tracknums_displayed=1&amp;TypeOfInquiryNumber=T&amp;loc=en_US&amp;InquiryNumber1=%s&amp;track.x=0&amp;track.y=0'),
('3',1,'2010-08-25 00:00:00',NULL,'2010-08-25 00:00:00','DHL','q',NULL,'http://www.google.com/search?hl=en&amp;site=&amp;q='),
('4',1,'2010-08-25 00:00:00',NULL,'2010-08-25 00:00:00','USPS','q',NULL,'http://www.google.com/search?hl=en&amp;site=&amp;q='),
('5',1,'2010-08-25 00:00:00',NULL,'2010-08-25 00:00:00','Courier','q',NULL,'http://www.google.com/search?hl=en&amp;site=&amp;q=');
/*!40000 ALTER TABLE `shipper` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shipper_service`
--

DROP TABLE IF EXISTS `shipper_service`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `shipper_service` (
  `id` char(38) NOT NULL,
  `version` bigint(20) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `shipper_id` char(38) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKDF7559D73896C98E` (`shipper_id`),
  CONSTRAINT `FKDF7559D73896C98E` FOREIGN KEY (`shipper_id`) REFERENCES `shipper` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shipper_service`
--

LOCK TABLES `shipper_service` WRITE;
/*!40000 ALTER TABLE `shipper_service` DISABLE KEYS */;
INSERT INTO `shipper_service` VALUES
('1',1,'Same Day Delivery','Same Day Air','1'),
('10',1,'3-5 Business Days','Ground','4'),
('11',1,NULL,'International Flight','5'),
('2',1,'Next Day Delivery','Express Freight','1'),
('3',1,'3-5 Business Days','Ground','1'),
('4',1,'Same Day Delivery','Same Day Air','2'),
('5',1,'Next Day Delivery','Express Freight','2'),
('6',1,'3-5 Business Days','Ground','2'),
('7',1,'Same Day Delivery','Same Day Air','3'),
('8',1,'Next Day Delivery','Express Freight','3'),
('9',1,'3-5 Business Days','Ground','3');
/*!40000 ALTER TABLE `shipper_service` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `stock_movement`
--

DROP TABLE IF EXISTS `stock_movement`;
/*!50001 DROP VIEW IF EXISTS `stock_movement`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `stock_movement` AS SELECT
 NULL AS `id`,
 NULL AS `name`,
 NULL AS `identifier`,
 NULL AS `description`,
 NULL AS `origin_id`,
 NULL AS `destination_id`,
 NULL AS `date_requested`,
 NULL AS `date_created`,
 NULL AS `last_updated`,
 NULL AS `requested_by_id`,
 NULL AS `created_by_id`,
 NULL AS `updated_by_id`,
 NULL AS `line_item_count`,
 NULL AS `shipment_type_id`,
 NULL AS `date_shipped`,
 NULL AS `expected_delivery_date`,
 NULL AS `driver_name`,
 NULL AS `comments`,
 NULL AS `shipment_id`,
 NULL AS `shipment_status`,
 NULL AS `tracking_number`,
 NULL AS `status_code`,
 NULL AS `requisition_id`,
 NULL AS `status`,
 NULL AS `request_type`,
 NULL AS `source_type`,
 NULL AS `stocklist_id`,
 NULL AS `order_id`,
 NULL AS `order_status`,
 NULL AS `stock_movement_type` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `stock_movement_item`
--

DROP TABLE IF EXISTS `stock_movement_item`;
/*!50001 DROP VIEW IF EXISTS `stock_movement_item`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `stock_movement_item` AS SELECT
 NULL AS `id`,
 NULL AS `requisition_item_type`,
 NULL AS `parent_requisition_item_id`,
 NULL AS `requisition_id`,
 NULL AS `origin_id`,
 NULL AS `destination_id`,
 NULL AS `product_id`,
 NULL AS `product_code`,
 NULL AS `name`,
 NULL AS `quantity`,
 NULL AS `quantity_canceled`,
 NULL AS `quantity_counted`,
 NULL AS `order_index`,
 NULL AS `cancel_reason_code`,
 NULL AS `comments`,
 NULL AS `quantity_revised` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `stock_movement_list_item`
--

DROP TABLE IF EXISTS `stock_movement_list_item`;
/*!50001 DROP VIEW IF EXISTS `stock_movement_list_item`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `stock_movement_list_item` AS SELECT
 NULL AS `id`,
 NULL AS `name`,
 NULL AS `identifier`,
 NULL AS `description`,
 NULL AS `origin_id`,
 NULL AS `destination_id`,
 NULL AS `date_requested`,
 NULL AS `date_created`,
 NULL AS `last_updated`,
 NULL AS `requested_by_id`,
 NULL AS `created_by_id`,
 NULL AS `updated_by_id`,
 NULL AS `shipment_id`,
 NULL AS `shipment_status`,
 NULL AS `shipment_type_id`,
 NULL AS `status_code`,
 NULL AS `requisition_id`,
 NULL AS `status`,
 NULL AS `request_type`,
 NULL AS `source_type`,
 NULL AS `stocklist_id`,
 NULL AS `order_id`,
 NULL AS `stock_movement_type` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `stocklist_item_list`
--

DROP TABLE IF EXISTS `stocklist_item_list`;
/*!50001 DROP VIEW IF EXISTS `stocklist_item_list`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `stocklist_item_list` AS SELECT
 NULL AS `id`,
 NULL AS `product_id`,
 NULL AS `stocklist_id`,
 NULL AS `name`,
 NULL AS `location_id`,
 NULL AS `location_name`,
 NULL AS `location_group_id`,
 NULL AS `location_group_name`,
 NULL AS `manager_id`,
 NULL AS `manager_name`,
 NULL AS `manager_email`,
 NULL AS `uom`,
 NULL AS `max_quantity`,
 NULL AS `replenishment_period`,
 NULL AS `monthly_demand` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `stockout_fact`
--

DROP TABLE IF EXISTS `stockout_fact`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `stockout_fact` (
  `date_dimension_id` bigint(20) NOT NULL,
  `location_dimension_id` bigint(20) NOT NULL,
  `product_dimension_id` bigint(20) NOT NULL,
  `quantity_on_hand` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`date_dimension_id`,`location_dimension_id`,`product_dimension_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stockout_fact`
--

LOCK TABLES `stockout_fact` WRITE;
/*!40000 ALTER TABLE `stockout_fact` DISABLE KEYS */;
/*!40000 ALTER TABLE `stockout_fact` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `substitution_item`
--

DROP TABLE IF EXISTS `substitution_item`;
/*!50001 DROP VIEW IF EXISTS `substitution_item`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `substitution_item` AS SELECT
 NULL AS `id`,
 NULL AS `parent_requisition_item_id`,
 NULL AS `requisition_id`,
 NULL AS `origin_id`,
 NULL AS `destination_id`,
 NULL AS `product_id`,
 NULL AS `product_code`,
 NULL AS `name`,
 NULL AS `sort_order`,
 NULL AS `quantity` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `supplier`
--

DROP TABLE IF EXISTS `supplier`;
/*!50001 DROP VIEW IF EXISTS `supplier`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `supplier` AS SELECT
 NULL AS `id`,
 NULL AS `name`,
 NULL AS `organization_id`,
 NULL AS `pending_orders_count`,
 NULL AS `pending_shipments_count` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `synonym`
--

DROP TABLE IF EXISTS `synonym`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `synonym` (
  `id` char(38) NOT NULL,
  `version` bigint(20) NOT NULL,
  `name` varchar(255) NOT NULL,
  `product_id` char(38) NOT NULL,
  `date_created` datetime NOT NULL,
  `last_updated` datetime NOT NULL,
  `created_by_id` char(38) DEFAULT NULL,
  `updated_by_id` char(38) DEFAULT NULL,
  `locale` varchar(50) DEFAULT NULL,
  `synonym_type_code` varchar(100) DEFAULT 'ALTERNATE_NAME',
  PRIMARY KEY (`id`),
  KEY `FK299E50ABDED5FAE7` (`product_id`),
  KEY `FK98293BFB217F5972` (`created_by_id`),
  KEY `FK98293BFB426DD105` (`updated_by_id`),
  CONSTRAINT `FK299E50ABDED5FAE7` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`),
  CONSTRAINT `FK98293BFB217F5972` FOREIGN KEY (`created_by_id`) REFERENCES `user` (`id`),
  CONSTRAINT `FK98293BFB426DD105` FOREIGN KEY (`updated_by_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `synonym`
--

LOCK TABLES `synonym` WRITE;
/*!40000 ALTER TABLE `synonym` DISABLE KEYS */;
/*!40000 ALTER TABLE `synonym` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tag`
--

DROP TABLE IF EXISTS `tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tag` (
  `id` char(38) NOT NULL,
  `version` bigint(20) NOT NULL,
  `created_by_id` char(38) DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `last_updated` datetime NOT NULL,
  `tag` varchar(255) NOT NULL,
  `updated_by_id` char(38) DEFAULT NULL,
  `is_active` tinyint(3) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK1BF9A217F5972` (`created_by_id`),
  KEY `FK1BF9A426DD105` (`updated_by_id`),
  CONSTRAINT `FK1BF9A217F5972` FOREIGN KEY (`created_by_id`) REFERENCES `user` (`id`),
  CONSTRAINT `FK1BF9A426DD105` FOREIGN KEY (`updated_by_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tag`
--

LOCK TABLES `tag` WRITE;
/*!40000 ALTER TABLE `tag` DISABLE KEYS */;
/*!40000 ALTER TABLE `tag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transaction`
--

DROP TABLE IF EXISTS `transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `transaction` (
  `id` char(38) NOT NULL,
  `version` bigint(20) NOT NULL,
  `created_by_id` char(38) DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `destination_id` char(38) DEFAULT NULL,
  `inventory_id` char(38) DEFAULT NULL,
  `last_updated` datetime NOT NULL,
  `source_id` char(38) DEFAULT NULL,
  `transaction_date` datetime NOT NULL,
  `transaction_type_id` char(38) DEFAULT NULL,
  `confirmed` bit(1) DEFAULT NULL,
  `confirmed_by_id` char(38) DEFAULT NULL,
  `date_confirmed` datetime DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `incoming_shipment_id` char(38) DEFAULT NULL,
  `outgoing_shipment_id` char(38) DEFAULT NULL,
  `updated_by_id` char(38) DEFAULT NULL,
  `transaction_number` varchar(255) DEFAULT NULL,
  `requisition_id` char(38) DEFAULT NULL,
  `order_id` char(38) DEFAULT NULL,
  `receipt_id` char(38) DEFAULT NULL,
  `cycle_count_id` char(38) DEFAULT NULL,
  `transaction_source_id` char(38) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK7FA0D2DE1E2B3CDC` (`destination_id`),
  KEY `FK7FA0D2DE217F5972` (`created_by_id`),
  KEY `FK7FA0D2DE3265A8A9` (`confirmed_by_id`),
  KEY `FK7FA0D2DE426DD105` (`updated_by_id`),
  KEY `FK7FA0D2DE5DE9E374` (`requisition_id`),
  KEY `FK7FA0D2DE5F12AFED` (`incoming_shipment_id`),
  KEY `FK7FA0D2DE72A2C5B4` (`inventory_id`),
  KEY `FK7FA0D2DE828481AF` (`source_id`),
  KEY `FK7FA0D2DEB3FB7111` (`transaction_type_id`),
  KEY `FK7FA0D2DEB80B3233` (`outgoing_shipment_id`),
  KEY `FK7FA0D2DED08EDBE6` (`order_id`),
  KEY `FK7FA0D2DEF7076438` (`receipt_id`),
  KEY `fk_transaction_cycle_count` (`cycle_count_id`),
  KEY `idx_transaction_transaction_date` (`transaction_date`),
  KEY `fk_transaction_transaction_source` (`transaction_source_id`),
  CONSTRAINT `FK7FA0D2DE1E2B3CDC` FOREIGN KEY (`destination_id`) REFERENCES `location` (`id`),
  CONSTRAINT `FK7FA0D2DE217F5972` FOREIGN KEY (`created_by_id`) REFERENCES `user` (`id`),
  CONSTRAINT `FK7FA0D2DE3265A8A9` FOREIGN KEY (`confirmed_by_id`) REFERENCES `user` (`id`),
  CONSTRAINT `FK7FA0D2DE426DD105` FOREIGN KEY (`updated_by_id`) REFERENCES `user` (`id`),
  CONSTRAINT `FK7FA0D2DE5DE9E374` FOREIGN KEY (`requisition_id`) REFERENCES `requisition` (`id`),
  CONSTRAINT `FK7FA0D2DE5F12AFED` FOREIGN KEY (`incoming_shipment_id`) REFERENCES `shipment` (`id`),
  CONSTRAINT `FK7FA0D2DE72A2C5B4` FOREIGN KEY (`inventory_id`) REFERENCES `inventory` (`id`),
  CONSTRAINT `FK7FA0D2DE828481AF` FOREIGN KEY (`source_id`) REFERENCES `location` (`id`),
  CONSTRAINT `FK7FA0D2DEB3FB7111` FOREIGN KEY (`transaction_type_id`) REFERENCES `transaction_type` (`id`),
  CONSTRAINT `FK7FA0D2DEB80B3233` FOREIGN KEY (`outgoing_shipment_id`) REFERENCES `shipment` (`id`),
  CONSTRAINT `FK7FA0D2DED08EDBE6` FOREIGN KEY (`order_id`) REFERENCES `order` (`id`),
  CONSTRAINT `FK7FA0D2DEF7076438` FOREIGN KEY (`receipt_id`) REFERENCES `receipt` (`id`),
  CONSTRAINT `fk_transaction_cycle_count` FOREIGN KEY (`cycle_count_id`) REFERENCES `cycle_count` (`id`),
  CONSTRAINT `fk_transaction_transaction_source` FOREIGN KEY (`transaction_source_id`) REFERENCES `transaction_source` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transaction`
--

LOCK TABLES `transaction` WRITE;
/*!40000 ALTER TABLE `transaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `transaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transaction_entry`
--

DROP TABLE IF EXISTS `transaction_entry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `transaction_entry` (
  `id` char(38) NOT NULL,
  `version` bigint(20) NOT NULL,
  `inventory_item_id` char(38) DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `transaction_id` char(38) DEFAULT NULL,
  `comments` varchar(255) DEFAULT NULL,
  `transaction_entries_idx` int(11) DEFAULT NULL,
  `bin_location_id` char(38) DEFAULT NULL,
  `product_id` char(38) DEFAULT NULL,
  `reason_code` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKABC21FD12EF4C7F4` (`transaction_id`),
  KEY `FKABC21FD169DB749D` (`bin_location_id`),
  KEY `FKABC21FD1AA992CED` (`inventory_item_id`),
  KEY `FKABC21FD1DED5FAE7` (`product_id`),
  CONSTRAINT `FKABC21FD12EF4C7F4` FOREIGN KEY (`transaction_id`) REFERENCES `transaction` (`id`),
  CONSTRAINT `FKABC21FD169DB749D` FOREIGN KEY (`bin_location_id`) REFERENCES `location` (`id`),
  CONSTRAINT `FKABC21FD1AA992CED` FOREIGN KEY (`inventory_item_id`) REFERENCES `inventory_item` (`id`),
  CONSTRAINT `FKABC21FD1DED5FAE7` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transaction_entry`
--

LOCK TABLES `transaction_entry` WRITE;
/*!40000 ALTER TABLE `transaction_entry` DISABLE KEYS */;
/*!40000 ALTER TABLE `transaction_entry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transaction_fact`
--

DROP TABLE IF EXISTS `transaction_fact`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `transaction_fact` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `version` bigint(20) NOT NULL,
  `location_key_id` bigint(20) NOT NULL,
  `lot_key_id` bigint(20) NOT NULL,
  `product_key_id` bigint(20) NOT NULL,
  `quantity` decimal(19,2) DEFAULT NULL,
  `transaction_date` datetime NOT NULL,
  `transaction_date_key_id` bigint(20) NOT NULL,
  `transaction_number` varchar(255) NOT NULL,
  `transaction_type_key_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK1E50D72D72882836` (`product_key_id`),
  KEY `FK1E50D72DA27827C2` (`location_key_id`),
  KEY `FK1E50D72DCA32CFEF` (`transaction_date_key_id`),
  KEY `FK1E50D72DCA354381` (`transaction_type_key_id`),
  KEY `FK1E50D72DD1F27172` (`lot_key_id`),
  CONSTRAINT `FK1E50D72D72882836` FOREIGN KEY (`product_key_id`) REFERENCES `product_dimension` (`id`),
  CONSTRAINT `FK1E50D72DA27827C2` FOREIGN KEY (`location_key_id`) REFERENCES `location_dimension` (`id`),
  CONSTRAINT `FK1E50D72DCA32CFEF` FOREIGN KEY (`transaction_date_key_id`) REFERENCES `date_dimension` (`id`),
  CONSTRAINT `FK1E50D72DCA354381` FOREIGN KEY (`transaction_type_key_id`) REFERENCES `transaction_type_dimension` (`id`),
  CONSTRAINT `FK1E50D72DD1F27172` FOREIGN KEY (`lot_key_id`) REFERENCES `lot_dimension` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transaction_fact`
--

LOCK TABLES `transaction_fact` WRITE;
/*!40000 ALTER TABLE `transaction_fact` DISABLE KEYS */;
/*!40000 ALTER TABLE `transaction_fact` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transaction_source`
--

DROP TABLE IF EXISTS `transaction_source`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `transaction_source` (
  `id` char(38) NOT NULL,
  `transaction_action` varchar(50) NOT NULL,
  `shipment_id` char(38) DEFAULT NULL,
  `requisition_id` char(38) DEFAULT NULL,
  `receipt_id` char(38) DEFAULT NULL,
  `order_id` char(38) DEFAULT NULL,
  `cycle_count_id` char(38) DEFAULT NULL,
  `origin_id` char(38) DEFAULT NULL,
  `destination_id` char(38) DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `last_updated` datetime NOT NULL,
  `created_by_id` char(38) NOT NULL,
  `updated_by_id` char(38) NOT NULL,
  `accurate` bit(1) DEFAULT b'1',
  PRIMARY KEY (`id`),
  KEY `fk_transaction_source_created_by` (`created_by_id`),
  KEY `fk_transaction_source_updated_by` (`updated_by_id`),
  KEY `fk_transaction_source_origin` (`origin_id`),
  KEY `fk_transaction_source_destination` (`destination_id`),
  KEY `fk_transaction_source_shipment` (`shipment_id`),
  KEY `fk_transaction_source_requisition` (`requisition_id`),
  KEY `fk_transaction_source_receipt` (`receipt_id`),
  KEY `fk_transaction_source_order` (`order_id`),
  KEY `fk_transaction_source_cycle_count` (`cycle_count_id`),
  CONSTRAINT `fk_transaction_source_created_by` FOREIGN KEY (`created_by_id`) REFERENCES `user` (`id`),
  CONSTRAINT `fk_transaction_source_cycle_count` FOREIGN KEY (`cycle_count_id`) REFERENCES `cycle_count` (`id`),
  CONSTRAINT `fk_transaction_source_destination` FOREIGN KEY (`destination_id`) REFERENCES `location` (`id`),
  CONSTRAINT `fk_transaction_source_order` FOREIGN KEY (`order_id`) REFERENCES `order` (`id`),
  CONSTRAINT `fk_transaction_source_origin` FOREIGN KEY (`origin_id`) REFERENCES `location` (`id`),
  CONSTRAINT `fk_transaction_source_receipt` FOREIGN KEY (`receipt_id`) REFERENCES `receipt` (`id`),
  CONSTRAINT `fk_transaction_source_requisition` FOREIGN KEY (`requisition_id`) REFERENCES `requisition` (`id`),
  CONSTRAINT `fk_transaction_source_shipment` FOREIGN KEY (`shipment_id`) REFERENCES `shipment` (`id`),
  CONSTRAINT `fk_transaction_source_updated_by` FOREIGN KEY (`updated_by_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transaction_source`
--

LOCK TABLES `transaction_source` WRITE;
/*!40000 ALTER TABLE `transaction_source` DISABLE KEYS */;
/*!40000 ALTER TABLE `transaction_source` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transaction_type`
--

DROP TABLE IF EXISTS `transaction_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `transaction_type` (
  `id` char(38) NOT NULL,
  `version` bigint(20) NOT NULL,
  `date_created` datetime NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `last_updated` datetime NOT NULL,
  `name` varchar(255) NOT NULL,
  `sort_order` int(11) DEFAULT NULL,
  `transaction_code` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_transaction_type_transaction_code` (`transaction_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transaction_type`
--

LOCK TABLES `transaction_type` WRITE;
/*!40000 ALTER TABLE `transaction_type` DISABLE KEYS */;
INSERT INTO `transaction_type` VALUES
('10',0,'2011-04-05 00:00:00',NULL,'2011-04-05 00:00:00','Adjustment - Debit',0,'DEBIT'),
('11',0,'2011-04-06 00:00:00',NULL,'2011-04-06 00:00:00','Product Inventory',0,'PRODUCT_INVENTORY'),
('12',0,'2025-04-29 00:00:00',NULL,'2025-04-29 00:00:00','Inventory Baseline',0,'PRODUCT_INVENTORY'),
('2',0,'2010-11-08 00:00:00',NULL,'2010-11-08 00:00:00','Consumption',0,'DEBIT'),
('3',0,'2010-11-08 00:00:00',NULL,'2010-11-08 00:00:00','Adjustment',0,'CREDIT'),
('4',0,'2010-11-08 00:00:00',NULL,'2010-11-08 00:00:00','Expired',0,'DEBIT'),
('5',0,'2010-11-08 00:00:00',NULL,'2010-11-08 00:00:00','Damaged',0,'DEBIT'),
('7',0,'2010-12-06 00:00:00','Inventory','2010-12-06 00:00:00','Inventory',0,'INVENTORY'),
('8',0,'2011-03-17 00:00:00',NULL,'2011-03-17 00:00:00','Transfer In',0,'CREDIT'),
('9',0,'2011-03-17 00:00:00',NULL,'2011-03-17 00:00:00','Transfer Out',0,'DEBIT');
/*!40000 ALTER TABLE `transaction_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transaction_type_dimension`
--

DROP TABLE IF EXISTS `transaction_type_dimension`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `transaction_type_dimension` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `version` bigint(20) NOT NULL,
  `transaction_code` varchar(255) NOT NULL,
  `transaction_type_id` char(38) NOT NULL,
  `transaction_type_name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK7FA87A22B3FB7111` (`transaction_type_id`),
  CONSTRAINT `FK7FA87A22B3FB7111` FOREIGN KEY (`transaction_type_id`) REFERENCES `transaction_type` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transaction_type_dimension`
--

LOCK TABLES `transaction_type_dimension` WRITE;
/*!40000 ALTER TABLE `transaction_type_dimension` DISABLE KEYS */;
/*!40000 ALTER TABLE `transaction_type_dimension` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `unit_of_measure`
--

DROP TABLE IF EXISTS `unit_of_measure`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `unit_of_measure` (
  `id` char(38) NOT NULL,
  `version` bigint(20) NOT NULL,
  `code` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `uom_class_id` char(38) DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `last_updated` datetime NOT NULL,
  `created_by_id` char(38) DEFAULT NULL,
  `updated_by_id` char(38) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK7348B491217F5972` (`created_by_id`),
  KEY `FK7348B491426DD105` (`updated_by_id`),
  KEY `FK7348B49197D8303E` (`uom_class_id`),
  CONSTRAINT `FK7348B491217F5972` FOREIGN KEY (`created_by_id`) REFERENCES `user` (`id`),
  CONSTRAINT `FK7348B491426DD105` FOREIGN KEY (`updated_by_id`) REFERENCES `user` (`id`),
  CONSTRAINT `FK7348B49197D8303E` FOREIGN KEY (`uom_class_id`) REFERENCES `unit_of_measure_class` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `unit_of_measure`
--

LOCK TABLES `unit_of_measure` WRITE;
/*!40000 ALTER TABLE `unit_of_measure` DISABLE KEYS */;
INSERT INTO `unit_of_measure` VALUES
('BTL',0,'BTL',NULL,'Bottle','QUANTITY','2020-04-25 00:00:00','2020-04-25 00:00:00','1','1'),
('BX',0,'BX',NULL,'Box','QUANTITY','2020-04-25 00:00:00','2020-04-25 00:00:00','1','1'),
('CS',0,'CS',NULL,'Case','QUANTITY','2020-04-25 00:00:00','2020-04-25 00:00:00','1','1'),
('EA',0,'EA',NULL,'Each','QUANTITY','2020-04-25 00:00:00','2020-04-25 00:00:00','1','1'),
('EUR',0,'EUR','EUR (€)','Euro','CURRENCY','2018-09-10 00:00:00','2018-09-10 00:00:00','1','1'),
('PK',0,'PK',NULL,'Pack','QUANTITY','2020-04-25 00:00:00','2020-04-25 00:00:00','1','1'),
('RL',0,'RL',NULL,'Roll','QUANTITY','2020-04-25 00:00:00','2020-04-25 00:00:00','1','1'),
('USD',0,'USD','USD (US$)','US Dollar','CURRENCY','2018-09-10 00:00:00','2018-09-10 00:00:00','1','1');
/*!40000 ALTER TABLE `unit_of_measure` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `unit_of_measure_class`
--

DROP TABLE IF EXISTS `unit_of_measure_class`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `unit_of_measure_class` (
  `id` char(38) NOT NULL,
  `active` bit(1) DEFAULT b'1',
  `name` varchar(255) DEFAULT NULL,
  `code` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `base_uom_id` char(38) DEFAULT NULL,
  `version` bigint(20) NOT NULL,
  `date_created` datetime NOT NULL,
  `last_updated` datetime NOT NULL,
  `type` varchar(255) DEFAULT NULL,
  `created_by_id` char(38) DEFAULT NULL,
  `updated_by_id` char(38) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK5D1B504A217F5972` (`created_by_id`),
  KEY `FK5D1B504A426DD105` (`updated_by_id`),
  KEY `FK5D1B504A6B9DFD` (`base_uom_id`),
  CONSTRAINT `FK5D1B504A217F5972` FOREIGN KEY (`created_by_id`) REFERENCES `user` (`id`),
  CONSTRAINT `FK5D1B504A426DD105` FOREIGN KEY (`updated_by_id`) REFERENCES `user` (`id`),
  CONSTRAINT `FK5D1B504A6B9DFD` FOREIGN KEY (`base_uom_id`) REFERENCES `unit_of_measure` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `unit_of_measure_class`
--

LOCK TABLES `unit_of_measure_class` WRITE;
/*!40000 ALTER TABLE `unit_of_measure_class` DISABLE KEYS */;
INSERT INTO `unit_of_measure_class` VALUES
('CURRENCY','','Currency','CURRENCY','','USD',0,'2018-09-10 00:00:00','2018-09-10 00:00:00','CURRENCY',NULL,NULL),
('QUANTITY','','Quantity','QUANTITY','','EA',0,'2020-04-25 00:00:00','2020-04-25 00:00:00','QUANTITY',NULL,NULL);
/*!40000 ALTER TABLE `unit_of_measure_class` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `unit_of_measure_conversion`
--

DROP TABLE IF EXISTS `unit_of_measure_conversion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `unit_of_measure_conversion` (
  `id` char(38) NOT NULL,
  `version` bigint(20) NOT NULL,
  `active` bit(1) NOT NULL,
  `from_unit_of_measure_id` char(38) NOT NULL,
  `to_unit_of_measure_id` char(38) NOT NULL,
  `conversion_rate` decimal(19,8) NOT NULL,
  `date_created` datetime NOT NULL,
  `last_updated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK2E4511844A3E746` (`from_unit_of_measure_id`),
  KEY `FK2E4511849B9434D5` (`to_unit_of_measure_id`),
  CONSTRAINT `FK2E4511844A3E746` FOREIGN KEY (`from_unit_of_measure_id`) REFERENCES `unit_of_measure` (`id`),
  CONSTRAINT `FK2E4511849B9434D5` FOREIGN KEY (`to_unit_of_measure_id`) REFERENCES `unit_of_measure` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `unit_of_measure_conversion`
--

LOCK TABLES `unit_of_measure_conversion` WRITE;
/*!40000 ALTER TABLE `unit_of_measure_conversion` DISABLE KEYS */;
/*!40000 ALTER TABLE `unit_of_measure_conversion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `id` char(38) NOT NULL,
  `last_login_date` datetime DEFAULT NULL,
  `manager_id` char(38) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `warehouse_id` char(38) DEFAULT NULL,
  `photo` mediumblob DEFAULT NULL,
  `locale` varchar(255) DEFAULT NULL,
  `remember_last_location` bit(1) DEFAULT NULL,
  `timezone` varchar(255) DEFAULT NULL,
  `dashboard_config` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `FK36EBCB1F28CE07` (`warehouse_id`),
  KEY `FK36EBCB41E07A73` (`manager_id`),
  CONSTRAINT `FK36EBCB1F28CE07` FOREIGN KEY (`warehouse_id`) REFERENCES `location` (`id`),
  CONSTRAINT `FK36EBCB41E07A73` FOREIGN KEY (`manager_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES
('1','2026-10-13 06:24:19',NULL,'password','admin','1',NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_role`
--

DROP TABLE IF EXISTS `user_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_role` (
  `user_id` char(38) DEFAULT NULL,
  `role_id` char(38) DEFAULT NULL,
  KEY `FK143BF46AA462C195` (`user_id`),
  KEY `FK143BF46AFF37FDB5` (`role_id`),
  CONSTRAINT `FK143BF46AA462C195` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`),
  CONSTRAINT `FK143BF46AFF37FDB5` FOREIGN KEY (`role_id`) REFERENCES `role` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_role`
--

LOCK TABLES `user_role` WRITE;
/*!40000 ALTER TABLE `user_role` DISABLE KEYS */;
INSERT INTO `user_role` VALUES
('1','5'),
('1','ff80818162d9f9cc0162d9fc1c220003'),
('1','ff80818162d9f9cc0162d9fbf09e0002'),
('1','ff808181681c757c01681c89c4960001');
/*!40000 ALTER TABLE `user_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'openboxes'
--

--
-- Final view structure for view `cycle_count_candidate`
--

/*!50001 DROP VIEW IF EXISTS `cycle_count_candidate`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb3 */;
/*!50001 SET character_set_results     = utf8mb3 */;
/*!50001 SET collation_connection      = utf8mb3_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`openboxes`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `cycle_count_candidate` AS (select `cycle_count_session`.`id` AS `id`,`cycle_count_session`.`inventory_id` AS `inventory_id`,`cycle_count_session`.`product_id` AS `product_id`,`cycle_count_session`.`facility_id` AS `facility_id`,`cycle_count_session`.`cycle_count_request_id` AS `cycle_count_request_id`,`cycle_count_session`.`abc_class` AS `abc_class`,`cycle_count_session`.`status` AS `status`,`cycle_count_session`.`product_active` AS `product_active`,`cycle_count_session`.`inventory_item_count` AS `inventory_item_count`,`cycle_count_session`.`internal_locations` AS `internal_locations`,`cycle_count_session`.`quantity_on_hand` AS `quantity_on_hand`,`cycle_count_session`.`quantity_allocated` AS `quantity_allocated`,`cycle_count_session`.`negative_item_count` AS `negative_item_count`,`cycle_count_session`.`date_last_count` AS `date_last_count`,`cycle_count_session`.`days_since_last_count` AS `days_since_last_count`,`cycle_count_session`.`date_next_count` AS `date_next_count`,`cycle_count_session`.`days_until_next_count` AS `days_until_next_count`,`cycle_count_session`.`date_latest_inventory` AS `date_latest_inventory`,`cycle_count_session`.`negative_item_count` > 0 or `cycle_count_session`.`quantity_on_hand` > 0 AS `has_stock_on_hand_or_negative_stock`,case when `cycle_count_session`.`negative_item_count` > 0 then 0 when `cycle_count_session`.`date_last_count` is null then 1 when `cycle_count_session`.`days_until_next_count` < 0 then 1 when `cycle_count_session`.`days_until_next_count` >= 0 then 2 else 3 end AS `sort_order` from `cycle_count_session` where `cycle_count_session`.`product_active` <> 0 order by case when `cycle_count_session`.`negative_item_count` > 0 then 0 when `cycle_count_session`.`date_last_count` is null then 1 when `cycle_count_session`.`days_until_next_count` < 0 then 1 when `cycle_count_session`.`days_until_next_count` >= 0 then 2 else 3 end,`cycle_count_session`.`abc_class` is null,`cycle_count_session`.`abc_class`,`cycle_count_session`.`days_until_next_count`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `cycle_count_details`
--

/*!50001 DROP VIEW IF EXISTS `cycle_count_details`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb3 */;
/*!50001 SET character_set_results     = utf8mb3 */;
/*!50001 SET collation_connection      = utf8mb3_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`openboxes`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `cycle_count_details` AS with cycle_count_item_details as (select `cycle_count_item`.`cycle_count_id` AS `cycle_count_id`,`cycle_count_item`.`product_id` AS `product_id`,`cycle_count_item`.`inventory_item_id` AS `inventory_item_id`,`cycle_count_item`.`location_id` AS `location_id` from `cycle_count_item` group by `cycle_count_item`.`cycle_count_id`,`cycle_count_item`.`product_id`,`cycle_count_item`.`inventory_item_id`,`cycle_count_item`.`location_id`), cycle_count_initial_count_details as (select `cycle_count`.`id` AS `cycle_count_id`,`cycle_count_item`.`facility_id` AS `facility_id`,`cycle_count_item`.`product_id` AS `product_id`,`cycle_count_item`.`inventory_item_id` AS `inventory_item_id`,`cycle_count_item`.`location_id` AS `location_id`,`cycle_count_item`.`date_counted` AS `date_counted`,`cycle_count_item`.`assignee_id` AS `assignee_id`,`cycle_count_item`.`quantity_on_hand` AS `quantity_on_hand`,`cycle_count_item`.`quantity_counted` AS `quantity_counted`,`cycle_count_item`.`quantity_counted` - `cycle_count_item`.`quantity_on_hand` AS `quantity_variance`,`cycle_count_item`.`discrepancy_reason_code` AS `variance_reason_code`,`cycle_count_item`.`comment` AS `variance_comment`,`cycle_count_item`.`count_index` AS `count_index` from ((`cycle_count_item` join `cycle_count` on(`cycle_count_item`.`cycle_count_id` = `cycle_count`.`id`)) join `cycle_count_request` on(`cycle_count`.`id` = `cycle_count_request`.`cycle_count_id`)) where `cycle_count_item`.`count_index` = 0), cycle_count_final_count_details as (select `cycle_count`.`id` AS `cycle_count_id`,`cycle_count_item`.`date_counted` AS `date_counted`,`cycle_count`.`facility_id` AS `facility_id`,`cycle_count_item`.`product_id` AS `product_id`,`cycle_count_item`.`inventory_item_id` AS `inventory_item_id`,`cycle_count_item`.`location_id` AS `location_id`,`cycle_count_item`.`assignee_id` AS `assignee_id`,`cycle_count_item`.`quantity_on_hand` AS `quantity_on_hand`,`cycle_count_item`.`quantity_counted` AS `quantity_counted`,`cycle_count_item`.`quantity_counted` - `cycle_count_item`.`quantity_on_hand` AS `quantity_variance`,`cycle_count_item`.`discrepancy_reason_code` AS `variance_reason_code`,`cycle_count_item`.`comment` AS `variance_comment`,`cycle_count_item`.`count_index` AS `count_index` from ((`cycle_count_item` join `cycle_count` on(`cycle_count_item`.`cycle_count_id` = `cycle_count`.`id`)) join `cycle_count_request` on(`cycle_count`.`id` = `cycle_count_request`.`cycle_count_id`)) where `cycle_count_item`.`count_index` = (select max(`b`.`count_index`) from `cycle_count_item` `b` where `cycle_count_item`.`cycle_count_id` = `b`.`cycle_count_id` and `cycle_count_item`.`product_id` = `b`.`product_id` and (`cycle_count_item`.`location_id` = `b`.`location_id` or `cycle_count_item`.`location_id` is null and `b`.`location_id` is null) and `cycle_count_item`.`inventory_item_id` = `b`.`inventory_item_id`)), transaction_details as (select `transaction`.`cycle_count_id` AS `cycle_count_id`,`transaction`.`id` AS `transaction_id`,`transaction`.`transaction_date` AS `transaction_date`,`transaction`.`transaction_number` AS `transaction_number`,`transaction_type`.`name` AS `transaction_type_name`,`transaction_type`.`transaction_code` AS `transaction_type_code`,`transaction`.`created_by_id` AS `created_by_id`,`transaction`.`updated_by_id` AS `updated_by_id`,`transaction`.`date_created` AS `date_created`,`transaction`.`last_updated` AS `last_updated` from (((`transaction` FORCE INDEX (`fk_transaction_cycle_count`) join `transaction_type` on(`transaction`.`transaction_type_id` = `transaction_type`.`id`)) join `inventory` on(`transaction`.`inventory_id` = `inventory`.`id`)) join `location` `facility` on(`facility`.`inventory_id` = `inventory`.`id`)) where `transaction_type`.`transaction_code` = 'PRODUCT_INVENTORY' and `transaction`.`cycle_count_id` is not null)select `cycle_count_details`.`id` AS `id`,`cycle_count_details`.`cycle_count_id` AS `cycle_count_id`,`cycle_count_details`.`transaction_number` AS `transaction_number`,`cycle_count_details`.`date_requested` AS `date_requested`,`cycle_count_details`.`date_initiated` AS `date_initiated`,`cycle_count_details`.`date_recorded` AS `date_recorded`,`cycle_count_details`.`requested_by_id` AS `requested_by_id`,`cycle_count_details`.`initiated_by_id` AS `initiated_by_id`,`cycle_count_details`.`recorded_by_id` AS `recorded_by_id`,`cycle_count_details`.`facility_id` AS `facility_id`,`cycle_count_details`.`location_id` AS `location_id`,`cycle_count_details`.`product_id` AS `product_id`,`cycle_count_details`.`inventory_item_id` AS `inventory_item_id`,`cycle_count_details`.`blind_count_date_counted` AS `blind_count_date_counted`,`cycle_count_details`.`blind_count_assignee_id` AS `blind_count_assignee_id`,`cycle_count_details`.`blind_count_quantity_on_hand` AS `blind_count_quantity_on_hand`,`cycle_count_details`.`blind_count_quantity_counted` AS `blind_count_quantity_counted`,`cycle_count_details`.`blind_count_quantity_variance` AS `blind_count_quantity_variance`,`cycle_count_details`.`blind_count_variance_percentage` AS `blind_count_variance_percentage`,`cycle_count_details`.`blind_count_variance_reason_code` AS `blind_count_variance_reason_code`,`cycle_count_details`.`blind_count_variance_comment` AS `blind_count_variance_comment`,`cycle_count_details`.`blind_count_count_index` AS `blind_count_count_index`,`cycle_count_details`.`verification_count_date_counted` AS `verification_count_date_counted`,`cycle_count_details`.`verification_count_assignee_id` AS `verification_count_assignee_id`,`cycle_count_details`.`verification_count_quantity_on_hand` AS `verification_count_quantity_on_hand`,`cycle_count_details`.`verification_count_quantity_counted` AS `verification_count_quantity_counted`,`cycle_count_details`.`verification_count_quantity_variance` AS `verification_count_quantity_variance`,`cycle_count_details`.`verification_count_variance_percentage` AS `verification_count_variance_percentage`,`cycle_count_details`.`verification_count_variance_reason_code` AS `verification_count_variance_reason_code`,`cycle_count_details`.`verification_count_variance_comment` AS `verification_count_variance_comment`,`cycle_count_details`.`verification_count_count_index` AS `verification_count_count_index` from (select crc32(concat(`cycle_count`.`id`,`product`.`product_code`,coalesce(`inventory_item`.`lot_number`,'DEFAULT'),coalesce(`bin_location`.`name`,'DEFAULT'))) AS `id`,`cycle_count`.`id` AS `cycle_count_id`,`cycle_count_request`.`date_created` AS `date_requested`,`cycle_count_request`.`created_by_id` AS `requested_by_id`,`cycle_count`.`date_created` AS `date_initiated`,`cycle_count`.`created_by_id` AS `initiated_by_id`,`facility`.`id` AS `facility_id`,`inventory_item`.`id` AS `inventory_item_id`,`product`.`id` AS `product_id`,`bin_location`.`id` AS `location_id`,`transaction_details`.`transaction_date` AS `date_recorded`,`transaction_details`.`transaction_number` AS `transaction_number`,`transaction_details`.`created_by_id` AS `recorded_by_id`,`icd`.`assignee_id` AS `blind_count_assignee_id`,`icd`.`date_counted` AS `blind_count_date_counted`,`icd`.`quantity_on_hand` AS `blind_count_quantity_on_hand`,`icd`.`quantity_counted` AS `blind_count_quantity_counted`,`icd`.`quantity_variance` AS `blind_count_quantity_variance`,abs(`icd`.`quantity_variance`) / `icd`.`quantity_on_hand` AS `blind_count_variance_percentage`,`icd`.`variance_reason_code` AS `blind_count_variance_reason_code`,`icd`.`variance_comment` AS `blind_count_variance_comment`,`icd`.`count_index` AS `blind_count_count_index`,`fcd`.`assignee_id` AS `verification_count_assignee_id`,`fcd`.`date_counted` AS `verification_count_date_counted`,`fcd`.`quantity_on_hand` AS `verification_count_quantity_on_hand`,`fcd`.`quantity_counted` AS `verification_count_quantity_counted`,`fcd`.`quantity_variance` AS `verification_count_quantity_variance`,abs(`fcd`.`quantity_variance`) / `fcd`.`quantity_on_hand` AS `verification_count_variance_percentage`,`fcd`.`variance_reason_code` AS `verification_count_variance_reason_code`,`fcd`.`variance_comment` AS `verification_count_variance_comment`,`fcd`.`count_index` AS `verification_count_count_index` from (((((((((`cycle_count_item_details` `cycle_count_item` join `cycle_count` on(`cycle_count_item`.`cycle_count_id` = `cycle_count`.`id`)) join `cycle_count_request` on(`cycle_count`.`id` = `cycle_count_request`.`cycle_count_id`)) join `location` `facility` on(`facility`.`id` = `cycle_count`.`facility_id`)) join `inventory_item` on(`cycle_count_item`.`inventory_item_id` = `inventory_item`.`id`)) join `product` on(`inventory_item`.`product_id` = `product`.`id`)) left join `location` `bin_location` on(`cycle_count_item`.`location_id` = `bin_location`.`id` or `cycle_count_item`.`location_id` is null and `bin_location`.`id` is null)) left join `transaction_details` on(`cycle_count`.`id` = `transaction_details`.`cycle_count_id`)) left join `cycle_count_initial_count_details` `icd` on(`cycle_count_item`.`cycle_count_id` = `icd`.`cycle_count_id` and `icd`.`product_id` = `cycle_count_item`.`product_id` and `icd`.`inventory_item_id` = `cycle_count_item`.`inventory_item_id` and (`icd`.`location_id` = `cycle_count_item`.`location_id` or `icd`.`location_id` is null and `cycle_count_item`.`location_id` is null))) left join `cycle_count_final_count_details` `fcd` on(`fcd`.`cycle_count_id` = `cycle_count_item`.`cycle_count_id` and `fcd`.`product_id` = `cycle_count_item`.`product_id` and `fcd`.`inventory_item_id` = `cycle_count_item`.`inventory_item_id` and (`fcd`.`location_id` = `cycle_count_item`.`location_id` or `fcd`.`location_id` is null and `cycle_count_item`.`location_id` is null))) where `cycle_count_request`.`status` = 'COMPLETED') `cycle_count_details` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `cycle_count_frequency`
--

/*!50001 DROP VIEW IF EXISTS `cycle_count_frequency`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb3 */;
/*!50001 SET character_set_results     = utf8mb3 */;
/*!50001 SET collation_connection      = utf8mb3_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`openboxes`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `cycle_count_frequency` AS (select `cycle_count_frequency`.`abc_class` AS `abc_class`,`cycle_count_frequency`.`facility_id` AS `facility_id`,`cycle_count_frequency`.`frequency` AS `frequency` from (select 'A' AS `abc_class`,NULL AS `facility_id`,90 AS `frequency` union all select 'B' AS `abc_class`,NULL AS `facility_id`,180 AS `frequency` union all select 'C' AS `abc_class`,NULL AS `facility_id`,365 AS `frequency` union all select 'DEFAULT' AS `abc_class`,NULL AS `facility_id`,365 AS `frequency`) `cycle_count_frequency`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `cycle_count_metadata`
--

/*!50001 DROP VIEW IF EXISTS `cycle_count_metadata`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb3 */;
/*!50001 SET character_set_results     = utf8mb3 */;
/*!50001 SET collation_connection      = utf8mb3_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`openboxes`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `cycle_count_metadata` AS (select crc32(concat(`cycle_count_metadata_tmp`.`inventory_id`,`cycle_count_metadata_tmp`.`product_id`)) AS `id`,`cycle_count_metadata_tmp`.`inventory_id` AS `inventory_id`,`cycle_count_metadata_tmp`.`product_id` AS `product_id`,`cycle_count_metadata_tmp`.`date_counted` AS `date_counted`,`cycle_count_metadata_tmp`.`abc_class` AS `abc_class`,`cycle_count_frequency`.`frequency` AS `frequency`,to_days(current_timestamp()) - to_days(`cycle_count_metadata_tmp`.`date_counted`) AS `days_since_last_count`,`cycle_count_metadata_tmp`.`date_counted` + interval `cycle_count_frequency`.`frequency` day AS `date_expected`,to_days(`cycle_count_metadata_tmp`.`date_counted` + interval `cycle_count_frequency`.`frequency` day) - to_days(current_timestamp()) AS `days_until_next_count` from ((select `product_count_history`.`inventory_id` AS `inventory_id`,`product_count_history`.`product_id` AS `product_id`,`product_count_history`.`date_counted` AS `date_counted`,case when `product_classification`.`abc_class` = 'A' then 'A' when `product_classification`.`abc_class` = 'B' then 'B' when `product_classification`.`abc_class` = 'C' then 'C' else 'DEFAULT' end AS `abc_class` from (`product_count_history` left join `product_classification` on(`product_count_history`.`inventory_id` = `product_classification`.`inventory_id` and `product_count_history`.`product_id` = `product_classification`.`product_id`))) `cycle_count_metadata_tmp` left join `cycle_count_frequency` on(`cycle_count_frequency`.`abc_class` = `cycle_count_metadata_tmp`.`abc_class`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `cycle_count_product_summary`
--

/*!50001 DROP VIEW IF EXISTS `cycle_count_product_summary`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb3 */;
/*!50001 SET character_set_results     = utf8mb3 */;
/*!50001 SET collation_connection      = utf8mb3_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`openboxes`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `cycle_count_product_summary` AS with cycle_count_item_variance as (select `cycle_count_item_variance`.`cycle_count_id` AS `cycle_count_id`,`cycle_count_item_variance`.`cycle_count_item_id` AS `cycle_count_item_id`,`cycle_count_item_variance`.`transaction_date` AS `transaction_date`,`cycle_count_item_variance`.`date_counted` AS `date_counted`,`cycle_count_item_variance`.`facility_id` AS `facility_id`,`cycle_count_item_variance`.`product_id` AS `product_id`,`cycle_count_item_variance`.`inventory_item_id` AS `inventory_item_id`,`cycle_count_item_variance`.`location_id` AS `location_id`,`cycle_count_item_variance`.`quantity_on_hand` AS `quantity_on_hand`,`cycle_count_item_variance`.`quantity_counted` AS `quantity_counted`,`cycle_count_item_variance`.`variance_reason_code` AS `variance_reason_code`,`cycle_count_item_variance`.`comment` AS `comment`,`cycle_count_item_variance`.`count_index` AS `count_index` from (select `cycle_count`.`id` AS `cycle_count_id`,`cycle_count_item`.`id` AS `cycle_count_item_id`,`ltp`.`latest_transaction_date` AS `transaction_date`,`cycle_count_item`.`date_counted` AS `date_counted`,`cycle_count`.`facility_id` AS `facility_id`,`cycle_count_item`.`product_id` AS `product_id`,`cycle_count_item`.`inventory_item_id` AS `inventory_item_id`,`cycle_count_item`.`location_id` AS `location_id`,`cycle_count_item`.`quantity_on_hand` AS `quantity_on_hand`,`cycle_count_item`.`quantity_counted` AS `quantity_counted`,`cycle_count_item`.`discrepancy_reason_code` AS `variance_reason_code`,`cycle_count_item`.`comment` AS `comment`,`cycle_count_item`.`count_index` AS `count_index` from (((`cycle_count_item` left join `cycle_count` on(`cycle_count_item`.`cycle_count_id` = `cycle_count`.`id`)) left join `cycle_count_request` on(`cycle_count`.`id` = `cycle_count_request`.`cycle_count_id`)) join `latest_transaction_per_cycle_count` `ltp` on(`ltp`.`cycle_count_id` = `cycle_count`.`id`)) where `cycle_count_request`.`status` = 'COMPLETED') `cycle_count_item_variance`), cycle_count_item_final_count as (select `cycle_count_item_variance`.`cycle_count_id` AS `cycle_count_id`,`cycle_count_item_variance`.`cycle_count_item_id` AS `cycle_count_item_id`,`cycle_count_item_variance`.`transaction_date` AS `transaction_date`,`cycle_count_item_variance`.`date_counted` AS `date_counted`,`cycle_count_item_variance`.`facility_id` AS `facility_id`,`cycle_count_item_variance`.`product_id` AS `product_id`,`cycle_count_item_variance`.`inventory_item_id` AS `inventory_item_id`,`cycle_count_item_variance`.`location_id` AS `location_id`,`cycle_count_item_variance`.`quantity_on_hand` AS `quantity_on_hand`,`cycle_count_item_variance`.`quantity_counted` AS `quantity_counted`,`cycle_count_item_variance`.`variance_reason_code` AS `variance_reason_code`,`cycle_count_item_variance`.`comment` AS `comment`,`cycle_count_item_variance`.`count_index` AS `count_index` from `cycle_count_item_variance` where `cycle_count_item_variance`.`count_index` = (select max(`cycle_count_item`.`count_index`) from (`cycle_count_item` left join `cycle_count` on(`cycle_count_item`.`cycle_count_id` = `cycle_count`.`id`)) where `cycle_count_item`.`cycle_count_id` = `cycle_count_item_variance`.`cycle_count_id` and `cycle_count_item`.`product_id` = `cycle_count_item_variance`.`product_id` and `cycle_count_item`.`inventory_item_id` = `cycle_count_item_variance`.`inventory_item_id` and `cycle_count`.`facility_id` = `cycle_count_item_variance`.`facility_id`))select `cycle_count_item_final_count`.`cycle_count_id` AS `cycle_count_id`,`cycle_count_item_final_count`.`transaction_date` AS `transaction_date`,`cycle_count_item_final_count`.`facility_id` AS `facility_id`,`cycle_count_item_final_count`.`product_id` AS `product_id`,sum(`cycle_count_item_final_count`.`quantity_counted` - `cycle_count_item_final_count`.`quantity_on_hand`) AS `quantity_variance` from `cycle_count_item_final_count` group by `cycle_count_item_final_count`.`cycle_count_id`,`cycle_count_item_final_count`.`facility_id`,`cycle_count_item_final_count`.`product_id` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `cycle_count_session`
--

/*!50001 DROP VIEW IF EXISTS `cycle_count_session`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb3 */;
/*!50001 SET character_set_results     = utf8mb3 */;
/*!50001 SET collation_connection      = utf8mb3_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`openboxes`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `cycle_count_session` AS (select crc32(concat(`product_availability`.`location_id`,`product_availability`.`product_id`)) AS `id`,`facility`.`inventory_id` AS `inventory_id`,`product_availability`.`product_id` AS `product_id`,`product_availability`.`location_id` AS `facility_id`,max(`cycle_count_request_summary`.`cycle_count_request_id`) AS `cycle_count_request_id`,min(`product_classification`.`abc_class`) AS `abc_class`,max(`cycle_count_request_summary`.`status`) AS `status`,`product`.`active` AS `product_active`,count(`product_availability`.`id`) AS `inventory_item_count`,group_concat(distinct if(`product_availability`.`quantity_on_hand` <> 0,concat_ws(': ',`zone`.`name`,`product_availability`.`bin_location_name`),NULL) separator ',') AS `internal_locations`,sum(`product_availability`.`quantity_on_hand`) AS `quantity_on_hand`,sum(`product_availability`.`quantity_allocated`) AS `quantity_allocated`,sum(case when `product_availability`.`quantity_on_hand` < 0 then 1 else 0 end) AS `negative_item_count`,`cycle_count_metadata`.`date_counted` AS `date_last_count`,`cycle_count_metadata`.`days_since_last_count` AS `days_since_last_count`,`cycle_count_metadata`.`date_expected` AS `date_next_count`,`cycle_count_metadata`.`days_until_next_count` AS `days_until_next_count`,NULL AS `date_latest_inventory` from (((((((`product_availability` join `location` `facility` on(`product_availability`.`location_id` = `facility`.`id`)) join `product` on(`product_availability`.`product_id` = `product`.`id`)) left join `location` `bin_location` on(`product_availability`.`bin_location_id` = `bin_location`.`id`)) left join `location` `zone` on(`bin_location`.`zone_id` = `zone`.`id`)) left join `product_classification` on(`product_availability`.`product_id` = `product_classification`.`product_id` and `facility`.`inventory_id` = `product_classification`.`inventory_id`)) left join (select `cycle_count_request`.`facility_id` AS `facility_id`,`cycle_count_request`.`product_id` AS `product_id`,`cycle_count_request`.`id` AS `cycle_count_request_id`,coalesce(`cycle_count`.`status`,`cycle_count_request`.`status`) AS `status` from (`cycle_count_request` left join `cycle_count` on(`cycle_count_request`.`cycle_count_id` = `cycle_count`.`id`)) where `cycle_count_request`.`id` is null or `cycle_count_request`.`status` <> 'COMPLETED' and `cycle_count_request`.`status` <> 'CANCELED') `cycle_count_request_summary` on(`cycle_count_request_summary`.`product_id` = `product_availability`.`product_id` and `cycle_count_request_summary`.`facility_id` = `product_availability`.`location_id`)) left join (select `cycle_count_metadata`.`inventory_id` AS `inventory_id`,`cycle_count_metadata`.`product_id` AS `product_id`,`cycle_count_metadata`.`abc_class` AS `abc_class`,max(`cycle_count_metadata`.`date_counted`) AS `date_counted`,max(`cycle_count_metadata`.`days_since_last_count`) AS `days_since_last_count`,max(`cycle_count_metadata`.`date_expected`) AS `date_expected`,max(`cycle_count_metadata`.`days_until_next_count`) AS `days_until_next_count` from `cycle_count_metadata` group by `cycle_count_metadata`.`inventory_id`,`cycle_count_metadata`.`product_id`) `cycle_count_metadata` on(`cycle_count_metadata`.`inventory_id` = `facility`.`inventory_id` and `cycle_count_metadata`.`product_id` = `product_availability`.`product_id`)) group by `product_availability`.`location_id`,`product_availability`.`product_id`,`facility`.`inventory_id`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `cycle_count_summary`
--

/*!50001 DROP VIEW IF EXISTS `cycle_count_summary`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb3 */;
/*!50001 SET character_set_results     = utf8mb3 */;
/*!50001 SET collation_connection      = utf8mb3_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`openboxes`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `cycle_count_summary` AS (select crc32(concat(`cycle_count_details`.`cycle_count_id`,`cycle_count_details`.`product_id`)) AS `id`,`cycle_count_details`.`cycle_count_id` AS `cycle_count_id`,`cycle_count_details`.`product_id` AS `product_id`,max(`cycle_count_details`.`transaction_number`) AS `transaction_number`,max(`cycle_count_details`.`date_requested`) AS `date_requested`,max(`cycle_count_details`.`date_initiated`) AS `date_initiated`,max(`cycle_count_details`.`date_recorded`) AS `date_recorded`,max(`cycle_count_details`.`requested_by_id`) AS `requested_by_id`,max(`cycle_count_details`.`initiated_by_id`) AS `initiated_by_id`,max(`cycle_count_details`.`recorded_by_id`) AS `recorded_by_id`,max(`cycle_count_details`.`facility_id`) AS `facility_id`,max(`cycle_count_details`.`location_id`) AS `location_id`,max(`cycle_count_details`.`blind_count_date_counted`) AS `blind_count_date_counted`,max(`cycle_count_details`.`blind_count_assignee_id`) AS `blind_count_assignee_id`,sum(`cycle_count_details`.`blind_count_quantity_counted`) AS `blind_count_quantity_counted`,sum(`cycle_count_details`.`blind_count_quantity_on_hand`) AS `blind_count_quantity_on_hand`,sum(`cycle_count_details`.`blind_count_quantity_variance`) AS `blind_count_quantity_variance`,group_concat(`cycle_count_details`.`blind_count_variance_reason_code` separator ',') AS `blind_count_variance_reason_code`,group_concat(`cycle_count_details`.`blind_count_variance_comment` separator ',') AS `blind_count_variance_comment`,max(`cycle_count_details`.`verification_count_date_counted`) AS `verification_count_date_counted`,max(`cycle_count_details`.`verification_count_assignee_id`) AS `verification_count_assignee_id`,sum(`cycle_count_details`.`verification_count_quantity_counted`) AS `verification_count_quantity_counted`,sum(`cycle_count_details`.`verification_count_quantity_on_hand`) AS `verification_count_quantity_on_hand`,sum(`cycle_count_details`.`verification_count_quantity_variance`) AS `verification_count_quantity_variance`,group_concat(`cycle_count_details`.`verification_count_variance_reason_code` separator ',') AS `verification_count_variance_reason_code`,group_concat(`cycle_count_details`.`verification_count_variance_comment` separator ',') AS `verification_count_variance_comment` from `cycle_count_details` group by `cycle_count_details`.`cycle_count_id`,`cycle_count_details`.`product_id`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `edit_page_item`
--

/*!50001 DROP VIEW IF EXISTS `edit_page_item`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb3 */;
/*!50001 SET character_set_results     = utf8mb3 */;
/*!50001 SET collation_connection      = utf8mb3_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`openboxes`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `edit_page_item` AS select `stock_movement_item`.`id` AS `id`,`stock_movement_item`.`requisition_item_type` AS `requisition_item_type`,`stock_movement_item`.`parent_requisition_item_id` AS `parent_requisition_item_id`,`stock_movement_item`.`requisition_id` AS `requisition_id`,`stock_movement_item`.`origin_id` AS `origin_id`,`stock_movement_item`.`destination_id` AS `destination_id`,`stock_movement_item`.`product_id` AS `product_id`,`stock_movement_item`.`product_code` AS `product_code`,`stock_movement_item`.`name` AS `name`,`stock_movement_item`.`quantity` AS `quantity`,`stock_movement_item`.`quantity_canceled` AS `quantity_canceled`,`stock_movement_item`.`quantity_revised` AS `quantity_revised`,`stock_movement_item`.`quantity_counted` AS `quantity_counted`,`stock_movement_item`.`order_index` AS `sort_order`,`stock_movement_item`.`cancel_reason_code` AS `cancel_reason_code`,`stock_movement_item`.`comments` AS `comments`,if(`product_substitution_status`.`substitution_status` is null,'NO',`product_substitution_status`.`substitution_status`) AS `substitution_status` from (`stock_movement_item` left join `product_substitution_status` on(`product_substitution_status`.`product_id` = `stock_movement_item`.`product_id` and `product_substitution_status`.`location_id` = `stock_movement_item`.`origin_id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `fill_rate`
--

/*!50001 DROP VIEW IF EXISTS `fill_rate`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb3 */;
/*!50001 SET character_set_results     = utf8mb3 */;
/*!50001 SET collation_connection      = utf8mb3_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`openboxes`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `fill_rate` AS select `r`.`id` AS `id`,`r`.`status` AS `status`,`ri`.`quantity` AS `quantity`,`ri`.`quantity_canceled` AS `quantity_canceled`,`ri`.`cancel_reason_code` AS `cancel_reason_code`,`ri`.`requisition_item_type` AS `requisition_item_type`,`product`.`id` AS `product_id`,`product`.`product_code` AS `product_code`,`product`.`name` AS `product_name`,`t`.`transaction_date` AS `transaction_date`,month(`t`.`transaction_date`) AS `month`,year(`t`.`transaction_date`) AS `year`,`origin`.`id` AS `origin_id`,`origin`.`name` AS `origin_name`,`destination`.`id` AS `destination_id`,`destination`.`name` AS `destination_name`,case when `il`.`status` = 'FORMULARY' then 1 else 0 end AS `formulary`,case when `ri`.`quantity_canceled` > 0 and `ri`.`cancel_reason_code` in ('STOCKOUT','LOW_STOCK','COULD_NOT_LOCATE') then 0 else 1 end AS `fill_rate` from ((((((`requisition` `r` join `requisition_item` `ri` on(`r`.`id` = `ri`.`requisition_id`)) join `location` `origin` on(`origin`.`id` = `r`.`origin_id`)) join `location` `destination` on(`destination`.`id` = `r`.`destination_id`)) join `product` on(`product`.`id` = `ri`.`product_id`)) left join `transaction` `t` on(`t`.`requisition_id` = `r`.`id`)) left join `inventory_level` `il` on(`il`.`inventory_id` = `origin`.`inventory_id` and `il`.`product_id` = `product`.`id`)) where `ri`.`requisition_item_type` = 'ORIGINAL' and `r`.`status` = 'ISSUED' and `r`.`type` <> 'IMPORT' */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `inbound_stock_movement_list_item`
--

/*!50001 DROP VIEW IF EXISTS `inbound_stock_movement_list_item`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb3 */;
/*!50001 SET character_set_results     = utf8mb3 */;
/*!50001 SET collation_connection      = utf8mb3_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`openboxes`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `inbound_stock_movement_list_item` AS select coalesce(`r`.`id`,`s`.`id`) AS `id`,coalesce(`r`.`name`,`s`.`name`) AS `name`,coalesce(`r`.`request_number`,`s`.`shipment_number`) AS `identifier`,coalesce(`r`.`description`,`s`.`description`) AS `description`,coalesce(`r`.`origin_id`,`s`.`origin_id`) AS `origin_id`,coalesce(`r`.`destination_id`,`s`.`destination_id`) AS `destination_id`,coalesce(`r`.`date_created`,`s`.`date_created`) AS `date_created`,coalesce(`r`.`last_updated`,`s`.`last_updated`) AS `last_updated`,coalesce(`r`.`date_requested`,`s`.`date_created`) AS `date_requested`,`r`.`requested_by_id` AS `requested_by_id`,coalesce(`r`.`created_by_id`,`s`.`created_by_id`) AS `created_by_id`,coalesce(`r`.`updated_by_id`,`s`.`updated_by_id`) AS `updated_by_id`,`s`.`id` AS `shipment_id`,`r`.`id` AS `requisition_id`,NULL AS `order_id`,`r`.`requisition_template_id` AS `stocklist_id`,`s`.`current_status` AS `current_status`,`s`.`shipment_type_id` AS `shipment_type_id` from (`shipment` `s` left join `requisition` `r` on(`r`.`id` = `s`.`requisition_id`)) where !exists(select 1 from (((`shipment_item` `si` join `order_shipment` `os` on(`os`.`shipment_item_id` = `si`.`id`)) join `order_item` `oi` on(`oi`.`id` = `os`.`order_item_id`)) join `order` `o` on(`o`.`id` = `oi`.`order_id`)) where `si`.`shipment_id` = `s`.`id` and `o`.`order_type_id` = 'RETURN_ORDER' limit 1) union all select `o`.`id` AS `id`,`o`.`name` AS `name`,`o`.`order_number` AS `identifier`,`o`.`description` AS `description`,`o`.`origin_id` AS `origin_id`,`o`.`destination_id` AS `destination_id`,`o`.`date_created` AS `date_created`,`o`.`last_updated` AS `last_updated`,`o`.`date_ordered` AS `date_requested`,`o`.`ordered_by_id` AS `requested_by_id`,`o`.`created_by_id` AS `created_by_id`,`o`.`updated_by_id` AS `updated_by_id`,`s`.`id` AS `shipment_id`,NULL AS `requisition_id`,`o`.`id` AS `order_id`,NULL AS `stocklist_id`,`s`.`current_status` AS `current_status`,`s`.`shipment_type_id` AS `shipment_type_id` from ((((`order` `o` left join `order_item` `oi` on(`oi`.`order_id` = `o`.`id`)) left join `order_shipment` `os` on(`os`.`order_item_id` = `oi`.`id`)) left join `shipment_item` `si` on(`si`.`id` = `os`.`shipment_item_id`)) left join `shipment` `s` on(`s`.`id` = `si`.`shipment_id`)) where `o`.`order_type_id` = 'RETURN_ORDER' group by `o`.`id`,`s`.`id` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `inventory_audit_details`
--

/*!50001 DROP VIEW IF EXISTS `inventory_audit_details`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb3 */;
/*!50001 SET character_set_results     = utf8mb3 */;
/*!50001 SET collation_connection      = utf8mb3_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`openboxes`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `inventory_audit_details` AS with product_availability_summary as (select `product_availability`.`location_id` AS `facility_id`,`product_availability`.`product_id` AS `product_id`,sum(`product_availability`.`quantity_on_hand`) AS `quantity_on_hand`,sum(`product_availability`.`quantity_available_to_promise`) AS `quantity_available`,sum(`product_availability`.`quantity_allocated`) AS `quantity_allocated` from `product_availability` USE INDEX (`product_availability_product_location_idx`) group by `product_availability`.`product_id`,`product_availability`.`location_id`)select `facility`.`id` AS `facility_id`,`facility`.`name` AS `facility_name`,`product`.`id` AS `product_id`,`product`.`product_code` AS `product_code`,`product`.`name` AS `product_name`,ifnull(`product`.`price_per_unit`,0) AS `price_per_unit`,coalesce(`inventory_level`.`abc_class`,`product`.`abc_class`) AS `abc_class`,`transaction`.`cycle_count_id` AS `cycle_count_id`,`transaction`.`id` AS `transaction_id`,`transaction`.`transaction_number` AS `transaction_number`,`transaction`.`transaction_date` AS `transaction_date`,`transaction`.`transaction_type_id` AS `transaction_type_id`,`transaction_type`.`name` AS `transaction_type_name`,`inventory_item`.`id` AS `inventory_item_id`,`transaction_entry`.`bin_location_id` AS `location_id`,`transaction_entry`.`quantity` AS `quantity_adjusted`,`product_availability_summary`.`quantity_on_hand` AS `quantity_on_hand` from (((((((((`transaction_entry` join `transaction` on(`transaction_entry`.`transaction_id` = `transaction`.`id`)) join `inventory` on(`transaction`.`inventory_id` = `inventory`.`id`)) join `location` `facility` on(`facility`.`inventory_id` = `inventory`.`id`)) join `inventory_item` on(`transaction_entry`.`inventory_item_id` = `inventory_item`.`id`)) join `product` on(`inventory_item`.`product_id` = `product`.`id`)) join `transaction_type` on(`transaction`.`transaction_type_id` = `transaction_type`.`id`)) left join `location` on(`location`.`id` = `transaction_entry`.`bin_location_id`)) left join `inventory_level` on(`product`.`id` = `inventory_level`.`product_id` and `inventory`.`id` = `inventory_level`.`inventory_id` and `inventory_level`.`internal_location_id` is null)) join `product_availability_summary` on(`product`.`id` = `product_availability_summary`.`product_id` and `facility`.`id` = `product_availability_summary`.`facility_id`)) where `transaction_type`.`id` = '3' */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `inventory_audit_rollup`
--

/*!50001 DROP VIEW IF EXISTS `inventory_audit_rollup`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb3 */;
/*!50001 SET character_set_results     = utf8mb3 */;
/*!50001 SET collation_connection      = utf8mb3_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`openboxes`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `inventory_audit_rollup` AS select `inventory_audit_details`.`facility_id` AS `facility_id`,`inventory_audit_details`.`product_id` AS `product_id`,`inventory_audit_details`.`transaction_id` AS `transaction_id`,max(`inventory_audit_details`.`facility_name`) AS `facility_name`,max(`inventory_audit_details`.`product_code`) AS `product_code`,max(`inventory_audit_details`.`transaction_number`) AS `transaction_number`,max(`inventory_audit_details`.`transaction_date`) AS `transaction_date`,sum(`inventory_audit_details`.`quantity_adjusted`) AS `quantity_adjusted`,max(`inventory_audit_details`.`price_per_unit`) AS `price_per_unit`,max(`inventory_audit_details`.`abc_class`) AS `abc_class`,case when sum(`inventory_audit_details`.`quantity_adjusted`) > 0 then 'MORE' when sum(`inventory_audit_details`.`quantity_adjusted`) < 0 then 'LESS' else 'EQUAL' end AS `variance_type_code` from `inventory_audit_details` group by `inventory_audit_details`.`facility_id`,`inventory_audit_details`.`product_id`,`inventory_audit_details`.`transaction_id` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `inventory_audit_summary`
--

/*!50001 DROP VIEW IF EXISTS `inventory_audit_summary`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb3 */;
/*!50001 SET character_set_results     = utf8mb3 */;
/*!50001 SET collation_connection      = utf8mb3_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`openboxes`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `inventory_audit_summary` AS select `inventory_audit_rollup`.`facility_id` AS `facility_id`,`inventory_audit_rollup`.`product_id` AS `product_id`,`inventory_audit_rollup`.`transaction_id` AS `transaction_id`,`inventory_audit_rollup`.`facility_name` AS `facility_name`,`inventory_audit_rollup`.`product_code` AS `product_code`,`inventory_audit_rollup`.`transaction_number` AS `transaction_number`,`inventory_audit_rollup`.`transaction_date` AS `transaction_date`,`inventory_audit_rollup`.`quantity_adjusted` AS `quantity_adjusted`,`inventory_audit_rollup`.`price_per_unit` AS `price_per_unit`,`inventory_audit_rollup`.`abc_class` AS `abc_class`,`inventory_audit_rollup`.`variance_type_code` AS `variance_type_code` from `inventory_audit_rollup` group by `inventory_audit_rollup`.`facility_id`,`inventory_audit_rollup`.`product_id` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `inventory_counts`
--

/*!50001 DROP VIEW IF EXISTS `inventory_counts`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb3 */;
/*!50001 SET character_set_results     = utf8mb3 */;
/*!50001 SET collation_connection      = utf8mb3_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`openboxes`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `inventory_counts` AS with baseline_adjustment_matches as (select `a`.`transaction_id` AS `adjustment_id`,`b`.`transaction_id` AS `baseline_id`,`a`.`product_id` AS `product_id`,`a`.`facility_id` AS `facility_id` from (`adjustment_candidate` `a` join `inventory_baseline_candidate` `b` on(`a`.`product_id` = `b`.`product_id` and `a`.`inventory_id` = `b`.`inventory_id` and timestampdiff(SECOND,`a`.`transaction_date`,`b`.`transaction_date`) = -1))), baseline_with_adjustments as (select crc32(concat(`bam`.`baseline_id`,`bam`.`product_id`,`bam`.`facility_id`)) AS `id`,`bam`.`baseline_id` AS `transaction_id`,`bam`.`product_id` AS `product_id`,`bam`.`facility_id` AS `facility_id`,`t`.`transaction_date` AS `date_recorded`,'BASELINE_ADJUSTMENT' AS `inventory_count_type_code`,`bam`.`adjustment_id` AS `associated_transaction_id` from (`baseline_adjustment_matches` `bam` join `transaction` `t` on(`bam`.`baseline_id` = `t`.`id`))), adjustment_without_baseline as (select crc32(concat(`te`.`transaction_id`,`ii`.`product_id`,`facility`.`id`)) AS `id`,`te`.`transaction_id` AS `transaction_id`,`ii`.`product_id` AS `product_id`,`facility`.`id` AS `facility_id`,`t`.`transaction_date` AS `date_recorded`,'ADJUSTMENT' AS `inventory_count_type_code`,NULL AS `associated_transaction_id` from (((`transaction_entry` `te` join `transaction` `t` on(`t`.`id` = `te`.`transaction_id`)) join `inventory_item` `ii` on(`ii`.`id` = `te`.`inventory_item_id`)) join `location` `facility` on(`facility`.`inventory_id` = `t`.`inventory_id`)) where `t`.`transaction_type_id` = '3' and !exists(select 1 from `baseline_adjustment_matches` `bam` where `bam`.`adjustment_id` = `t`.`id` and `bam`.`product_id` = `ii`.`product_id` limit 1)), baseline_without_adjustment as (select crc32(concat(`te`.`transaction_id`,`ii`.`product_id`,`facility`.`id`)) AS `id`,`te`.`transaction_id` AS `transaction_id`,`ii`.`product_id` AS `product_id`,`facility`.`id` AS `facility_id`,`t`.`transaction_date` AS `date_recorded`,'BASELINE' AS `inventory_count_type_code`,NULL AS `associated_transaction_id` from (((`transaction_entry` `te` join `transaction` `t` on(`t`.`id` = `te`.`transaction_id`)) join `inventory_item` `ii` on(`ii`.`id` = `te`.`inventory_item_id`)) join `location` `facility` on(`facility`.`inventory_id` = `t`.`inventory_id`)) where `t`.`transaction_type_id` = '12' and (`t`.`comment` <> 'Inventory baseline created during old product inventory transactions migration for products that had stock but no inventory baseline transaction as a most recent transaction' or `t`.`comment` is null) and !exists(select 1 from `baseline_adjustment_matches` `bam` where `bam`.`baseline_id` = `t`.`id` and `bam`.`product_id` = `ii`.`product_id` limit 1))select `baseline_with_adjustments`.`id` AS `id`,`baseline_with_adjustments`.`transaction_id` AS `transaction_id`,`baseline_with_adjustments`.`product_id` AS `product_id`,`baseline_with_adjustments`.`facility_id` AS `facility_id`,`baseline_with_adjustments`.`date_recorded` AS `date_recorded`,`baseline_with_adjustments`.`inventory_count_type_code` AS `inventory_count_type_code`,`baseline_with_adjustments`.`associated_transaction_id` AS `associated_transaction_id` from `baseline_with_adjustments` union select `adjustment_without_baseline`.`id` AS `id`,`adjustment_without_baseline`.`transaction_id` AS `transaction_id`,`adjustment_without_baseline`.`product_id` AS `product_id`,`adjustment_without_baseline`.`facility_id` AS `facility_id`,`adjustment_without_baseline`.`date_recorded` AS `date_recorded`,`adjustment_without_baseline`.`inventory_count_type_code` AS `inventory_count_type_code`,`adjustment_without_baseline`.`associated_transaction_id` AS `associated_transaction_id` from `adjustment_without_baseline` union select `baseline_without_adjustment`.`id` AS `id`,`baseline_without_adjustment`.`transaction_id` AS `transaction_id`,`baseline_without_adjustment`.`product_id` AS `product_id`,`baseline_without_adjustment`.`facility_id` AS `facility_id`,`baseline_without_adjustment`.`date_recorded` AS `date_recorded`,`baseline_without_adjustment`.`inventory_count_type_code` AS `inventory_count_type_code`,`baseline_without_adjustment`.`associated_transaction_id` AS `associated_transaction_id` from `baseline_without_adjustment` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `invoice_item_candidate`
--

/*!50001 DROP VIEW IF EXISTS `invoice_item_candidate`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb3 */;
/*!50001 SET character_set_results     = utf8mb3 */;
/*!50001 SET collation_connection      = utf8mb3_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`openboxes`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `invoice_item_candidate` AS (select `order_adjustment`.`id` AS `id`,`order`.`order_number` AS `order_number`,`order`.`id` AS `order_id`,'' AS `shipment_id`,'' AS `shipment_number`,`order_adjustment`.`budget_code_id` AS `budget_code_id`,coalesce(`order_item`.`gl_account_id`,`order_adjustment_type`.`gl_account_id`) AS `gl_account_id`,`product`.`product_code` AS `product_code`,`order_adjustment`.`description` AS `description`,1 AS `quantity`,1 AS `quantity_to_invoice`,`order_item`.`quantity_uom_id` AS `quantity_uom_id`,`order_item`.`unit_price` AS `unit_price`,`order_item`.`quantity_per_uom` AS `quantity_per_uom`,`order_item`.`quantity` AS `order_item_quantity`,`order`.`currency_code` AS `currency_code`,`order`.`origin_party_id` AS `vendor_id`,`order_adjustment`.`amount` AS `adjustment_amount`,`order_adjustment`.`percentage` AS `adjustment_percentage`,`product_supplier`.`supplier_code` AS `supplier_code` from ((((((`order_adjustment` join `order` on(`order_adjustment`.`order_id` = `order`.`id`)) left join `order_item` on(`order_adjustment`.`order_item_id` = `order_item`.`id`)) left join `product_supplier` on(`order_item`.`product_supplier_id` = `product_supplier`.`id`)) left join `product` on(`order_item`.`product_id` = `product`.`id`)) left join `order_adjustment_type` on(`order_adjustment`.`order_adjustment_type_id` = `order_adjustment_type`.`id`)) left join `order_adjustment_invoice` on(`order_adjustment_invoice`.`order_adjustment_id` = `order_adjustment`.`id`)) where `order_adjustment_invoice`.`invoice_item_id` is null and ifnull(`order_adjustment`.`canceled`,0) <> 1) union (select `shipment_item`.`id` AS `id`,`order`.`order_number` AS `order_number`,`order`.`id` AS `order_id`,`shipment`.`id` AS `shipment_id`,`shipment`.`shipment_number` AS `shipment_number`,`order_item`.`budget_code_id` AS `budget_code_id`,`product`.`gl_account_id` AS `gl_account_id`,`product`.`product_code` AS `product_code`,`product`.`name` AS `description`,`shipment_item`.`quantity` / `order_item`.`quantity_per_uom` - ifnull(`shipment_invoice`.`quantity`,0) AS `quantity`,`shipment_item`.`quantity` / `order_item`.`quantity_per_uom` - ifnull(`shipment_invoice`.`quantity`,0) AS `quantity_to_invoice`,`order_item`.`quantity_uom_id` AS `quantity_uom_id`,`order_item`.`unit_price` AS `unit_price`,`order_item`.`quantity_per_uom` AS `quantity_per_uom`,`order_item`.`quantity` AS `order_item_quantity`,`order`.`currency_code` AS `currency_code`,`order`.`origin_party_id` AS `vendor_id`,NULL AS `adjustment_amount`,NULL AS `adjustment_percentage`,`product_supplier`.`supplier_code` AS `supplier_code` from ((((((((`shipment_item` join `shipment` on(`shipment_item`.`shipment_id` = `shipment`.`id`)) join `product` on(`shipment_item`.`product_id` = `product`.`id`)) join `order_shipment` on(`order_shipment`.`shipment_item_id` = `shipment_item`.`id`)) join `order_item` on(`order_shipment`.`order_item_id` = `order_item`.`id`)) left join `product_supplier` on(`order_item`.`product_supplier_id` = `product_supplier`.`id`)) join `order` on(`order_item`.`order_id` = `order`.`id`)) left join `order_invoice` on(`order_invoice`.`order_item_id` = `order_item`.`id`)) left join (select `shipment_invoice`.`shipment_item_id` AS `shipment_item_id`,ifnull(sum(`invoice_item`.`quantity`),0) AS `quantity` from (`shipment_invoice` left join `invoice_item` on(`shipment_invoice`.`invoice_item_id` = `invoice_item`.`id`)) group by `shipment_invoice`.`shipment_item_id`) `shipment_invoice` on(`shipment_invoice`.`shipment_item_id` = `shipment_item`.`id`)) where `order_invoice`.`invoice_item_id` is null and ifnull(`shipment_invoice`.`quantity`,0) < `shipment_item`.`quantity` / `order_item`.`quantity_per_uom` and `shipment`.`current_status` in ('SHIPPED','PARTIALLY_RECEIVED','RECEIVED')) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `invoice_list`
--

/*!50001 DROP VIEW IF EXISTS `invoice_list`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb3 */;
/*!50001 SET character_set_results     = utf8mb3 */;
/*!50001 SET collation_connection      = utf8mb3_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`openboxes`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `invoice_list` AS (select `invoice`.`id` AS `invoice_id`,`invoice`.`invoice_number` AS `invoice_number`,ifnull(`reference_number`.`identifier`,'') AS `vendor_invoice_number`,`invoice`.`party_from_id` AS `party_from_id`,`invoice`.`party_id` AS `party_id`,`party`.`code` AS `party_code`,`party`.`name` AS `party_name`,if(`invoice_type`.`code` is not null,`invoice_type`.`code`,'INVOICE') AS `invoice_type_code`,case when `invoice`.`date_paid` is not null then 'PAID' when `invoice`.`date_posted` is not null then 'POSTED' when `invoice`.`date_submitted` is not null then 'SUBMITTED' else 'PENDING' end AS `status`,`unit_of_measure`.`name` AS `currency`,count(`invoice_item`.`id`) AS `item_count`,`invoice`.`date_invoiced` AS `date_invoiced`,`invoice`.`date_created` AS `date_created`,`person`.`id` AS `created_by_id`,concat(`person`.`first_name`,' ',`person`.`last_name`) AS `created_by_name` from (((((((`invoice` left join `invoice_item` on(`invoice_item`.`invoice_id` = `invoice`.`id`)) left join `unit_of_measure` on(`unit_of_measure`.`id` = `invoice`.`currency_uom_id`)) left join `person` on(`person`.`id` = `invoice`.`created_by_id`)) left join `invoice_reference_number` on(`invoice_reference_number`.`invoice_reference_numbers_id` = `invoice`.`id`)) left join `reference_number` on(`invoice_reference_number`.`reference_number_id` = `reference_number`.`id` and `reference_number`.`reference_number_type_id` = 'VENDOR_INVOICE_NUMBER')) left join `party` on(`invoice`.`party_id` = `party`.`id`)) left join `invoice_type` on(`invoice`.`invoice_type_id` = `invoice_type`.`id`)) where `invoice_item`.`inverse` is false group by `invoice`.`id`,`reference_number`.`id`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `latest_transaction_per_cycle_count`
--

/*!50001 DROP VIEW IF EXISTS `latest_transaction_per_cycle_count`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb3 */;
/*!50001 SET character_set_results     = utf8mb3 */;
/*!50001 SET collation_connection      = utf8mb3_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`openboxes`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `latest_transaction_per_cycle_count` AS select `transaction`.`cycle_count_id` AS `cycle_count_id`,max(`transaction`.`transaction_date`) AS `latest_transaction_date` from `transaction` where `transaction`.`cycle_count_id` is not null group by `transaction`.`cycle_count_id` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `on_order_order_item_summary`
--

/*!50001 DROP VIEW IF EXISTS `on_order_order_item_summary`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb3 */;
/*!50001 SET character_set_results     = utf8mb3 */;
/*!50001 SET collation_connection      = utf8mb3_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`openboxes`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `on_order_order_item_summary` AS (select `a`.`product_id` AS `product_id`,`a`.`destination_id` AS `destination_id`,ifnull(sum(case when `a`.`quantity_ordered` - `a`.`quantity_shipped` > 0 then `a`.`quantity_ordered` - `a`.`quantity_shipped` else 0 end),0) AS `quantity_ordered_not_shipped`,NULL AS `quantity_shipped_not_received` from (select `product`.`id` AS `product_id`,`order_item`.`id` AS `id`,`order`.`destination_id` AS `destination_id`,sum(distinct case when `order`.`status` <> 'PENDING' then `order_item`.`quantity` * `order_item`.`quantity_per_uom` else 0 end) AS `quantity_ordered`,sum(case when `shipment_item`.`quantity` <> 0 and `shipment`.`current_status` in ('SHIPPED','PARTIALLY_RECEIVED','RECEIVED') then `shipment_item`.`quantity` else 0 end) AS `quantity_shipped`,NULL AS `quantity_shipped_not_received` from (((((`order_item` join `product` on(`order_item`.`product_id` = `product`.`id`)) join `order` on(`order_item`.`order_id` = `order`.`id`)) left join `order_shipment` on(`order_shipment`.`order_item_id` = `order_item`.`id`)) left join `shipment_item` on(`order_shipment`.`shipment_item_id` = `shipment_item`.`id`)) left join `shipment` on(`shipment_item`.`shipment_id` = `shipment`.`id`)) where `order`.`order_type_id` = 'PURCHASE_ORDER' and `order_item`.`order_item_status_code` <> 'CANCELED' group by `product`.`product_code`,`order_item`.`id`,`product`.`name`,`order`.`destination_id`) `a` group by `a`.`product_id`,`a`.`destination_id`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `on_order_shipment_item_summary`
--

/*!50001 DROP VIEW IF EXISTS `on_order_shipment_item_summary`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb3 */;
/*!50001 SET character_set_results     = utf8mb3 */;
/*!50001 SET collation_connection      = utf8mb3_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`openboxes`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `on_order_shipment_item_summary` AS (select `c`.`product_id` AS `product_id`,`c`.`destination_id` AS `destination_id`,NULL AS `quantity_ordered_not_shipped`,ifnull(sum(`c`.`quantity_shipped`) - (sum(`c`.`quantity_received`) + sum(`c`.`quantity_canceled`)),0) AS `quantity_shipped_not_received` from (select `product`.`id` AS `product_id`,`shipment_item`.`id` AS `id`,`shipment`.`destination_id` AS `destination_id`,sum(distinct `shipment_item`.`quantity`) AS `quantity_shipped`,sum(case when `receipt`.`receipt_status_code` = 'RECEIVED' then `receipt_item`.`quantity_received` else 0 end) AS `quantity_received`,sum(case when `receipt`.`receipt_status_code` = 'RECEIVED' and `receipt_item`.`quantity_canceled` <> 0 then `receipt_item`.`quantity_canceled` else 0 end) AS `quantity_canceled` from ((((((`shipment_item` join `product` on(`product`.`id` = `shipment_item`.`product_id`)) join `shipment` on(`shipment`.`id` = `shipment_item`.`shipment_id`)) join `location` on(`location`.`id` = `shipment`.`destination_id`)) join `location_type` on(`location`.`location_type_id` = `location_type`.`id`)) left join `receipt_item` on(`shipment_item`.`id` = `receipt_item`.`shipment_item_id`)) left join `receipt` on(`receipt`.`id` = `receipt_item`.`receipt_id`)) where `shipment`.`current_status` in (NULL,'SHIPPED','PARTIALLY_RECEIVED') and `location_type`.`location_type_code` = 'DEPOT' group by `product`.`id`,`shipment_item`.`id`,`shipment`.`destination_id`) `c` where `c`.`quantity_received` + `c`.`quantity_canceled` < `c`.`quantity_shipped` group by `c`.`product_id`,`c`.`destination_id`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `on_order_summary`
--

/*!50001 DROP VIEW IF EXISTS `on_order_summary`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb3 */;
/*!50001 SET character_set_results     = utf8mb3 */;
/*!50001 SET collation_connection      = utf8mb3_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`openboxes`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `on_order_summary` AS (select `a`.`product_id` AS `product_id`,`a`.`destination_id` AS `destination_id`,`a`.`quantity_ordered_not_shipped` AS `quantity_ordered_not_shipped`,`b`.`quantity_shipped_not_received` AS `quantity_shipped_not_received` from (`on_order_order_item_summary` `a` left join `on_order_shipment_item_summary` `b` on(`a`.`product_id` = `b`.`product_id` and `a`.`destination_id` = `b`.`destination_id`))) union (select `b`.`product_id` AS `product_id`,`b`.`destination_id` AS `destination_id`,`a`.`quantity_ordered_not_shipped` AS `quantity_ordered_not_shipped`,`b`.`quantity_shipped_not_received` AS `quantity_shipped_not_received` from (`on_order_shipment_item_summary` `b` left join `on_order_order_item_summary` `a` on(`b`.`product_id` = `a`.`product_id` and `b`.`destination_id` = `a`.`destination_id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `order_adjustment_details`
--

/*!50001 DROP VIEW IF EXISTS `order_adjustment_details`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb3 */;
/*!50001 SET character_set_results     = utf8mb3 */;
/*!50001 SET collation_connection      = utf8mb3_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`openboxes`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `order_adjustment_details` AS select `order_adjustment_details`.`id` AS `id`,`order_adjustment_details`.`total_adjustment` AS `total_adjustment` from (select `order_adjustment`.`id` AS `id`,sum(distinct abs(ifnull(`order_adjustment`.`amount`,if(`order_adjustment`.`percentage` is not null,if(`order_adjustment`.`order_item_id` is not null,`order_item`.`quantity` * `order_item`.`unit_price` * (`order_adjustment`.`percentage` / 100),`order_total`.`order_total` * (`order_adjustment`.`percentage` / 100)),0)))) AS `total_adjustment` from ((`order_adjustment` left join `order_item` on(`order_adjustment`.`order_item_id` = `order_item`.`id`)) left join (select `oi`.`order_id` AS `order_id`,sum(`oi`.`quantity` * `oi`.`unit_price`) AS `order_total` from (`order_item` `oi` left join `order` `o` on(`o`.`id` = `oi`.`order_id`)) group by `oi`.`order_id`) `order_total` on(`order_adjustment`.`order_id` = `order_total`.`order_id`)) where `order_adjustment`.`canceled` is not true group by `order_adjustment`.`id`) `order_adjustment_details` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `order_adjustment_payment_status`
--

/*!50001 DROP VIEW IF EXISTS `order_adjustment_payment_status`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb3 */;
/*!50001 SET character_set_results     = utf8mb3 */;
/*!50001 SET collation_connection      = utf8mb3_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`openboxes`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `order_adjustment_payment_status` AS select `order_adjustment_payment_status`.`order_id` AS `order_id`,`order_adjustment_payment_status`.`order_number` AS `order_number`,`order_adjustment_payment_status`.`adjustment_id` AS `adjustment_id`,`order_adjustment_payment_status`.`invoice_item_id` AS `invoice_item_id`,`order_adjustment_payment_status`.`order_status` AS `order_status`,`order_adjustment_payment_status`.`quantity_invoiced` AS `quantity_invoiced`,`order_adjustment_payment_status`.`invoice_item_amount` AS `invoiced_amount` from (select `order`.`id` AS `order_id`,`order_adjustment`.`id` AS `adjustment_id`,if(`invoice`.`date_posted` is null,0,`invoice_item`.`amount`) AS `invoice_item_amount`,`order`.`order_number` AS `order_number`,`order`.`status` AS `order_status`,`invoice_item`.`id` AS `invoice_item_id`,case when `invoice`.`date_posted` is not null then ifnull(`invoice_item`.`quantity`,0) else 0 end AS `quantity_invoiced` from ((((`order` left join `order_adjustment` on(`order_adjustment`.`order_id` = `order`.`id`)) join `order_adjustment_invoice` on(`order_adjustment_invoice`.`order_adjustment_id` = `order_adjustment`.`id`)) left join `invoice_item` on(`invoice_item`.`id` = `order_adjustment_invoice`.`invoice_item_id`)) left join `invoice` on(`invoice`.`id` = `invoice_item`.`invoice_id`)) where `order`.`order_type_id` = 'PURCHASE_ORDER' and (`invoice`.`invoice_type_id` <> '5' or `invoice`.`invoice_type_id` is null) and (`invoice_item`.`inverse` is null or `invoice_item`.`inverse` = 0) and `order_adjustment`.`canceled` <> 1 group by `order`.`id`,`order`.`order_number`,`invoice_item`.`id`,`order_adjustment`.`id`) `order_adjustment_payment_status` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `order_item_details`
--

/*!50001 DROP VIEW IF EXISTS `order_item_details`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb3 */;
/*!50001 SET character_set_results     = utf8mb3 */;
/*!50001 SET collation_connection      = utf8mb3_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`openboxes`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `order_item_details` AS (select `o_i`.`id` AS `id`,`o_i`.`id` AS `order_item_id`,`o`.`id` AS `order_id`,`o`.`order_number` AS `order_number`,`o_i`.`product_id` AS `product_id`,`o_i`.`quantity` AS `quantity`,`o_i`.`order_item_status_code` AS `order_item_status`,`o_i`.`quantity_uom_id` AS `quantity_uom_id`,`o_i`.`quantity_per_uom` AS `quantity_per_uom`,`o_i`.`unit_price` AS `unit_price` from (`order_item` `o_i` join `order` `o` on(`o`.`id` = `o_i`.`order_id`)) where `o`.`order_type_id` = 'PURCHASE_ORDER' and `o_i`.`order_item_status_code` <> 'CANCELLED') */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `order_item_payment_status`
--

/*!50001 DROP VIEW IF EXISTS `order_item_payment_status`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb3 */;
/*!50001 SET character_set_results     = utf8mb3 */;
/*!50001 SET collation_connection      = utf8mb3_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`openboxes`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `order_item_payment_status` AS select `order_item_payment_status`.`order_id` AS `order_id`,`order_item_payment_status`.`order_number` AS `order_number`,`order_item_payment_status`.`order_item_id` AS `order_item_id`,ifnull(sum(`order_item_payment_status`.`quantity_ordered`),0) AS `quantity_ordered`,ifnull(sum(`order_item_payment_status`.`quantity_invoiced`),0) AS `quantity_invoiced` from (select `order_item`.`id` AS `order_item_id`,`order`.`id` AS `order_id`,`order`.`order_number` AS `order_number`,`order_item`.`quantity` AS `quantity_ordered`,sum(`invoice_item`.`quantity`) AS `quantity_invoiced` from ((((((`order` left join `order_item` on(`order`.`id` = `order_item`.`order_id`)) left join `order_shipment` on(`order_item`.`id` = `order_shipment`.`order_item_id`)) left join `shipment_item` on(`shipment_item`.`id` = `order_shipment`.`shipment_item_id`)) left join `shipment_invoice` on(`shipment_invoice`.`shipment_item_id` = `shipment_item`.`id`)) left join `invoice_item` on(`invoice_item`.`id` = `shipment_invoice`.`invoice_item_id`)) left join `invoice` on(`invoice`.`id` = `invoice_item`.`invoice_id`)) where `order`.`order_type_id` = 'PURCHASE_ORDER' and `order_item`.`order_item_status_code` <> 'CANCELLED' and (`invoice`.`invoice_type_id` <> '5' or `invoice`.`invoice_type_id` is null) and `invoice`.`date_posted` is not null and (`invoice_item`.`inverse` is null or `invoice_item`.`inverse` = 0) group by `order`.`id`,`order_item`.`id`,`invoice_item`.`id`,`shipment_item`.`id`) `order_item_payment_status` group by `order_item_payment_status`.`order_item_id` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `order_item_status`
--

/*!50001 DROP VIEW IF EXISTS `order_item_status`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb3 */;
/*!50001 SET character_set_results     = utf8mb3 */;
/*!50001 SET collation_connection      = utf8mb3_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`openboxes`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `order_item_status` AS select `order_item_status`.`order_id` AS `order_id`,`order_item_status`.`order_number` AS `order_number`,ifnull(max(`order_item_status`.`quantity_ordered`),0) AS `quantity_ordered`,ifnull(sum(`order_item_status`.`quantity_shipped`),0) AS `quantity_shipped`,`order_item_status`.`order_item_id` AS `order_item_id` from (select `order`.`id` AS `order_id`,`order`.`order_number` AS `order_number`,`order_item`.`id` AS `order_item_id`,case when `order_item`.`order_item_status_code` = 'CANCELED' then 0 else ifnull(max(`order_item`.`quantity`),0) end AS `quantity_ordered`,case when `shipment`.`current_status` in ('SHIPPED','PARTIALLY_RECEIVED','RECEIVED') then sum(`shipment_item`.`quantity` / `order_item`.`quantity_per_uom`) else 0 end AS `quantity_shipped` from ((((`order` left join `order_item` on(`order`.`id` = `order_item`.`order_id`)) left join `order_shipment` on(`order_item`.`id` = `order_shipment`.`order_item_id`)) left join `shipment_item` on(`shipment_item`.`id` = `order_shipment`.`shipment_item_id`)) left join `shipment` on(`shipment`.`id` = `shipment_item`.`shipment_id`)) where `order`.`order_type_id` = 'PURCHASE_ORDER' group by `order`.`id`,`order_item`.`id`,`shipment`.`id`) `order_item_status` group by `order_item_status`.`order_id`,`order_item_status`.`order_item_id` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `order_item_summary`
--

/*!50001 DROP VIEW IF EXISTS `order_item_summary`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb3 */;
/*!50001 SET character_set_results     = utf8mb3 */;
/*!50001 SET collation_connection      = utf8mb3_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`openboxes`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `order_item_summary` AS (select `order_item_summary`.`order_item_id` AS `id`,`order_item_summary`.`order_id` AS `order_id`,`order_item_summary`.`order_number` AS `order_number`,`order_item_summary`.`product_id` AS `product_id`,`order_item_summary`.`quantity` AS `quantity`,`order_item_summary`.`order_item_status` AS `order_item_status`,`order_item_summary`.`quantity_uom_id` AS `quantity_uom_id`,`order_item_summary`.`quantity_per_uom` AS `quantity_per_uom`,`order_item_summary`.`unit_price` AS `unit_price`,`order_item_summary`.`quantity_ordered` AS `quantity_ordered`,`order_item_summary`.`quantity_shipped` AS `quantity_shipped`,`order_item_summary`.`quantity_received` AS `quantity_received`,`order_item_summary`.`quantity_canceled` AS `quantity_canceled`,`order_item_summary`.`quantity_invoiced` AS `quantity_invoiced`,if(`order_item_summary`.`quantity_ordered` > 0,1,0) AS `is_item_fully_ordered`,if(`order_item_summary`.`quantity_shipped` > 0 and `order_item_summary`.`quantity_shipped` = `order_item_summary`.`quantity_ordered`,1,0) AS `is_item_fully_shipped`,if(`order_item_summary`.`quantity_received` + `order_item_summary`.`quantity_canceled` > 0 and `order_item_summary`.`quantity_received` + `order_item_summary`.`quantity_canceled` = `order_item_summary`.`quantity_ordered`,1,0) AS `is_item_fully_received`,if(`order_item_summary`.`quantity_invoiced` > 0 and `order_item_summary`.`quantity_invoiced` = `order_item_summary`.`quantity_ordered`,1,0) AS `is_item_fully_invoiced`,coalesce(`order_item_summary`.`payment_status`,`order_item_summary`.`receipt_status`,`order_item_summary`.`shipment_status`,`order_item_summary`.`order_item_status`,`order_item_summary`.`order_status`) AS `derived_status` from (select `order_item`.`id` AS `order_item_id`,`order`.`id` AS `order_id`,`order`.`order_number` AS `order_number`,`order`.`status` AS `order_status`,`order_item`.`product_id` AS `product_id`,`order_item`.`quantity` AS `quantity`,`order_item`.`order_item_status_code` AS `order_item_status`,`order_item`.`quantity_uom_id` AS `quantity_uom_id`,`order_item`.`quantity_per_uom` AS `quantity_per_uom`,`order_item`.`unit_price` AS `unit_price`,ifnull(sum(`order_item_status`.`quantity_ordered`),0) AS `quantity_ordered`,ifnull(sum(`order_item_status`.`quantity_shipped`),0) AS `quantity_shipped`,ifnull(sum(`order_receipt_status`.`quantity_received`),0) AS `quantity_received`,ifnull(sum(`order_receipt_status`.`quantity_canceled`),0) AS `quantity_canceled`,ifnull(sum(`order_item_payment_status`.`quantity_invoiced`),0) AS `quantity_invoiced`,case when sum(`order_item_status`.`quantity_ordered`) + sum(`order_item_status`.`quantity_shipped`) = 0 then NULL when sum(`order_item_status`.`quantity_ordered`) = sum(`order_item_status`.`quantity_shipped`) then 'SHIPPED' when sum(`order_item_status`.`quantity_ordered`) > 0 and sum(`order_item_status`.`quantity_shipped`) > 0 then 'PARTIALLY_SHIPPED' else NULL end AS `shipment_status`,case when sum(`order_receipt_status`.`quantity_received`) = 0 then NULL when sum(`order_item_status`.`quantity_ordered`) - sum(`order_receipt_status`.`quantity_canceled`) <= sum(`order_receipt_status`.`quantity_received`) then 'RECEIVED' when sum(`order_item_status`.`quantity_ordered`) - sum(`order_receipt_status`.`quantity_canceled`) > sum(`order_receipt_status`.`quantity_received`) and sum(`order_receipt_status`.`quantity_received`) > 0 then 'PARTIALLY_RECEIVED' else NULL end AS `receipt_status`,case when sum(`order_item_status`.`quantity_ordered`) + sum(`order_item_payment_status`.`quantity_invoiced`) = 0 then NULL when sum(`order_item_status`.`quantity_ordered`) = sum(`order_item_payment_status`.`quantity_invoiced`) then 'INVOICED' when sum(`order_item_status`.`quantity_ordered`) > sum(`order_item_payment_status`.`quantity_invoiced`) and sum(`order_item_payment_status`.`quantity_invoiced`) > 0 then 'PARTIALLY_INVOICED' else NULL end AS `payment_status` from ((((`order_item` join `order` on(`order_item`.`order_id` = `order`.`id`)) left join `order_item_status` on(`order_item_status`.`order_item_id` = `order_item`.`id`)) left join `order_receipt_status` on(`order_receipt_status`.`order_item_id` = `order_item`.`id`)) left join `order_item_payment_status` on(`order_item_payment_status`.`order_item_id` = `order_item`.`id`)) where `order`.`order_type_id` = 'PURCHASE_ORDER' group by `order_item`.`id`) `order_item_summary`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `order_receipt_status`
--

/*!50001 DROP VIEW IF EXISTS `order_receipt_status`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb3 */;
/*!50001 SET character_set_results     = utf8mb3 */;
/*!50001 SET collation_connection      = utf8mb3_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`openboxes`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `order_receipt_status` AS select `order_receipt_status`.`order_id` AS `order_id`,`order_receipt_status`.`order_item_id` AS `order_item_id`,`order_receipt_status`.`order_number` AS `order_number`,ifnull(sum(`order_receipt_status`.`quantity_received`),0) AS `quantity_received`,ifnull(sum(`order_receipt_status`.`quantity_canceled`),0) AS `quantity_canceled` from (select `order`.`id` AS `order_id`,`order`.`order_number` AS `order_number`,`order_item`.`id` AS `order_item_id`,sum(`receipt_item`.`quantity_received` / `order_item`.`quantity_per_uom`) AS `quantity_received`,sum(`receipt_item`.`quantity_canceled` / `order_item`.`quantity_per_uom`) AS `quantity_canceled` from (((((`order` left join `order_item` on(`order`.`id` = `order_item`.`order_id`)) left join `order_shipment` on(`order_item`.`id` = `order_shipment`.`order_item_id`)) left join `shipment_item` on(`shipment_item`.`id` = `order_shipment`.`shipment_item_id`)) left join `shipment` on(`shipment`.`id` = `shipment_item`.`shipment_id`)) left join `receipt_item` on(`receipt_item`.`shipment_item_id` = `shipment_item`.`id`)) where `order`.`order_type_id` = 'PURCHASE_ORDER' and `order_item`.`order_item_status_code` <> 'CANCELLED' and `shipment`.`current_status` = 'RECEIVED' or `shipment`.`current_status` = 'PARTIALLY_RECEIVED' group by `order`.`id`,`order`.`order_number`,`order_item`.`id`,`shipment`.`id`) `order_receipt_status` group by `order_receipt_status`.`order_item_id` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `order_summary`
--

/*!50001 DROP VIEW IF EXISTS `order_summary`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb3 */;
/*!50001 SET character_set_results     = utf8mb3 */;
/*!50001 SET collation_connection      = utf8mb3_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`openboxes`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `order_summary` AS (select `order_summary`.`id` AS `id`,`order_summary`.`id` AS `order_id`,`order_summary`.`quantity_ordered` AS `quantity_ordered`,`order_summary`.`adjustments_count` AS `adjustments_count`,`order_summary`.`quantity_shipped` AS `quantity_shipped`,`order_summary`.`quantity_received` AS `quantity_received`,`order_summary`.`quantity_canceled` AS `quantity_canceled`,`order_summary`.`quantity_invoiced` AS `quantity_invoiced`,`order_summary`.`adjustments_invoiced` AS `adjustments_invoiced`,`order_summary`.`items_ordered` AS `items_ordered`,`order_summary`.`items_shipped` AS `items_shipped`,`order_summary`.`items_received` AS `items_received`,`order_summary`.`items_invoiced` AS `items_invoiced`,`order_summary`.`order_status` AS `order_status`,`order_summary`.`shipment_status` AS `shipment_status`,`order_summary`.`receipt_status` AS `receipt_status`,`order_summary`.`payment_status` AS `payment_status`,case when `order_summary`.`shipment_status` = 'SHIPPED' and `order_summary`.`receipt_status` = 'RECEIVED' and `order_summary`.`payment_status` = 'INVOICED' then 'COMPLETED' else coalesce(`order_summary`.`payment_status`,`order_summary`.`receipt_status`,`order_summary`.`shipment_status`,`order_summary`.`order_status`) end AS `derived_status` from (select `items_and_adjustments_union`.`id` AS `id`,`items_and_adjustments_union`.`order_status` AS `order_status`,sum(`items_and_adjustments_union`.`quantity_ordered`) AS `quantity_ordered`,sum(`items_and_adjustments_union`.`adjustments_count`) AS `adjustments_count`,sum(`items_and_adjustments_union`.`quantity_shipped`) AS `quantity_shipped`,sum(`items_and_adjustments_union`.`quantity_received`) AS `quantity_received`,sum(`items_and_adjustments_union`.`quantity_canceled`) AS `quantity_canceled`,sum(`items_and_adjustments_union`.`quantity_invoiced`) AS `quantity_invoiced`,sum(`items_and_adjustments_union`.`items_ordered`) AS `items_ordered`,sum(`items_and_adjustments_union`.`items_shipped`) AS `items_shipped`,sum(`items_and_adjustments_union`.`items_received`) AS `items_received`,sum(`items_and_adjustments_union`.`items_invoiced`) AS `items_invoiced`,sum(`items_and_adjustments_union`.`adjustments_invoiced`) AS `adjustments_invoiced`,case when sum(`items_and_adjustments_union`.`quantity_ordered`) + sum(`items_and_adjustments_union`.`quantity_shipped`) = 0 then NULL when sum(`items_and_adjustments_union`.`quantity_ordered`) = sum(`items_and_adjustments_union`.`quantity_shipped`) then 'SHIPPED' when sum(`items_and_adjustments_union`.`quantity_ordered`) > 0 and sum(`items_and_adjustments_union`.`quantity_shipped`) > 0 then 'PARTIALLY_SHIPPED' else NULL end AS `shipment_status`,case when sum(`items_and_adjustments_union`.`quantity_received`) = 0 then NULL when sum(`items_and_adjustments_union`.`quantity_ordered`) - sum(`items_and_adjustments_union`.`quantity_canceled`) > sum(`items_and_adjustments_union`.`quantity_received`) and sum(`items_and_adjustments_union`.`quantity_received`) > 0 then 'PARTIALLY_RECEIVED' when sum(`items_and_adjustments_union`.`quantity_ordered`) - sum(`items_and_adjustments_union`.`quantity_canceled`) <= sum(`items_and_adjustments_union`.`quantity_received`) then 'RECEIVED' else NULL end AS `receipt_status`,case when sum(`items_and_adjustments_union`.`quantity_ordered`) = 0 and sum(`items_and_adjustments_union`.`adjustments_count`) = 0 or sum(`items_and_adjustments_union`.`quantity_invoiced`) = 0 and sum(`items_and_adjustments_union`.`adjustments_invoiced`) = 0 then NULL when sum(`items_and_adjustments_union`.`quantity_ordered`) = sum(`items_and_adjustments_union`.`quantity_invoiced`) and sum(`items_and_adjustments_union`.`adjustments_count`) = sum(`items_and_adjustments_union`.`adjustments_invoiced`) and sum(`items_and_adjustments_union`.`total_adjustments`) = sum(`items_and_adjustments_union`.`invoiced_adjustments_amount`) then 'INVOICED' else 'PARTIALLY_INVOICED' end AS `payment_status` from (select `order`.`id` AS `id`,`order`.`status` AS `order_status`,ifnull(sum(`order_item_summary`.`quantity_ordered`),0) AS `quantity_ordered`,sum(`order_item_summary`.`is_item_fully_ordered`) AS `items_ordered`,0 AS `adjustments_count`,ifnull(sum(`order_item_summary`.`quantity_shipped`),0) AS `quantity_shipped`,sum(`order_item_summary`.`is_item_fully_shipped`) AS `items_shipped`,ifnull(sum(`order_item_summary`.`quantity_received`),0) AS `quantity_received`,sum(`order_item_summary`.`is_item_fully_received`) AS `items_received`,ifnull(sum(`order_item_summary`.`quantity_canceled`),0) AS `quantity_canceled`,ifnull(sum(`order_item_summary`.`quantity_invoiced`),0) AS `quantity_invoiced`,sum(`order_item_summary`.`is_item_fully_invoiced`) AS `items_invoiced`,0 AS `adjustments_invoiced`,0 AS `total_adjustments`,0 AS `invoiced_adjustments_amount` from ((`order` left join `order_item` on(`order_item`.`order_id` = `order`.`id`)) left join `order_item_summary` on(`order_item_summary`.`id` = `order_item`.`id`)) where `order`.`order_type_id` = 'PURCHASE_ORDER' group by `order`.`id` union select `order`.`id` AS `id`,`order`.`status` AS `order_status`,0 AS `quantity_ordered`,0 AS `items_ordered`,ifnull(count(distinct `order_adjustment`.`id`),0) AS `adjustments_count`,0 AS `quantity_shipped`,0 AS `items_shipped`,0 AS `quantity_received`,0 AS `items_received`,0 AS `quantity_canceled`,0 AS `quantity_invoiced`,0 AS `items_invoiced`,ifnull(sum(`order_adjustment_payment_statuses`.`quantity_invoiced`),0) AS `adjustments_invoiced`,sum(distinct `total_adjustments`.`total_adjustments`) AS `total_adjustments`,ifnull(sum(abs(`order_adjustment_payment_statuses`.`invoiced_amount`)),0) AS `invoiced_adjustments_amount` from (((`order` left join `order_adjustment` on(`order_adjustment`.`order_id` = `order`.`id`)) left join (select `order_adjustment_payment_status`.`adjustment_id` AS `adjustment_id`,sum(`order_adjustment_payment_status`.`invoiced_amount`) AS `invoiced_amount`,if(sum(`order_adjustment_payment_status`.`quantity_invoiced`) > 0,1,0) AS `quantity_invoiced` from `order_adjustment_payment_status` group by `order_adjustment_payment_status`.`adjustment_id`) `order_adjustment_payment_statuses` on(`order_adjustment_payment_statuses`.`adjustment_id` = `order_adjustment`.`id`)) left join (select `amount_per_order_by_adjustment`.`order_id` AS `order_id`,sum(`amount_per_order_by_adjustment`.`total_adjustment`) AS `total_adjustments` from (select `order`.`id` AS `order_id`,`order_adjustment`.`id` AS `order_adjustment_id`,sum(distinct abs(ifnull(`order_adjustment`.`amount`,if(`order_adjustment`.`percentage` is not null,if(`order_adjustment`.`order_item_id` is not null,`order_item`.`quantity` * `order_item`.`unit_price` * (`order_adjustment`.`percentage` / 100),`order_total`.`order_total` * (`order_adjustment`.`percentage` / 100)),0)))) AS `total_adjustment` from ((((`order` left join `order_adjustment` on(`order_adjustment`.`order_id` = `order`.`id`)) left join `order_adjustment_payment_status` on(`order_adjustment_payment_status`.`adjustment_id` = `order_adjustment`.`id`)) left join `order_item` on(`order_adjustment`.`order_item_id` = `order_item`.`id`)) left join (select `oi`.`order_id` AS `order_id`,sum(`oi`.`quantity` * `oi`.`unit_price`) AS `order_total` from (`order_item` `oi` left join `order` `o` on(`o`.`id` = `oi`.`order_id`)) group by `oi`.`order_id`) `order_total` on(`order`.`id` = `order_total`.`order_id`)) where `order_adjustment`.`canceled` is not true group by `order_adjustment`.`id`,`order`.`id`) `amount_per_order_by_adjustment` group by `amount_per_order_by_adjustment`.`order_id`) `total_adjustments` on(`total_adjustments`.`order_id` = `order`.`id`)) where `order`.`order_type_id` = 'PURCHASE_ORDER' and `order_adjustment`.`canceled` is not true group by `order`.`id`) `items_and_adjustments_union` group by `items_and_adjustments_union`.`id`,`items_and_adjustments_union`.`order_status`) `order_summary`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `pending_cycle_count_request`
--

/*!50001 DROP VIEW IF EXISTS `pending_cycle_count_request`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb3 */;
/*!50001 SET character_set_results     = utf8mb3 */;
/*!50001 SET collation_connection      = utf8mb3_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`openboxes`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `pending_cycle_count_request` AS (select crc32(concat(`pa`.`location_id`,`pa`.`product_id`)) AS `id`,`ccr`.`id` AS `cycle_count_request_id`,`ccr`.`facility_id` AS `facility_id`,`ccr`.`product_id` AS `product_id`,coalesce(`cc`.`status`,`ccr`.`status`) AS `status`,`ccr`.`request_type` AS `request_type`,`ccr`.`blind_count` AS `blind_count`,`ccr`.`date_created` AS `date_created`,`ccr`.`last_updated` AS `last_updated`,`ccr`.`created_by_id` AS `created_by_id`,`ccr`.`updated_by_id` AS `updated_by_id`,`product_classification`.`abc_class` AS `abc_class`,sum(`pa`.`quantity_on_hand`) AS `quantity_on_hand`,sum(`pa`.`quantity_allocated`) AS `quantity_allocated`,sum(case when `pa`.`quantity_on_hand` < 0 then 1 else 0 end) AS `negative_item_count`,group_concat(distinct if(`pa`.`quantity_on_hand` <> 0,concat_ws(': ',`zone`.`name`,`pa`.`bin_location_name`),NULL) separator ',') AS `internal_locations` from (((((((`cycle_count_request` `ccr` left join `product_availability` `pa` on(`ccr`.`product_id` = `pa`.`product_id` and `ccr`.`facility_id` = `pa`.`location_id`)) left join `cycle_count` `cc` on(`ccr`.`cycle_count_id` = `cc`.`id`)) join `location` `facility` on(`pa`.`location_id` = `facility`.`id`)) left join `location` `bin_location` on(`pa`.`bin_location_id` = `bin_location`.`id`)) left join `location` `zone` on(`bin_location`.`zone_id` = `zone`.`id`)) left join `product_classification` on(`pa`.`product_id` = `product_classification`.`product_id` and `facility`.`inventory_id` = `product_classification`.`inventory_id`)) join `product` on(`ccr`.`product_id` = `product`.`id`)) where `product`.`active` <> 0 group by `ccr`.`id`,`ccr`.`facility_id`,`ccr`.`product_id`,coalesce(`cc`.`status`,`ccr`.`status`),`ccr`.`cycle_count_id`,`ccr`.`request_type`,`ccr`.`blind_count`,`ccr`.`date_created`,`ccr`.`last_updated`,`ccr`.`created_by_id`,`ccr`.`updated_by_id`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `product_classification`
--

/*!50001 DROP VIEW IF EXISTS `product_classification`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb3 */;
/*!50001 SET character_set_results     = utf8mb3 */;
/*!50001 SET collation_connection      = utf8mb3_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`openboxes`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `product_classification` AS (select `inventory_level`.`inventory_id` AS `inventory_id`,`inventory_level`.`product_id` AS `product_id`,min(coalesce(`inventory_level`.`abc_class`,`product`.`abc_class`,NULL)) AS `abc_class` from (`inventory_level` join `product` on(`inventory_level`.`product_id` = `product`.`id`)) where `inventory_level`.`internal_location_id` is null group by `inventory_level`.`inventory_id`,`inventory_level`.`product_id`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `product_count_history`
--

/*!50001 DROP VIEW IF EXISTS `product_count_history`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb3 */;
/*!50001 SET character_set_results     = utf8mb3 */;
/*!50001 SET collation_connection      = utf8mb3_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`openboxes`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `product_count_history` AS (select `inventory_level_summary_unions`.`inventory_id` AS `inventory_id`,`inventory_level_summary_unions`.`product_id` AS `product_id`,max(`inventory_level_summary_unions`.`date_counted`) AS `date_counted` from (select `product_cycle_count_history`.`inventory_id` AS `inventory_id`,`product_cycle_count_history`.`product_id` AS `product_id`,`product_cycle_count_history`.`date_counted` AS `date_counted` from `product_cycle_count_history` union select `product_physical_count_history`.`inventory_id` AS `inventory_id`,`product_physical_count_history`.`product_id` AS `product_id`,`product_physical_count_history`.`date_counted` AS `date_counted` from `product_physical_count_history`) `inventory_level_summary_unions` group by `inventory_level_summary_unions`.`inventory_id`,`inventory_level_summary_unions`.`product_id`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `product_cycle_count_history`
--

/*!50001 DROP VIEW IF EXISTS `product_cycle_count_history`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb3 */;
/*!50001 SET character_set_results     = utf8mb3 */;
/*!50001 SET collation_connection      = utf8mb3_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`openboxes`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `product_cycle_count_history` AS (select `location`.`inventory_id` AS `inventory_id`,`cycle_count_item`.`product_id` AS `product_id`,max(`cycle_count_item`.`date_counted`) AS `date_counted` from (((`cycle_count` join `cycle_count_request` on(`cycle_count`.`id` = `cycle_count_request`.`cycle_count_id`)) join `cycle_count_item` on(`cycle_count_item`.`cycle_count_id` = `cycle_count`.`id`)) join `location` on(`location`.`id` = `cycle_count`.`facility_id`)) where `cycle_count`.`status` = 'COMPLETED' group by `location`.`inventory_id`,`cycle_count_item`.`product_id`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `product_demand`
--

/*!50001 DROP VIEW IF EXISTS `product_demand`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb3 */;
/*!50001 SET character_set_results     = utf8mb3 */;
/*!50001 SET collation_connection      = utf8mb3_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`openboxes`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `product_demand` AS select `tmp2`.`request_id` AS `request_id`,`tmp2`.`request_status` AS `request_status`,`tmp2`.`request_number` AS `request_number`,`tmp2`.`date_created` AS `date_created`,`tmp2`.`date_requested` AS `date_requested`,`tmp2`.`date_issued` AS `date_issued`,`tmp2`.`origin_id` AS `origin_id`,`tmp2`.`origin_name` AS `origin_name`,`tmp2`.`destination_id` AS `destination_id`,`tmp2`.`destination_name` AS `destination_name`,`tmp2`.`request_item_id` AS `request_item_id`,`tmp2`.`product_id` AS `product_id`,`tmp2`.`product_code` AS `product_code`,`tmp2`.`product_name` AS `product_name`,`tmp2`.`quantity_requested` AS `quantity_requested`,`tmp2`.`quantity_canceled` AS `quantity_canceled`,`tmp2`.`quantity_approved` AS `quantity_approved`,`tmp2`.`quantity_modified` AS `quantity_modified`,`tmp2`.`quantity_picked` AS `quantity_picked`,`tmp2`.`cancel_reason_code` AS `cancel_reason_code`,`tmp2`.`cancel_comments` AS `cancel_comments`,`tmp2`.`pick_reason_code` AS `pick_reason_code`,`tmp2`.`request_item_status` AS `request_item_status`,`tmp2`.`reason_code_classification` AS `reason_code_classification`,`tmp2`.`picklist_reason_code` AS `picklist_reason_code`,coalesce(`tmp2`.`cancel_reason_code`,`tmp2`.`pick_reason_code`,`tmp2`.`picklist_reason_code`) AS `reason_code`,case when `tmp2`.`request_item_status` = 'SUBSTITUTION' then 'ITEM_SUBSTITUTED' when `tmp2`.`quantity_requested` = `tmp2`.`quantity_canceled` and `tmp2`.`quantity_picked` = 0 then 'ITEM_CANCELED' when `tmp2`.`quantity_requested` = `tmp2`.`quantity_approved` and `tmp2`.`quantity_picked` <> `tmp2`.`quantity_approved` then 'PICK_MODIFIED' when `tmp2`.`quantity_requested` <> `tmp2`.`quantity_approved` and `tmp2`.`quantity_picked` = `tmp2`.`quantity_approved` then 'ITEM_MODIFIED' when `tmp2`.`quantity_picked` > 0 then 'ITEM_ISSUED' else NULL end AS `request_item_change_status`,case when `tmp2`.`request_item_status` = 'SUBSTITUTION' then `tmp2`.`quantity_requested` when `tmp2`.`quantity_picked` > `tmp2`.`quantity_requested` then `tmp2`.`quantity_picked` when `tmp2`.`quantity_picked` < `tmp2`.`quantity_requested` and `tmp2`.`reason_code_classification` in (NULL,'INSUFFICIENT_QUANTITY_AVAILABLE') then `tmp2`.`quantity_requested` when `tmp2`.`quantity_picked` < `tmp2`.`quantity_requested` and `tmp2`.`reason_code_classification` = 'CLINICAL_JUDGMENT' then `tmp2`.`quantity_picked` else `tmp2`.`quantity_requested` end AS `quantity_demand` from (select `tmp1`.`request_id` AS `request_id`,`tmp1`.`request_item_id` AS `request_item_id`,`tmp1`.`request_status` AS `request_status`,`tmp1`.`request_number` AS `request_number`,`tmp1`.`date_created` AS `date_created`,`tmp1`.`date_requested` AS `date_requested`,`tmp1`.`date_issued` AS `date_issued`,`tmp1`.`origin_id` AS `origin_id`,`tmp1`.`origin_name` AS `origin_name`,`tmp1`.`destination_id` AS `destination_id`,`tmp1`.`destination_name` AS `destination_name`,`tmp1`.`product_id` AS `product_id`,`tmp1`.`product_code` AS `product_code`,`tmp1`.`product_name` AS `product_name`,`tmp1`.`quantity_requested` AS `quantity_requested`,ifnull(`tmp1`.`quantity_canceled`,0) AS `quantity_canceled`,ifnull(`tmp1`.`quantity_approved`,0) AS `quantity_approved`,ifnull(`tmp1`.`quantity_modified`,0) AS `quantity_modified`,ifnull(`tmp1`.`quantity_picked`,0) AS `quantity_picked`,`tmp1`.`cancel_reason_code` AS `cancel_reason_code`,`tmp1`.`cancel_comments` AS `cancel_comments`,`tmp1`.`pick_reason_code` AS `pick_reason_code`,`tmp1`.`reason_code_classification` AS `reason_code_classification`,`tmp1`.`request_item_status` AS `request_item_status`,`tmp1`.`picklist_reason_code` AS `picklist_reason_code` from (select `requisition`.`id` AS `request_id`,`requisition_item`.`id` AS `request_item_id`,`requisition`.`status` AS `request_status`,`requisition`.`request_number` AS `request_number`,`requisition`.`date_created` AS `date_created`,`requisition`.`date_requested` AS `date_requested`,`requisition_transaction`.`date_issued` AS `date_issued`,`origin`.`id` AS `origin_id`,`origin`.`name` AS `origin_name`,`destination`.`id` AS `destination_id`,`destination`.`name` AS `destination_name`,`child_request_item`.`status` AS `request_item_status`,`product`.`id` AS `product_id`,`product`.`product_code` AS `product_code`,`product`.`name` AS `product_name`,`requisition_item`.`cancel_reason_code` AS `cancel_reason_code`,case when `reason_codes`.`insufficient_quantity_available` > 0 then 'INSUFFICIENT_QUANTITY_AVAILABLE' when `reason_codes`.`clinical_judgment` > 0 then 'CLINICAL_JUDGMENT' else NULL end AS `reason_code_classification`,`reason_codes`.`insufficient_quantity_available` AS `insufficient_quantity_available`,`reason_codes`.`clinical_judgment` AS `clinical_judgment`,`requisition_item`.`cancel_comments` AS `cancel_comments`,`requisition_item`.`pick_reason_code` AS `pick_reason_code`,`requisition_item`.`quantity` AS `quantity_requested`,`requisition_item`.`quantity_canceled` AS `quantity_canceled`,`requisition_item`.`quantity_approved` AS `quantity_approved`,(select sum(`child`.`quantity`) from `requisition_item` `child` where `child`.`parent_requisition_item_id` = `requisition_item`.`id` and `child`.`requisition_item_type` = 'QUANTITY_CHANGE') AS `quantity_modified`,`picked_items`.`quantity_picked` AS `quantity_picked`,`picked_items`.`picklist_reason_code` AS `picklist_reason_code` from (((((((((`requisition_item` join `product` on(`product`.`id` = `requisition_item`.`product_id`)) join `requisition` on(`requisition`.`id` = `requisition_item`.`requisition_id`)) join `location` `destination` on(`destination`.`id` = `requisition`.`destination_id`)) join `location` `origin` on(`origin`.`id` = `requisition`.`origin_id`)) join `location_type` on(`origin`.`location_type_id` = `location_type`.`id`)) left join (select `requisition`.`id` AS `requisition_id`,`transaction`.`transaction_date` AS `date_issued` from ((`requisition` join `shipment` on(`shipment`.`requisition_id` = `requisition`.`id`)) join `transaction` on(`shipment`.`id` = `transaction`.`outgoing_shipment_id`))) `requisition_transaction` on(`requisition`.`id` = `requisition_transaction`.`requisition_id`)) left join (select ifnull(`requisition_item`.`parent_requisition_item_id`,`requisition_item`.`id`) AS `requisition_item_id`,sum(`picklist_item`.`quantity`) AS `quantity_picked`,`picklist_item`.`reason_code` AS `picklist_reason_code` from (`picklist_item` join `requisition_item` on(`picklist_item`.`requisition_item_id` = `requisition_item`.`id`)) group by `requisition_item`.`id`,`picklist_item`.`reason_code`) `picked_items` on(`picked_items`.`requisition_item_id` = `requisition_item`.`id`)) left join (select `requisition_item`.`id` AS `requisition_item_id`,group_concat(distinct `child`.`product_id` separator ',') AS `products`,ifnull(group_concat(distinct `child`.`requisition_item_type` separator ','),`requisition_item`.`requisition_item_type`) AS `status` from (`requisition_item` left join `requisition_item` `child` on(`child`.`parent_requisition_item_id` = `requisition_item`.`id`)) group by `requisition_item`.`id`) `child_request_item` on(`requisition_item`.`id` = `child_request_item`.`requisition_item_id`)) left join (select `parent_item`.`id` AS `requisition_item_id`,sum(if(`parent_item`.`cancel_reason_code` in ('STOCKOUT','LOW_STOCK','COULD_NOT_LOCATE','BACKORDER') or `parent_item`.`pick_reason_code` in ('STOCKOUT','LOW_STOCK','COULD_NOT_LOCATE','BACKORDER') or `child_item`.`cancel_reason_code` in ('STOCKOUT','LOW_STOCK','COULD_NOT_LOCATE','BACKORDER') or `child_item`.`pick_reason_code` in ('STOCKOUT','LOW_STOCK','COULD_NOT_LOCATE','BACKORDER') or `parent_picklist_item`.`reason_code` in ('STOCKOUT','LOW_STOCK','COULD_NOT_LOCATE','BACKORDER') or `child_picklist_item`.`reason_code` in ('STOCKOUT','LOW_STOCK','COULD_NOT_LOCATE','BACKORDER'),1,0)) AS `insufficient_quantity_available`,sum(coalesce(`parent_item`.`cancel_reason_code`,`child_item`.`cancel_reason_code`,`parent_item`.`pick_reason_code`,`child_item`.`pick_reason_code`,`parent_picklist_item`.`reason_code`,`child_picklist_item`.`reason_code`) <> '') AS `clinical_judgment` from (((`requisition_item` `parent_item` left join `requisition_item` `child_item` on(`child_item`.`parent_requisition_item_id` = `parent_item`.`id`)) left join `picklist_item` `parent_picklist_item` on(`parent_item`.`id` = `parent_picklist_item`.`requisition_item_id`)) left join `picklist_item` `child_picklist_item` on(`child_item`.`id` = `child_picklist_item`.`requisition_item_id`)) group by `parent_item`.`id`) `reason_codes` on(`requisition_item`.`id` = `reason_codes`.`requisition_item_id`)) where `requisition_item`.`requisition_item_type` = 'ORIGINAL' and `location_type`.`location_type_code` = 'DEPOT' and `requisition`.`status` = 'ISSUED') `tmp1`) `tmp2` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `product_expiry_summary`
--

/*!50001 DROP VIEW IF EXISTS `product_expiry_summary`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb3 */;
/*!50001 SET character_set_results     = utf8mb3 */;
/*!50001 SET collation_connection      = utf8mb3_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`openboxes`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `product_expiry_summary` AS select `p_a`.`product_id` AS `product_id`,`p_a`.`location_id` AS `location_id`,`i`.`expiration_date` AS `expiration_date`,sum(`p_a`.`quantity_on_hand`) AS `quantity_on_hand`,ifnull(`demand`.`average_daily_demand`,0) AS `average_daily_demand` from ((`product_availability` `p_a` join `inventory_item` `i` on(`i`.`id` = `p_a`.`inventory_item_id`)) left join (select `product_demand_details`.`product_id` AS `product_id`,`product_demand_details`.`origin_id` AS `location_id`,sum(`product_demand_details`.`quantity_demand`) / (to_days(curdate()) - to_days(min(coalesce(`product_demand_details`.`date_issued`,`product_demand_details`.`date_requested`)))) AS `average_daily_demand` from `product_demand_details` group by `product_demand_details`.`product_id`,`product_demand_details`.`origin_id`) `demand` on(`demand`.`product_id` = `p_a`.`product_id` and `demand`.`location_id` = `p_a`.`location_id`)) where `i`.`expiration_date` is not null group by `p_a`.`product_id`,`p_a`.`location_id`,`i`.`expiration_date`,`demand`.`average_daily_demand` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `product_inventory_compare_view`
--

/*!50001 DROP VIEW IF EXISTS `product_inventory_compare_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb3 */;
/*!50001 SET character_set_results     = utf8mb3 */;
/*!50001 SET collation_connection      = utf8mb3_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`openboxes`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `product_inventory_compare_view` AS (select `product`.`id` AS `product_id`,`product`.`product_code` AS `product_code`,`product`.`name` AS `product_name`,`location`.`id` AS `location_id`,`location`.`name` AS `location_name`,case when `product_inventory_pivot_view`.`current_quantity` <= 0 then 'out_of_stock' when `product_inventory_pivot_view`.`current_quantity` <= `inventory_level`.`min_quantity` and `inventory_level`.`min_quantity` <> 0 then 'low_stock' when `product_inventory_pivot_view`.`current_quantity` <= `inventory_level`.`reorder_quantity` and `inventory_level`.`reorder_quantity` <> 0 then 'reorder_stock' when `product_inventory_pivot_view`.`current_quantity` >= `inventory_level`.`max_quantity` and `inventory_level`.`max_quantity` <> 0 then 'over_stock' else 'in_stock' end AS `status`,coalesce(`inventory_level`.`min_quantity`,0) AS `min_quantity`,coalesce(`inventory_level`.`reorder_quantity`,0) AS `reorder_quantity`,coalesce(`inventory_level`.`max_quantity`,0) AS `max_quantity`,`product_inventory_pivot_view`.`previous_quantity` AS `previous_quantity`,`product_inventory_pivot_view`.`current_quantity` AS `current_quantity` from (((`product_inventory_pivot_view` join `product` on(`product`.`id` = `product_inventory_pivot_view`.`product_id`)) join `location` on(`location`.`id` = `product_inventory_pivot_view`.`location_id`)) left join `inventory_level` on(`inventory_level`.`product_id` = `product`.`id` and `inventory_level`.`inventory_id` = `location`.`inventory_id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `product_inventory_expiry_view`
--

/*!50001 DROP VIEW IF EXISTS `product_inventory_expiry_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb3 */;
/*!50001 SET character_set_results     = utf8mb3 */;
/*!50001 SET collation_connection      = utf8mb3_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`openboxes`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `product_inventory_expiry_view` AS (select `location`.`id` AS `location_id`,`location`.`name` AS `location_name`,`bin`.`id` AS `bin_id`,`bin`.`name` AS `bin_name`,`product`.`id` AS `product_id`,`product`.`product_code` AS `product_code`,`product`.`name` AS `product_name`,`inventory_item`.`id` AS `inventory_item_id`,`inventory_item`.`lot_number` AS `lot_number`,`inventory_item`.`expiration_date` AS `expiration_date`,to_days(`inventory_item`.`expiration_date`) - to_days(current_timestamp()) AS `days_until_expiry`,`inventory_snapshot`.`quantity_on_hand` AS `quantity_on_hand` from ((((`inventory_snapshot` join `location` on(`inventory_snapshot`.`location_id` = `location`.`id`)) left join `location` `bin` on(`inventory_snapshot`.`bin_location_id` = `bin`.`id`)) join `inventory_item` on(`inventory_item`.`id` = `inventory_snapshot`.`inventory_item_id`)) join `product` on(`inventory_item`.`product_id` = `product`.`id`)) where `inventory_snapshot`.`date` = (select max(`inventory_snapshot`.`date`) from `inventory_snapshot`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `product_inventory_extended_view`
--

/*!50001 DROP VIEW IF EXISTS `product_inventory_extended_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb3 */;
/*!50001 SET character_set_results     = utf8mb3 */;
/*!50001 SET collation_connection      = utf8mb3_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`openboxes`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `product_inventory_extended_view` AS (select `product_inventory_snapshot_view`.`product_id` AS `product_id`,`product_inventory_snapshot_view`.`location_id` AS `location_id`,`product_inventory_snapshot_view`.`date` AS `date`,case when `product_inventory_snapshot_view`.`date` = cast(curdate() as datetime) then `product_inventory_snapshot_view`.`quantity_on_hand` end AS `previous_quantity`,case when `product_inventory_snapshot_view`.`date` = cast(curdate() + 1 as datetime) then `product_inventory_snapshot_view`.`quantity_on_hand` end AS `current_quantity` from `product_inventory_snapshot_view`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `product_inventory_pivot_view`
--

/*!50001 DROP VIEW IF EXISTS `product_inventory_pivot_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb3 */;
/*!50001 SET character_set_results     = utf8mb3 */;
/*!50001 SET collation_connection      = utf8mb3_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`openboxes`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `product_inventory_pivot_view` AS (select `product_inventory_extended_view`.`product_id` AS `product_id`,`product_inventory_extended_view`.`location_id` AS `location_id`,sum(`product_inventory_extended_view`.`previous_quantity`) AS `previous_quantity`,sum(`product_inventory_extended_view`.`current_quantity`) AS `current_quantity` from `product_inventory_extended_view` group by `product_inventory_extended_view`.`product_id`,`product_inventory_extended_view`.`location_id`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `product_inventory_snapshot_view`
--

/*!50001 DROP VIEW IF EXISTS `product_inventory_snapshot_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb3 */;
/*!50001 SET character_set_results     = utf8mb3 */;
/*!50001 SET collation_connection      = utf8mb3_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`openboxes`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `product_inventory_snapshot_view` AS (select `inventory_snapshot`.`product_id` AS `product_id`,`inventory_snapshot`.`location_id` AS `location_id`,`inventory_snapshot`.`date` AS `date`,sum(`inventory_snapshot`.`quantity_on_hand`) AS `quantity_on_hand` from `inventory_snapshot` where `inventory_snapshot`.`date` between cast(curdate() as datetime) and cast(curdate() + 1 as datetime) group by `inventory_snapshot`.`date`,`inventory_snapshot`.`location_id`,`inventory_snapshot`.`product_id`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `product_physical_count_history`
--

/*!50001 DROP VIEW IF EXISTS `product_physical_count_history`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb3 */;
/*!50001 SET character_set_results     = utf8mb3 */;
/*!50001 SET collation_connection      = utf8mb3_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`openboxes`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `product_physical_count_history` AS select `transaction_candidate`.`inventory_id` AS `inventory_id`,`transaction_candidate`.`product_id` AS `product_id`,max(`transaction_candidate`.`transaction_date`) AS `date_counted` from (select `ac`.`inventory_id` AS `inventory_id`,`ac`.`product_id` AS `product_id`,`ac`.`transaction_date` AS `transaction_date` from `adjustment_candidate` `ac` union all select `ibc`.`inventory_id` AS `inventory_id`,`ibc`.`product_id` AS `product_id`,`ibc`.`transaction_date` AS `transaction_date` from `inventory_baseline_candidate` `ibc` union all select `pic`.`inventory_id` AS `inventory_id`,`pic`.`product_id` AS `product_id`,`pic`.`transaction_date` AS `transaction_date` from `product_inventory_candidate` `pic`) `transaction_candidate` group by `transaction_candidate`.`inventory_id`,`transaction_candidate`.`product_id` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `product_receipt_history`
--

/*!50001 DROP VIEW IF EXISTS `product_receipt_history`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb3 */;
/*!50001 SET character_set_results     = utf8mb3 */;
/*!50001 SET collation_connection      = utf8mb3_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`openboxes`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `product_receipt_history` AS (select `shipment`.`destination_id` AS `facility_id`,`receipt_item`.`product_id` AS `product_id`,`receipt_item`.`inventory_item_id` AS `inventory_item_id`,`receipt`.`actual_delivery_date` AS `date_received` from (((`receipt_item` join `receipt` on(`receipt_item`.`receipt_id` = `receipt`.`id`)) join `shipment` on(`receipt`.`shipment_id` = `shipment`.`id`)) join `location` on(`shipment`.`destination_id` = `location`.`id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `product_snapshot`
--

/*!50001 DROP VIEW IF EXISTS `product_snapshot`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb3 */;
/*!50001 SET character_set_results     = utf8mb3 */;
/*!50001 SET collation_connection      = utf8mb3_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`openboxes`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `product_snapshot` AS (select `product_availability`.`location_id` AS `location_id`,`product_availability`.`product_id` AS `product_id`,sum(`product_availability`.`quantity_on_hand`) AS `quantity_on_hand` from `product_availability` group by `product_availability`.`location_id`,`product_availability`.`product_id`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `product_stocklist`
--

/*!50001 DROP VIEW IF EXISTS `product_stocklist`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb3 */;
/*!50001 SET character_set_results     = utf8mb3 */;
/*!50001 SET collation_connection      = utf8mb3_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`openboxes`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `product_stocklist` AS select `requisition`.`origin_id` AS `origin_id`,`requisition_item`.`product_id` AS `product_id`,ifnull(ceiling(sum(`requisition_item`.`quantity` / `requisition`.`replenishment_period` * 30)),0) AS `quantity_demand` from (`requisition_item` join `requisition` on(`requisition`.`id` = `requisition_item`.`requisition_id`)) where `requisition`.`is_template` = 1 group by `requisition`.`origin_id`,`requisition_item`.`product_id` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `product_stockout`
--

/*!50001 DROP VIEW IF EXISTS `product_stockout`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb3 */;
/*!50001 SET character_set_results     = utf8mb3 */;
/*!50001 SET collation_connection      = utf8mb3_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`openboxes`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `product_stockout` AS (select `stockout_fact_tmp`.`product_id` AS `product_id`,`stockout_fact_tmp`.`location_id` AS `location_id`,case when `stockout_fact_tmp`.`stockout_days` > 21 then 'Stocked out 3-4 weeks' when `stockout_fact_tmp`.`stockout_days` > 14 then 'Stocked out 2-3 weeks' when `stockout_fact_tmp`.`stockout_days` > 7 then 'Stocked out 1-2 weeks' when `stockout_fact_tmp`.`stockout_days` > 0 then 'Stocked out <1 week' when `stockout_fact_tmp`.`stockout_days` = 0 then 'Never' end AS `stockout_status` from (select `product_dimension`.`product_id` AS `product_id`,`location_dimension`.`location_id` AS `location_id`,count(`date_dimension`.`id`) AS `stockout_days` from (((`stockout_fact` join `date_dimension` on(`stockout_fact`.`date_dimension_id` = `date_dimension`.`id`)) join `product_dimension` on(`stockout_fact`.`product_dimension_id` = `product_dimension`.`id`)) join `location_dimension` on(`stockout_fact`.`location_dimension_id` = `location_dimension`.`id`)) where `date_dimension`.`date` between current_timestamp() + interval -30 day and current_timestamp() group by `product_dimension`.`product_id`,`location_dimension`.`location_id`) `stockout_fact_tmp`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `product_stockout_status`
--

/*!50001 DROP VIEW IF EXISTS `product_stockout_status`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb3 */;
/*!50001 SET character_set_results     = utf8mb3 */;
/*!50001 SET collation_connection      = utf8mb3_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`openboxes`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `product_stockout_status` AS (select `product_summary`.`product_id` AS `product_id`,`product_summary`.`location_id` AS `location_id`,ifnull(`product_stockout`.`stockout_status`,'Never') AS `stockout_status` from (`product_summary` left join `product_stockout` on(`product_summary`.`product_id` = `product_stockout`.`product_id` and `product_summary`.`location_id` = `product_stockout`.`location_id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `product_substitution_status`
--

/*!50001 DROP VIEW IF EXISTS `product_substitution_status`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb3 */;
/*!50001 SET character_set_results     = utf8mb3 */;
/*!50001 SET collation_connection      = utf8mb3_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`openboxes`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `product_substitution_status` AS select `association`.`product_id` AS `product_id`,`substitute_availability`.`location_id` AS `location_id`,if(min(`original_inventory_item`.`expiration_date`) is null and min(`substitute_inventory_item`.`expiration_date`) is not null,'EARLIER',if(min(`original_inventory_item`.`expiration_date`) > min(`substitute_inventory_item`.`expiration_date`),'EARLIER','YES')) AS `substitution_status` from ((((`product_association` `association` left join `product_availability` `substitute_availability` on(`substitute_availability`.`product_id` = `association`.`associated_product_id`)) left join `product_availability` `original_availability` on(`original_availability`.`product_id` = `association`.`product_id` and `original_availability`.`location_id` = `substitute_availability`.`location_id` and `original_availability`.`quantity_available_to_promise` > 0)) left join `inventory_item` `substitute_inventory_item` on(`substitute_inventory_item`.`id` = `substitute_availability`.`inventory_item_id`)) left join `inventory_item` `original_inventory_item` on(`original_inventory_item`.`id` = `original_availability`.`inventory_item_id`)) where `association`.`code` = 'SUBSTITUTE' and `substitute_availability`.`quantity_available_to_promise` > 0 group by `association`.`product_id`,`substitute_availability`.`location_id` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `product_summary`
--

/*!50001 DROP VIEW IF EXISTS `product_summary`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb3 */;
/*!50001 SET character_set_results     = utf8mb3 */;
/*!50001 SET collation_connection      = utf8mb3_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`openboxes`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `product_summary` AS select `product`.`id` AS `product_id`,`product_availability`.`location_id` AS `location_id`,ifnull(sum(`product_availability`.`quantity_on_hand`),0) AS `quantity_on_hand`,ifnull(sum(distinct `oos`.`quantity_ordered_not_shipped`),0) AS `quantity_on_order_not_shipped`,ifnull(sum(distinct `oss`.`quantity_shipped_not_received`),0) AS `quantity_on_order_not_received`,ifnull(sum(distinct `oos`.`quantity_ordered_not_shipped`),0) + ifnull(sum(distinct `oss`.`quantity_shipped_not_received`),0) AS `quantity_on_order` from (((`product_availability` join `product` on(`product_availability`.`product_id` = `product`.`id`)) left join `on_order_order_item_summary` `oos` on(`oos`.`product_id` = `product_availability`.`product_id` and `oos`.`destination_id` = `product_availability`.`location_id`)) left join `on_order_shipment_item_summary` `oss` on(`oss`.`product_id` = `product_availability`.`product_id` and `oss`.`destination_id` = `product_availability`.`location_id`)) group by `product_availability`.`location_id`,`product`.`id` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `product_supplier_clean`
--

/*!50001 DROP VIEW IF EXISTS `product_supplier_clean`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb3 */;
/*!50001 SET character_set_results     = utf8mb3 */;
/*!50001 SET collation_connection      = utf8mb3_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`openboxes`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `product_supplier_clean` AS (select `product_supplier`.`id` AS `id`,`product_supplier`.`code` AS `code`,`product_supplier`.`name` AS `name`,`product_supplier`.`product_id` AS `product_id`,`product_supplier`.`supplier_id` AS `supplier_id`,`product_supplier`.`manufacturer_id` AS `manufacturer_id`,replace(replace(replace(`product_supplier`.`supplier_code`,' ',''),'-',''),'.','') AS `supplier_code`,replace(replace(replace(`product_supplier`.`manufacturer_code`,' ',''),'-',''),'.','') AS `manufacturer_code` from `product_supplier`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `requirement`
--

/*!50001 DROP VIEW IF EXISTS `requirement`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb3 */;
/*!50001 SET character_set_results     = utf8mb3 */;
/*!50001 SET collation_connection      = utf8mb3_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`openboxes`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `requirement` AS (select `i_l`.`id` AS `id`,`i_l`.`product_id` AS `product_id`,`loc`.`id` AS `location_id`,`i_l`.`internal_location_id` AS `bin_location_id`,greatest(ifnull(`pa_in_bin`.`quantity_available_to_promise`,0),0) AS `quantity_in_bin`,ifnull(`i_l`.`min_quantity`,0) AS `min_quantity`,ifnull(`i_l`.`max_quantity`,0) AS `max_quantity`,ifnull(`i_l`.`reorder_quantity`,0) AS `reorder_quantity`,greatest(ifnull(`total_pa`.`total_quantity_available_to_promise`,0),0) AS `total_quantity_available_to_promise`,greatest(ifnull(`total_pa`.`total_quantity_available_to_promise`,0),0) - greatest(ifnull(`pa_in_bin`.`quantity_available_to_promise`,0),0) AS `quantity_available`,case when ifnull(`pa_in_bin`.`quantity_available_to_promise`,0) < ifnull(`i_l`.`min_quantity`,0) then 'BELOW_MINIMUM' when ifnull(`pa_in_bin`.`quantity_available_to_promise`,0) < ifnull(`i_l`.`reorder_quantity`,0) then 'BELOW_REORDER' when ifnull(`pa_in_bin`.`quantity_available_to_promise`,0) = 0 then 'OUT_OF_STOCK' when ifnull(`pa_in_bin`.`quantity_available_to_promise`,0) < ifnull(`i_l`.`max_quantity`,0) then 'BELOW_MAXIMUM' when ifnull(`pa_in_bin`.`quantity_available_to_promise`,0) >= ifnull(`i_l`.`min_quantity`,0) and ifnull(`pa_in_bin`.`quantity_available_to_promise`,0) <= ifnull(`i_l`.`max_quantity`,0) then 'IN_STOCK' else NULL end AS `status` from (((`inventory_level` `i_l` join `location` `loc` on(`loc`.`inventory_id` = `i_l`.`inventory_id`)) left join (select `pa_in_bin`.`product_id` AS `product_id`,`pa_in_bin`.`location_id` AS `location_id`,`pa_in_bin`.`bin_location_id` AS `bin_location_id`,sum(`pa_in_bin`.`quantity_available_to_promise`) AS `quantity_available_to_promise` from `product_availability` `pa_in_bin` group by `pa_in_bin`.`product_id`,`pa_in_bin`.`location_id`,`pa_in_bin`.`bin_location_id`) `pa_in_bin` on(`pa_in_bin`.`product_id` = `i_l`.`product_id` and `pa_in_bin`.`bin_location_id` <=> `i_l`.`internal_location_id` and `pa_in_bin`.`location_id` = `loc`.`id`)) left join (select `tpa`.`product_id` AS `product_id`,`tpa`.`location_id` AS `location_id`,sum(`tpa`.`quantity_available_to_promise`) AS `total_quantity_available_to_promise` from `product_availability` `tpa` group by `tpa`.`product_id`,`tpa`.`location_id`) `total_pa` on(`total_pa`.`product_id` = `i_l`.`product_id` and `total_pa`.`location_id` = `loc`.`id`)) where `i_l`.`max_quantity` is not null or `i_l`.`min_quantity` is not null or `i_l`.`reorder_quantity` is not null order by `i_l`.`last_updated` desc) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `stock_movement`
--

/*!50001 DROP VIEW IF EXISTS `stock_movement`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb3 */;
/*!50001 SET character_set_results     = utf8mb3 */;
/*!50001 SET collation_connection      = utf8mb3_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`openboxes`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `stock_movement` AS select `r`.`id` AS `id`,`r`.`name` AS `name`,`r`.`request_number` AS `identifier`,`r`.`description` AS `description`,`r`.`origin_id` AS `origin_id`,`r`.`destination_id` AS `destination_id`,`r`.`date_requested` AS `date_requested`,`r`.`date_created` AS `date_created`,`r`.`last_updated` AS `last_updated`,`r`.`requested_by_id` AS `requested_by_id`,`r`.`created_by_id` AS `created_by_id`,`r`.`updated_by_id` AS `updated_by_id`,coalesce(`ri`.`item_count`,0) AS `line_item_count`,`s`.`shipment_type_id` AS `shipment_type_id`,`s`.`expected_shipping_date` AS `date_shipped`,`s`.`expected_delivery_date` AS `expected_delivery_date`,`s`.`driver_name` AS `driver_name`,`s`.`additional_information` AS `comments`,`s`.`id` AS `shipment_id`,`s`.`current_status` AS `shipment_status`,`rn`.`identifier` AS `tracking_number`,case when `r`.`status` is null then 'REQUESTING' when `r`.`status` = 'EDITING' then 'REQUESTING' when `r`.`status` = 'VERIFYING' then 'REQUESTED' when `r`.`status` = 'CHECKING' then 'PACKED' when `r`.`status` = 'ISSUED' then 'DISPATCHED' else `r`.`status` end AS `status_code`,`r`.`id` AS `requisition_id`,`r`.`status` AS `status`,ifnull(`r`.`type`,'DEFAULT') AS `request_type`,`r`.`source_type` AS `source_type`,`r`.`requisition_template_id` AS `stocklist_id`,NULL AS `order_id`,NULL AS `order_status`,'STOCK_MOVEMENT' AS `stock_movement_type` from ((((`requisition` `r` left join `shipment` `s` on(`s`.`requisition_id` = `r`.`id`)) left join (select `requisition_item`.`requisition_id` AS `requisition_id`,count(0) AS `item_count` from `requisition_item` group by `requisition_item`.`requisition_id`) `ri` on(`ri`.`requisition_id` = `r`.`id`)) left join `shipment_reference_number` `sr` on(`s`.`id` = `sr`.`shipment_reference_numbers_id`)) left join `reference_number` `rn` on(`rn`.`id` = `sr`.`reference_number_id` and `rn`.`reference_number_type_id` = '10')) where `r`.`is_template` is false union all select `o`.`id` AS `id`,`o`.`name` AS `name`,`o`.`order_number` AS `identifier`,`o`.`description` AS `description`,`o`.`origin_id` AS `origin_id`,`o`.`destination_id` AS `destination_id`,`o`.`date_ordered` AS `date_requested`,`o`.`date_created` AS `date_created`,`o`.`last_updated` AS `last_updated`,`o`.`ordered_by_id` AS `requested_by_id`,`o`.`created_by_id` AS `created_by_id`,`o`.`updated_by_id` AS `updated_by_id`,count(`oi`.`id`) AS `line_item_count`,`s`.`shipment_type_id` AS `shipment_type_id`,`s`.`expected_shipping_date` AS `date_shipped`,`s`.`expected_delivery_date` AS `expected_delivery_date`,`s`.`driver_name` AS `driver_name`,`s`.`additional_information` AS `comments`,`s`.`id` AS `shipment_id`,`s`.`current_status` AS `shipment_status`,`rn`.`identifier` AS `tracking_number`,case when `o`.`status` is null then 'PENDING' when `o`.`status` = 'PENDING' then 'PENDING' when `o`.`status` = 'PLACED' then 'REQUESTED' when `o`.`status` = 'APPROVED' then 'PICKING' when `o`.`status` = 'CANCELED' then 'CANCELED' when `o`.`status` = 'PARTIALLY_RECEIVED' then 'DISPATCHED' when `o`.`status` = 'RECEIVED' then 'DISPATCHED' when `o`.`status` = 'COMPLETED' then 'DISPATCHED' when `o`.`status` = 'REJECTED' then 'CANCELED' else 'PENDING' end AS `status_code`,NULL AS `requisition_id`,case when `o`.`status` is null then 'PENDING' when `o`.`status` = 'PENDING' then 'PENDING' when `o`.`status` = 'PLACED' then 'REQUESTED' when `o`.`status` = 'APPROVED' then 'PICKING' when `o`.`status` = 'CANCELED' then 'CANCELED' when `o`.`status` = 'PARTIALLY_RECEIVED' then 'DISPATCHED' when `o`.`status` = 'RECEIVED' then 'DISPATCHED' when `o`.`status` = 'COMPLETED' then 'DISPATCHED' when `o`.`status` = 'REJECTED' then 'CANCELED' else 'PENDING' end AS `status`,NULL AS `request_type`,NULL AS `source_type`,NULL AS `stocklist_id`,`o`.`id` AS `order_id`,`o`.`status` AS `order_status`,'RETURN_ORDER' AS `stock_movement_type` from ((((((`order` `o` left join `order_item` `oi` on(`oi`.`order_id` = `o`.`id`)) left join `order_shipment` `os` on(`os`.`order_item_id` = `oi`.`id`)) left join `shipment_item` `si` on(`si`.`id` = `os`.`shipment_item_id`)) left join `shipment` `s` on(`s`.`id` = `si`.`shipment_id`)) left join `shipment_reference_number` `sr` on(`s`.`id` = `sr`.`shipment_reference_numbers_id`)) left join `reference_number` `rn` on(`rn`.`id` = `sr`.`reference_number_id` and `rn`.`reference_number_type_id` = '10')) where `o`.`order_type_id` = 'RETURN_ORDER' group by `o`.`id`,`s`.`id`,`rn`.`identifier` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `stock_movement_item`
--

/*!50001 DROP VIEW IF EXISTS `stock_movement_item`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb3 */;
/*!50001 SET character_set_results     = utf8mb3 */;
/*!50001 SET collation_connection      = utf8mb3_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`openboxes`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `stock_movement_item` AS select `requisition_item`.`id` AS `id`,`requisition_item`.`requisition_item_type` AS `requisition_item_type`,`requisition_item`.`parent_requisition_item_id` AS `parent_requisition_item_id`,`requisition_item`.`requisition_id` AS `requisition_id`,`requisition`.`origin_id` AS `origin_id`,`requisition`.`destination_id` AS `destination_id`,`requisition_item`.`product_id` AS `product_id`,`product`.`product_code` AS `product_code`,`product`.`name` AS `name`,`requisition_item`.`quantity` AS `quantity`,`requisition_item`.`quantity_canceled` AS `quantity_canceled`,`requisition_item`.`quantity_counted` AS `quantity_counted`,`requisition_item`.`order_index` AS `order_index`,`requisition_item`.`cancel_reason_code` AS `cancel_reason_code`,`requisition_item`.`comment` AS `comments`,case when `modification_item`.`quantity` then `modification_item`.`quantity` when `requisition_item`.`quantity_canceled` = `requisition_item`.`quantity` then 0 else NULL end AS `quantity_revised` from (((`requisition_item` join `requisition` on(`requisition_item`.`requisition_id` = `requisition`.`id`)) join `product` on(`product`.`id` = `requisition_item`.`product_id`)) left join `requisition_item` `modification_item` on(`modification_item`.`parent_requisition_item_id` = `requisition_item`.`id` and `modification_item`.`requisition_item_type` = 'QUANTITY_CHANGE')) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `stock_movement_list_item`
--

/*!50001 DROP VIEW IF EXISTS `stock_movement_list_item`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb3 */;
/*!50001 SET character_set_results     = utf8mb3 */;
/*!50001 SET collation_connection      = utf8mb3_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`openboxes`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `stock_movement_list_item` AS select `r`.`id` AS `id`,`r`.`name` AS `name`,`r`.`request_number` AS `identifier`,`r`.`description` AS `description`,`r`.`origin_id` AS `origin_id`,`r`.`destination_id` AS `destination_id`,`r`.`date_requested` AS `date_requested`,`r`.`date_created` AS `date_created`,`r`.`last_updated` AS `last_updated`,`r`.`requested_by_id` AS `requested_by_id`,`r`.`created_by_id` AS `created_by_id`,`r`.`updated_by_id` AS `updated_by_id`,`s`.`id` AS `shipment_id`,`s`.`current_status` AS `shipment_status`,`s`.`shipment_type_id` AS `shipment_type_id`,case when `r`.`status` is null then 'REQUESTING' when `r`.`status` = 'EDITING' then 'REQUESTING' when `r`.`status` = 'VERIFYING' then 'REQUESTED' when `r`.`status` = 'CHECKING' then 'PACKED' when `r`.`status` = 'ISSUED' then 'DISPATCHED' else `r`.`status` end AS `status_code`,`r`.`id` AS `requisition_id`,`r`.`status` AS `status`,ifnull(`r`.`type`,'DEFAULT') AS `request_type`,`r`.`source_type` AS `source_type`,`r`.`requisition_template_id` AS `stocklist_id`,NULL AS `order_id`,'STOCK_MOVEMENT' AS `stock_movement_type` from (`requisition` `r` left join `shipment` `s` on(`s`.`requisition_id` = `r`.`id`)) where `r`.`is_template` is false union all select `o`.`id` AS `id`,`o`.`name` AS `name`,`o`.`order_number` AS `identifier`,`o`.`description` AS `description`,`o`.`origin_id` AS `origin_id`,`o`.`destination_id` AS `destination_id`,`o`.`date_ordered` AS `date_requested`,`o`.`date_created` AS `date_created`,`o`.`last_updated` AS `last_updated`,`o`.`ordered_by_id` AS `requested_by_id`,`o`.`created_by_id` AS `created_by_id`,`o`.`updated_by_id` AS `updated_by_id`,`s`.`id` AS `shipment_id`,`s`.`current_status` AS `shipment_status`,`s`.`shipment_type_id` AS `shipment_type_id`,case when `o`.`status` is null then 'PENDING' when `o`.`status` = 'PENDING' then 'PENDING' when `o`.`status` = 'PLACED' then 'REQUESTED' when `o`.`status` = 'APPROVED' then 'PICKING' when `o`.`status` = 'CANCELED' then 'CANCELED' when `o`.`status` = 'PARTIALLY_RECEIVED' then 'DISPATCHED' when `o`.`status` = 'RECEIVED' then 'DISPATCHED' when `o`.`status` = 'COMPLETED' then 'DISPATCHED' when `o`.`status` = 'REJECTED' then 'CANCELED' else 'PENDING' end AS `status_code`,NULL AS `requisition_id`,case when `o`.`status` is null then 'CREATED' when `o`.`status` = 'PENDING' then 'CREATED' when `o`.`status` = 'PLACED' then 'CHECKING' when `o`.`status` = 'APPROVED' then 'PICKING' when `o`.`status` = 'CANCELED' then 'CANCELED' when `o`.`status` = 'PARTIALLY_RECEIVED' then 'ISSUED' when `o`.`status` = 'RECEIVED' then 'ISSUED' when `o`.`status` = 'COMPLETED' then 'ISSUED' when `o`.`status` = 'REJECTED' then 'CANCELED' else 'PENDING' end AS `status`,NULL AS `request_type`,NULL AS `source_type`,NULL AS `stocklist_id`,`o`.`id` AS `order_id`,'RETURN_ORDER' AS `stock_movement_type` from ((((`order` `o` left join `order_item` `oi` on(`oi`.`order_id` = `o`.`id`)) left join `order_shipment` `os` on(`os`.`order_item_id` = `oi`.`id`)) left join `shipment_item` `si` on(`si`.`id` = `os`.`shipment_item_id`)) left join `shipment` `s` on(`s`.`id` = `si`.`shipment_id`)) where `o`.`order_type_id` = 'RETURN_ORDER' group by `o`.`id`,`s`.`id` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `stocklist_item_list`
--

/*!50001 DROP VIEW IF EXISTS `stocklist_item_list`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb3 */;
/*!50001 SET character_set_results     = utf8mb3 */;
/*!50001 SET collation_connection      = utf8mb3_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`openboxes`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `stocklist_item_list` AS (select `requisition_item`.`id` AS `id`,`product`.`id` AS `product_id`,`requisition`.`id` AS `stocklist_id`,`requisition`.`name` AS `name`,`location`.`id` AS `location_id`,`location`.`name` AS `location_name`,`location_group`.`id` AS `location_group_id`,`location_group`.`name` AS `location_group_name`,`manager`.`id` AS `manager_id`,concat(`manager`.`first_name`,' ',`manager`.`last_name`) AS `manager_name`,`manager`.`email` AS `manager_email`,`product`.`unit_of_measure` AS `uom`,`requisition_item`.`quantity` AS `max_quantity`,`requisition`.`replenishment_period` AS `replenishment_period`,ceiling(`requisition_item`.`quantity` / `requisition`.`replenishment_period` * 30) AS `monthly_demand` from (((((`requisition_item` join `requisition` on(`requisition_item`.`requisition_id` = `requisition`.`id`)) join `location` on(`requisition`.`origin_id` = `location`.`id`)) left join `location_group` on(`location`.`location_group_id` = `location_group`.`id`)) left join `person` `manager` on(`manager`.`id` = `requisition`.`requested_by_id`)) left join `product` on(`product`.`id` = `requisition_item`.`product_id`)) where `requisition`.`is_published` = 1 and `requisition`.`is_template` = 1) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `substitution_item`
--

/*!50001 DROP VIEW IF EXISTS `substitution_item`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb3 */;
/*!50001 SET character_set_results     = utf8mb3 */;
/*!50001 SET collation_connection      = utf8mb3_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`openboxes`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `substitution_item` AS select `requisition_item`.`id` AS `id`,`requisition_item`.`parent_requisition_item_id` AS `parent_requisition_item_id`,`requisition_item`.`requisition_id` AS `requisition_id`,`requisition`.`origin_id` AS `origin_id`,`requisition`.`destination_id` AS `destination_id`,`requisition_item`.`product_id` AS `product_id`,`product`.`product_code` AS `product_code`,`product`.`name` AS `name`,`requisition_item`.`order_index` AS `sort_order`,`requisition_item`.`quantity` AS `quantity` from ((`requisition_item` join `requisition` on(`requisition_item`.`requisition_id` = `requisition`.`id`)) join `product` on(`product`.`id` = `requisition_item`.`product_id`)) where `requisition_item`.`requisition_item_type` = 'SUBSTITUTION' */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `supplier`
--

/*!50001 DROP VIEW IF EXISTS `supplier`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb3 */;
/*!50001 SET character_set_results     = utf8mb3 */;
/*!50001 SET collation_connection      = utf8mb3_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`openboxes`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `supplier` AS (select `location`.`id` AS `id`,`location`.`name` AS `name`,`location`.`organization_id` AS `organization_id`,count(distinct `purchase_order`.`id`) AS `pending_orders_count`,count(distinct `shipment`.`id`) AS `pending_shipments_count` from (((`location` join `location_type` on(`location_type`.`id` = `location`.`location_type_id`)) left join `order` `purchase_order` on(`purchase_order`.`origin_id` = `location`.`id` and `purchase_order`.`status` not in ('COMPLETED','CANCELED','REJECTED') and `purchase_order`.`order_type_id` = 'PURCHASE_ORDER')) left join `shipment` on(`shipment`.`origin_id` = `location`.`id` and `shipment`.`current_status` <> 'RECEIVED')) where `location_type`.`location_type_code` = 'SUPPLIER' group by `location`.`id`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-10-13  8:08:41
